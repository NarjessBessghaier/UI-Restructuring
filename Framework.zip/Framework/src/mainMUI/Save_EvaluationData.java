package mainMUI;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;

import javax.swing.JOptionPane;

import Parser.nativeApps;
import aesthetics_evaluation_tool.Sorting;
import aesthetics_evaluation_tool.main_launcher;

/**
 * @author bessghaiernarjess
 */
public class Save_EvaluationData {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub

		
		
		//Generate output file

		 if(main_launcher.data_File==null)
		 {
			 JOptionPane.showMessageDialog(null, "You did not evaluate any UI yet!");
 			
		 }
		 else
		 {
		// specify the path to the results out put file
			 PrintStream Output_file= new PrintStream (new File (main_launcher.data_File+"evaluationData.txt" ));
		 
		 System.setOut(Output_file);
		 Output_file.print("----------------------------------");
		 Output_file.print("\n");
		 Output_file.print("Metrics");
		 Output_file.print("\n");
		 Output_file.print("----------------------------------");
		 Output_file.print("----------------------------------");
		 Output_file.print("\n");
		 Output_file.print(  "Uniformity = "+ main_launcher.uniformity1 +"\n"+" Complexity= " + main_launcher.complexity1 
				 +"\n"+" Simplicity= "+main_launcher.simplicity1 + "\n"+" Sequence= " +main_launcher.sorting1 
				 +"\n"+" Regularity= " +main_launcher.regularity1 +"\n"+" Integrality= "
				 +main_launcher.integrality1 + "\n"+" Density= "+main_launcher.density1 +"\n"+" Economy= " +main_launcher.economy1 +"\n"+" Clarity= " 
				 + main_launcher.clarity1 +"\n"+" Unity= " + main_launcher.unity1 +"\n"+" Cohesion= " +main_launcher.cohesion1 +"\n"+" Balance=  "
				 +main_launcher.balance1 +"\n"+ " Grouping= "+main_launcher.grouping1+"\n"+" Homogeneity= "+main_launcher.repartition1+"\n"+"Number of elements= "+main_launcher.elements1);
		 Output_file.print("\n");
		 Output_file.print("----------------------------------");
		 Output_file.print("----------------------------------");
		 Output_file.print("\n");
		
	     Output_file.print("Defects");
	     Output_file.print("\n");
	     Output_file.print("----------------------------------");
	     Output_file.print("----------------------------------");
	     Output_file.print("\n");
		
		 System.out.println("-----------------------------------------------------------------------------");
		  System.out.println("----------------------------------------------");
		  System.out.printf("%1s %30s ", "Defect", "Status");
		  System.out.println();
		  System.out.println("----------------------------------------------");
		 System.out.printf("%1s %24s", "Overloaded MUI",main_launcher.overloaded1);
		   
		   System.out.println(); 
		   
		   System.out.println("----------------------------------------------");
		   System.out.printf("%1s %24s", "Imbalanced MUI",main_launcher.balanced1);
		   System.out.println(); 
		   System.out.println("----------------------------------------------");
		   System.out.printf("%1s%22s", "InCohesion of MUI",main_launcher.cohesioned1);
		   System.out.println(); 
		   System.out.println("----------------------------------------------");
		   
		   System.out.printf("%1s %15s", "Incorrect layout of MUI",main_launcher.layout1);
		   System.out.println(); 
		   System.out.println("----------------------------------------------");
		   System.out.printf("%1s%19s", "Difficult navigation",main_launcher.difficult1);
		   System.out.println(); 
		   System.out.println("----------------------------------------------");
		  

		   System.out.println(); 
		   JOptionPane.showMessageDialog(null, "The Evaluation data has been written !");
		 
		}
		
		

		

	}	
		
		
	

}
