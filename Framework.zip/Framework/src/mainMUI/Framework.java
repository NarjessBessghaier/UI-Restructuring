package mainMUI;
import java.awt.*;
import java.awt.event.*; 
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import javax.imageio.ImageIO;
import javax.swing.*;

import restructuring.GenerateOldMUITree;
import restructuring.GenerateSimilarUI;
import restructuring.restructuringMain;
import DN_Practices.Check_BottomNavAndTab;
import OM_Practices.GenerateNewMUITree;
import OM_Practices.ManualRemovalElements;
import Recommendations.ColorRecommendations;
import Recommendations.ElementsOnEachColumn;
import Recommendations.recomendations;
import aesthetics_evaluation_tool.Cohesion;
import aesthetics_evaluation_tool.Grouping;
import aesthetics_evaluation_tool.Layout_Uniformity;
import aesthetics_evaluation_tool.Sorting;
import aesthetics_evaluation_tool.balance;
import aesthetics_evaluation_tool.clarity;
import aesthetics_evaluation_tool.complexity;
import aesthetics_evaluation_tool.density;
import aesthetics_evaluation_tool.economy;
import aesthetics_evaluation_tool.integrality;
import aesthetics_evaluation_tool.main_launcher;
import aesthetics_evaluation_tool.nb_elements;
import aesthetics_evaluation_tool.regularity;
import aesthetics_evaluation_tool.repartition;
import aesthetics_evaluation_tool.simplicity;
import aesthetics_evaluation_tool.unity;
import mainMUI.Save_EvaluationData;
import mainMUI.evaluate;
import mainMUI.evaluate.ViewElements;
/**
 * @author bessghaiernarjess
 */
public class Framework extends JFrame implements ActionListener{
	private static final int kControlA = 65;
	static String longMessage;
	public static int screenWidth,screenHeight;
	public static JFrame frame;
	JPanel evaluate, recommend, restructure;
	JToolBar barreOutils;
	public static final Color Gold = new Color(255,204,51);
	public static JButton deleteEvaluation;
	JButton boutonEvaluation,boutonRec,boutonDesign,boutonmetadata;
	public static final String SUN_JAVA_COMMAND = "sun.java.command";
	public Framework() throws IOException {
		// TODO Auto-generated constructor stub
		frame= new JFrame();
	        frame.setTitle("Automatic Aesthetic Design Restructuring for Android User Interfaces");
	      //add menu
		    //Add menu bar to our frame
		    MenuBar menuBar = new MenuBar();
		    Menu aboutMenu = new Menu("About");
		    menuBar.add(aboutMenu);
		    
		    frame.setMenuBar(menuBar);
		   
			 
			 aboutMenu.add(new MenuItem("About V1", new MenuShortcut(kControlA))).addActionListener(new Events());

			    longMessage="This Framework aims to provide a tool for designers, developers to:"+"\n "+
		      "-- Evaluate user interfaces: we detect all possible aesthetic issues in the design,"+"\n "
			  +" based on the evaluation of a set of 15 geometrical metrics. Metrics values will help with the "+"\n "+"comprehension of the MUI structure"+"\n "
			  +"-- Remarks: we provide designers/developers with a list of remarks describing the structural"+"\n"+" organization of the MUI"+"\n "
		      +"-- Recommendations: Based on the set of our restructuring operations, we provide the user with "+"\n"+"a set of adaptive restructuring operations based on the structure of the evaluated user interface"+"\n"
			  +"-- Re-design: we consider all the structural points of the user interface, and try to an extent "+"\n"+"apply automatically the proposed recommendations."
			  +"\n"+"\n"+" Considered Aesthetics defects:"+"\n"+
			  "---ICM:"+""+"InCohesion of Mobile User Interface"+"\n"+
			  "this defect means that most of the components do not have same sizes and they are not situated in the center "+"\n"+
			  "of the MUI. i.e. the components are dispersed from each other and the majority does not have same size. "
			  +"\n"+
			  "---ILW:"+""+"Incorrect Layout of Widgets"+"\n"+
			  "this defects means that the components are distributed on all the area of the interface."+"\n"+" i.e. the components have different sizes, and they occupy the majority of the interface.  "+"\n"+
			  "of the MUI. i.e. the components are dispersed from each other and the majority does not have same size. "
			    +"\n"+"PS: the incorrect layout of widgets does not take into consideration whether the components are situated or not in the center!"		    
			   +"\n"+ "---IM:"+""+"Imbalanced Mobile user interface"+"\n"+
				  "this defect means that the quadrants of the MUI do not have the same quantity of components "+"\n"+" (when the components are more situated on the upper side of the MUI,"+"\n"+" or on the lower side of the MUI, or left side or right side. ). "
				 +"\n"+"---OM:"+""+"Overloaded Mobile user interface"+"\n"+
				  "this defect means that the MUI has lots of components, or big size variation"+"\n"+
				 "---DN:"+""+"Difficult Navigation"+"\n"+"this defects concerns buttons, menu items and EditTexts."+"\n"+
				  "if the MUI lacks a text describing the role of a button, or lacks a title describing the role of a menu item,"+"\n"+" "
				  		+ "or lacks a hint describing what to write in an EditText, the defect will be triggered"
				  		+"\n"+"\n"+"\n"+"\n"+"Contact author"+"\n"+"bessghaier.narjess@gmail.com"	;
			    //toolbar
			    
			    barreOutils = new JToolBar () ; 
			    Font font11 = new Font("Lora", Font.BOLD, 12);
			    boutonEvaluation = new JButton ("-Save Evaluation Data-");
			    boutonEvaluation.setBackground(Gold);
			    boutonEvaluation.setContentAreaFilled(true);
			    boutonEvaluation.setOpaque(true);
			    boutonEvaluation.setFont(font11);
				barreOutils.add (boutonEvaluation) ; 
				boutonEvaluation.addActionListener (new SaveEvaluation()) ; 
				boutonmetadata = new JButton ("-Save MUI Description-");
				boutonmetadata.setBackground(Gold);
				boutonmetadata.setContentAreaFilled(true);
				boutonmetadata.setOpaque(true);
				boutonmetadata.setFont(font11);
			    barreOutils.add (boutonmetadata) ; 
			    boutonmetadata.addActionListener (new SaveUIDescription()) ; 
				boutonRec = new JButton ("-Save Recommendations-") ;
				boutonRec.setBackground(Gold);
				boutonRec.setContentAreaFilled(true);
				boutonRec.setOpaque(true);
				boutonRec.setFont(font11);
				barreOutils.add (boutonRec) ; 
				boutonRec.addActionListener (new SaveRecommendations()) ; 
				/*boutonDesign= new JButton("-Save new Design-");
				boutonDesign.setBackground(Color.yellow);
				boutonDesign.setContentAreaFilled(true);
				boutonDesign.setOpaque(true);
				boutonDesign.setFont(font11);
				barreOutils.add (boutonDesign) ;*/
				JButton bouton= new JButton("------------------------------------------------------------------------------------------------------------------------------");
				bouton.setBackground(Gold);
				bouton.setEnabled(false);
				bouton.setContentAreaFilled(true);
				bouton.setOpaque(true);
				bouton.setFont(font11);
				barreOutils.add (bouton) ;
				frame.add(barreOutils, "North") ;
			    
			    
			    
			    
			    JPanel globe= new JPanel();
			    globe.setBackground(Gold);
			    globe.setLayout(new FlowLayout((FlowLayout.LEFT)));
	            frame.add(globe);
	            
	            
			    //evaluate titledborder
			    evaluate evaluate = new evaluate();
			    evaluate.setBackground(Gold);
			    evaluate.getContent();
			    evaluate.add(evaluate.getGUI());
			    
			    JPanel one = new JPanel();
			    one.setBackground(Color.black);
			    one.setLayout(new BoxLayout(one, BoxLayout.Y_AXIS));
			    one.add(evaluate);
			    JPanel deletebtnpanel = new JPanel();
			    deletebtnpanel.setBackground(Gold);
			    //deleteEvaluation= new JButton("Delete Evaluation Data");
			 
			   /* deleteEvaluation.setBackground(Color.black);
			    deleteEvaluation.setForeground(Color.black);
			    deleteEvaluation.setContentAreaFilled(true);
			    deleteEvaluation.setOpaque(true);
			    deleteEvaluation.setFont(font11);
			    deleteEvaluation.setEnabled(false);
			    deletebtnpanel.add(deleteEvaluation);
			    deleteEvaluation.addActionListener(new deleteEvaluation());*/
			    one.add(deletebtnpanel);
			    globe.add(one);
			    
			    
			  //recommendation titledborder
			    recomendations recommend = new recomendations();
			    recommend.setBackground(Gold);
			    recommend.getContent();
			    recommend.add(recommend.getGUI());
			    
			    globe.add(recommend);
			    
			    
			    //color recommendations
			    
			    JPanel one1 = new JPanel();
			    ColorRecommendations color = new ColorRecommendations();
			    color.setBackground(Gold);
			    color.getContent();
			    color.add(color.getGUI());
			    
			    one1.add(color);
			    
			    
			    
			    
			    //restructuring titledborder
			    restructuringMain restructure = new  restructuringMain();
			    restructure.setBackground(Gold);
			    restructure.getContent();
			    restructure.add(restructure.getGUI());
			    
			    
			   
			    one1.setBackground(Color.black);
			    one1.setLayout(new BoxLayout(one1, BoxLayout.Y_AXIS));
			    one1.add(restructure);
			    JPanel similar = new JPanel();
			    similar.setBackground(Gold);
			   
			    JButton similarbtn= new JButton("Start restructuring your MUI");
				similarbtn.setBackground(Color.black);
				similarbtn.setForeground(Color.white);
				similarbtn.setContentAreaFilled(true);
				similarbtn.setOpaque(true);
				similarbtn.setFont(font11); 
				similarbtn.addActionListener(new ViewSimilarUI());
				similar.add(similarbtn);
				 one1.add(similar);
			    globe.add(one1);
			    
			    //restructuringMain.holderTree.setVisible(false);
			 // java - get screen size using the Toolkit class
			    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
			 // the screen width
			    screenWidth = screenSize.width;
			 // the screen height
			     screenHeight = screenSize.height;
			    frame.setSize(screenWidth,screenHeight);
			    JFrame.setDefaultLookAndFeelDecorated(true);
			   frame.setLocationRelativeTo(null);
			   frame.setVisible(true);
			   frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			   pack();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

try {
    for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
        if ("Nimbus".equals(info.getName())) {
            javax.swing.UIManager.setLookAndFeel(info.getClassName());
            break;
        }
    }
} catch (ClassNotFoundException ex) {
    java.util.logging.Logger.getLogger(Framework.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
} catch (InstantiationException ex) {
    java.util.logging.Logger.getLogger(Framework.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
} catch (IllegalAccessException ex) {
    java.util.logging.Logger.getLogger(Framework.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
} catch (javax.swing.UnsupportedLookAndFeelException ex) {
    java.util.logging.Logger.getLogger(Framework.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
}

java.awt.EventQueue.invokeLater(new Runnable() {
    public void run() {
        try {
			new Framework();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
});



	}
	private class Events extends WindowAdapter implements ActionListener
	  {
	 

	    @SuppressWarnings("static-access")
		public void actionPerformed(ActionEvent e)
	    {
	      //System.out.println(e.getActionCommand());
	     
	   
	      if(e.getActionCommand().equalsIgnoreCase("About V1"))
	      { // create a JTextArea
		      JTextArea textArea = new JTextArea(20, 55);
		      //textArea.setBackground(Gold);
		      textArea.setText(longMessage);
		      textArea.setEditable(false);
		     // textArea.setBackground(Color.YELLOW);
		      // wrap a scrollpane around it
		      JScrollPane scrollPane = new JScrollPane(textArea);
		     // scrollPane.setBackground(Gold);
		     
		      UIManager UI=new UIManager();
		      /*UI.put("OptionPane.background", Color.yellow);
		      UI.put("Panel.background", Color.yellow);*/
		      UIManager.put("OptionPane.okButtonText", "Ok, Thanks!");
		      
			  
		      // display them in a message dialog
		      JOptionPane.showMessageDialog(frame, scrollPane,"About",JOptionPane.INFORMATION_MESSAGE);
	      }
	  
	    }
	  }
	//saveevaluation data
	
	private class SaveEvaluation extends WindowAdapter implements ActionListener
	  {
	 

	    @SuppressWarnings("static-access")
		public void actionPerformed(ActionEvent e)
	    {
	      //System.out.println(e.getActionCommand());
	     
	   Save_EvaluationData SED= new Save_EvaluationData();
	 
	   try {
		SED.main(new String[]{});
	} catch (FileNotFoundException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	      }
	    }
	    
	  
	
	//saveRecommendations
	private class SaveRecommendations extends WindowAdapter implements ActionListener
	  {
	 

	    @SuppressWarnings("static-access")
		public void actionPerformed(ActionEvent e)
	    {
	      //System.out.println(e.getActionCommand());
	     
	   mainMUI.Save_recommendations SRC= new mainMUI.Save_recommendations ();
	   if (mainMUI.evaluate.xlspath.getText().isEmpty())
	   {
		   JOptionPane.showMessageDialog(null, "You did not yet evaluate any UI!");
			   
	   }
	   else
	     try {
			SRC.main(new String[]{});
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	      }
	  
	    
	  }
	
	//saveDesign
	
	private class SaveUIDescription extends WindowAdapter implements ActionListener
	  {
	 

	    @SuppressWarnings("static-access")
		public void actionPerformed(ActionEvent e)
	    {
	      //System.out.println(e.getActionCommand());
	     
	  mainMUI.SaveUIDescription meta= new mainMUI.SaveUIDescription();
	  if (recomendations.Clarity.getText().isEmpty())
	   {
		   JOptionPane.showMessageDialog(null, "You did not yet evaluate any UI!");
			   
	   }
	   else
	     try {
			meta.main(new String[]{});
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	      }
	      }

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	  
	    
	  }
	/*
	private class deleteEvaluation extends WindowAdapter implements ActionListener
	
	{

		@SuppressWarnings("static-access")
		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
			mainMUI.evaluate.path.setText("");
			mainMUI.evaluate.xlspath.setText("");
			mainMUI.evaluate.fht.setText("");
			mainMUI.evaluate.fwt.setText("");
			mainMUI.evaluate.lht.setText("");
			mainMUI.evaluate.lwt.setText("");
			mainMUI.evaluate.DNstatus.setText("");
			mainMUI.evaluate.ILWstatus.setText("");
			mainMUI.evaluate.ICMstatus.setText("");
			mainMUI.evaluate.IMstatus.setText("");
			mainMUI.evaluate.OMstatus.setText("");
			
			mainMUI.evaluate.parse.setEnabled(false);
			mainMUI.evaluate.Start.setEnabled(false);
			mainMUI.evaluate.UIdata.setEnabled(false);
			
			mainMUI.evaluate.group.clearSelection();
			
	 		DefaultTableModel dtm = (DefaultTableModel) main_launcher.jTableOM.getModel();
			dtm.setRowCount(0);
			main_launcher.jTableOM.revalidate();
			DefaultTableModel dtm1 = (DefaultTableModel) main_launcher.jTableIM.getModel();
			dtm1.setRowCount(0);
			main_launcher.jTableIM.revalidate();
			DefaultTableModel dtm2 = (DefaultTableModel) main_launcher.jTableICM.getModel();
			dtm2.setRowCount(0);
			main_launcher.jTableICM.revalidate();
			DefaultTableModel dtm3 = (DefaultTableModel) main_launcher.jTableILW.getModel();
			dtm3.setRowCount(0);
			main_launcher.jTableILW.revalidate();
			DefaultTableModel dtm4 = (DefaultTableModel) main_launcher.jTableDN.getModel();
			dtm4.setRowCount(0);
			main_launcher.jTableDN.revalidate();
		  
			mainMUI.evaluate.metricDN.removeAll();
			mainMUI.evaluate.metricICM.removeAll();
			mainMUI.evaluate.metricILW.removeAll();
			mainMUI.evaluate.metricIM.removeAll();
			mainMUI.evaluate.metricOM.removeAll();
			
			balance.value=0;
			clarity.value=0;
			Cohesion.value=0;
			complexity.value=0;
			density.value=0;
			economy.value=0;
			Grouping.value=0;
			integrality.value=0;
			Layout_Uniformity.value=0;
			nb_elements.value=0;
			regularity.value=0;
			repartition.value=0;
			simplicity.value=0;
			Sorting.value=0;
			unity.value=0;
			
			frame.setSize(screenWidth-20, 700);
		deleteEvaluation.setEnabled(false);
		deleteEvaluation.setForeground(Color.black);
		
		
			RestartApplication restart = new RestartApplication();
			try {
				restart.main(new String[]{});
			} catch (IOException | InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	
			
		}}
	*/
	//######## view button
	
	class ViewSimilarUI implements ActionListener {  
		@SuppressWarnings("static-access")
		public void actionPerformed(ActionEvent Event) { 
		
			//if some elements have been removed, the balanceWeight class will be called
			// if not the balanceWeight class will not be called. 
			// we move to the GenerateSimilarUI, that will call the class IM.GenerateGolden that will call the 
			ManualRemovalElements LR= new ManualRemovalElements();
			try {
				LR.main(new String[]{});
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			GenerateSimilarUI UI = new GenerateSimilarUI();
			UI.main(new String[]{});
			
			
			
			
			
		}

	}	
	
	

