package mainMUI;
import java.io.File;
import java.io.IOException;
import java.lang.management.ManagementFactory;
/**
 * @author bessghaiernarjess
 */
public class RestartApplication {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		
		        final String dir = System.getProperty("user.dir");
		        System.out.println("current dir = " + dir);
		
	}

}
