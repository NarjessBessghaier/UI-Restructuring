package mainMUI;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 * @author bessghaiernarjess
 */
public class Check_TextFields {
	public List<JTextField> fieldList;

	public Check_TextFields() {
		// TODO Auto-generated constructor stub
		 fieldList = new ArrayList<JTextField>();
		
		
		fieldList.add(evaluate.xlspath);
	    fieldList.add(evaluate.fht);
	    fieldList.add(evaluate.fwt);
	    fieldList.add(evaluate.lwt);
	    fieldList.add(evaluate.lht);
	    fieldList.add(evaluate.path);
	   
	    
	    DocumentListener myDocListener = new MyDocListener();
	    //addlistener to filedlist
	    for (JTextField field : fieldList)
	    {
	     
	      field.getDocument().addDocumentListener(myDocListener);
	      
	    }
	 
	  }
	 
	private void CheckType()
	{
		 // check types
	    if( ((!(evaluate.lwt.getText().isEmpty())&&!(evaluate.lht.getText().isEmpty())&& !(evaluate.fwt.getText().isEmpty())&&!(evaluate.fht.getText().isEmpty()))
	    		)&&( 
	   ( !evaluate.lwt.getText().matches("^-?\\d+$") )||(!evaluate.lht.getText().matches("^-?\\d+$"))
	   || (!evaluate.fwt.getText().matches("^-?\\d+$") )||(!evaluate.fht.getText().matches("^-?\\d+$"))
	    ))
	    {
	    	JOptionPane.showMessageDialog(null, "Inputs must be integers, re-check!","Warning!", JOptionPane.ERROR_MESSAGE);
	    	 
	    	evaluate.Start.setEnabled(false);
	    	evaluate.Start.setForeground(Color.black);
	    }
	
	}
	//##############
	
	  private void checkFieldsFull()
	  {
	    //check all fields
	      if (
	    		 (evaluate.fht.getText().isEmpty())||(evaluate.fwt.getText().isEmpty())
	    		  ||(evaluate.lht.getText().isEmpty())||(evaluate.lwt.getText().isEmpty())
	    		  ||(evaluate.xlspath.getText().isEmpty())
	    		  
	    		  )
	      {
	        evaluate.Start.setEnabled(false);
	        evaluate.Start.setForeground(Color.black);
	       
	      }
	    
	      else {evaluate.Start.setEnabled(true);evaluate.Start.setForeground(Color.white);}
	      
	    //check path
	      if (  !(evaluate.path.getText().trim().length() == 0) 
	    		  &&( (evaluate.r1.isSelected()==true) || (evaluate.r2.isSelected()==true) ))
	    {
	    	evaluate.parse.setEnabled(true);evaluate.parse.setForeground(Color.white);
	    	
	    }
	      else {evaluate.parse.setEnabled(false);evaluate.parse.setForeground(Color.black);}
	    
	    //check xlspath
	    if (
	      evaluate.xlspath.getText().isEmpty())
	    		  
	    		  
	      {
	        //evaluate.UIdata.setEnabled(false);
	        //evaluate.UIdata.setForeground(Color.black);
	      }
	    
	    else {evaluate.UIdata.setEnabled(true);evaluate.UIdata.setForeground(Color.white);}
	    
	   
	  }
	 
	  private class MyDocListener implements DocumentListener
	  {
	 
	    public void changedUpdate(DocumentEvent e)
	    {
	      checkFieldsFull();
	      CheckType();
		    
	    }
	 
	    public void insertUpdate(DocumentEvent e)
	    {
	      checkFieldsFull();
	      CheckType();
	    
	    }
	 
	    public void removeUpdate(DocumentEvent e)
	    {
	      checkFieldsFull();
	      CheckType();
		    
	    }
	    
	    
	 
	  }
	 
	}


