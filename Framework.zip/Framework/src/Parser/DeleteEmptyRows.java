package Parser;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;

import javax.swing.JOptionPane;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import mainMUI.evaluate;

/**
 * @author bessghaiernarjess
 */
public class DeleteEmptyRows {
	// public static int rowTotal1;
	// public static int[] array=null;
	private static Object row;
	private static HSSFSheet sheet;
	private static int [] array;
	@SuppressWarnings("null")
	public static void main(String[] args) throws FileNotFoundException,IOException {
		// TODO Auto-generated method stub
		
		
		String outputFile=nativeApps.outputFile;
		//System.out.println(outputFile);
		 String indice = ""; 
		InputStream input = new FileInputStream(outputFile);
		 HSSFWorkbook wb     = new HSSFWorkbook(input);
		 sheet = wb.getSheetAt(0); //first sheet
		 //row number
		 int rowTotal = sheet.getLastRowNum();
	
     if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
         rowTotal++;
     }
   	
     for ( int r=0;r<rowTotal; r++){     
			 HSSFRow row     = sheet.getRow(r); 
			 
			 //get cell number in each row
			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
			 
			 // parse cells values of each row
			 for (int c=0;c<1; c++)
	    	        
		        {
				 
			 HSSFCell cell= row.getCell(c);
			// System.out.println("row="+r+"###"+cell.getStringCellValue() );
			 
			 String text= cell.getStringCellValue();
			 //System.out.println("text="+text);
			 
			 if (text.equals(""))
			 {
				indice=indice+r+",";
			 }
		
	}
     
     }
     
     for (int j = 0; j < indice.length(); ++j) { 
			
			//System.out.println("sizes=="+indice);	
		}
	
     
     
     //split the string xval
     
     String[] Finalindice=null;
     Finalindice=indice.split(","); 
 
	 for(int k=0;k<Finalindice.length;k++){
    		
		//System.out.println(Finalindice[k]); 
		
	 }
     
	   array = Arrays.stream(Finalindice).mapToInt(Integer::parseInt).toArray();

	 for(int k=0;k<array.length;k++){
 		
			//System.out.println(array[k]); 
			
		 }
     
	
	 boolean   isRowEmpty = false;
	 
	    for(int i = 0; i < sheet.getLastRowNum(); i++){
	        if(sheet.getRow(i)==null){
	            sheet.shiftRows(i + 1, sheet.getLastRowNum(), -1);
	            i--;
	        continue;
	        }
	        for(int j =0; j<sheet.getRow(i).getLastCellNum();j++){
	            if(sheet.getRow(i).getCell(j).toString().trim().equals("")){
	               isRowEmpty=true;
	            }else {
	                isRowEmpty=false;
	                break;
	            }
	        }
	        if(isRowEmpty==true){
	            sheet.shiftRows(i + 1, sheet.getLastRowNum(), -1);
	            i--;
	        }
	    }
	
	String	outputFileNew=nativeApps.UIXFilePath+"OriginalFile.xls";
		
	 FileOutputStream fileOut = new FileOutputStream(outputFileNew);
		
		//System.out.println(outputFile);
		evaluate.xlspath.setText(outputFileNew);
		//write this workbook to an Outputstream.
		wb.write(fileOut);
		fileOut.flush();
		fileOut.close();
	 
	 
	}

}
