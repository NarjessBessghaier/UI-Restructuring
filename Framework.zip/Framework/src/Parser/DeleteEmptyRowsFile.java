package Parser;

import java.io.File;
import mainMUI.evaluate;
/**
 * @author bessghaiernarjess
 */
public class DeleteEmptyRowsFile {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String outputFile;
		if (mainMUI.evaluate.r1.isSelected()==true )
		{outputFile= nativeApps.outputFile;}
		else  outputFile= hybridApps.outputFile;
		File f1 = new File(outputFile);
		if (f1.delete()) {
		    //System.out.println("File " + f1.getName() + " file is deleted.");
		} else {
		    //System.out.println("File " + f1.getName() + " file not deleted.");
		}
	}

}
