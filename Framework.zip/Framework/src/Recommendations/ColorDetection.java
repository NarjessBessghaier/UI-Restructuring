package Recommendations;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.List;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Map;

import javax.imageio.ImageIO;

import restructuring.GenerateSimilarUI;
import mainMUI.evaluate;

/**
 * @author bessghaiernarjess
 */
@SuppressWarnings("serial")
public class ColorDetection extends Component {
public static ArrayList<String> list;
public static String max,second,third;
public static int max1,second1,third1;
public static  int countup,countdown=0;
private static int nbPixles=0;
public static int[] sortedList ;
public static String[] sortedListColor, finalColors ;
public static final Color Beige = new Color(255,239,213);
public static final Color darkGreen = new Color(0,100,0);
public static final Color darkBlue = new Color(0,0,139);
public static final Color darkPink = new Color(199,21,133);
public static final Color violet = new Color(138,43,226);

	public static void main(String[] args) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException {
		
		
		list = new ArrayList<String>(); 
		try {
		      // get the BufferedImage, using the ImageIO class
			String path=evaluate.pathimage.getText();
		    	File imagePath= new File(path);
				BufferedImage image = ImageIO.read(imagePath);
				marchThroughImage(image);
		    } catch (IOException e) {
		      System.err.println(e.getMessage());
		    }
	  }

	public static void countColor(ArrayList<String> list) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException 
    { 
    	
	
    	Map<String, Integer> hm = new HashMap<String, Integer>(); 
    	  
        for (String i : list) { 
            Integer j = hm.get(i); 
            hm.put(i, (j == null) ? 1 : j + 1); 
        } 
        for (Map.Entry<String, Integer> val : hm.entrySet()) { 
            
    		nbPixles=nbPixles+val.getValue();
 
    }max="";
	max1=0;
        for (Map.Entry<String, Integer> val : hm.entrySet()) { 
        	
        	if((val.getValue()*100/nbPixles)!=0){
        	max1++;}
        } 
        
        //System.out.println(max1);
        sortedList = new int[max1];
        sortedListColor = new String[max1];
        finalColors = new String[max1];
        int i=1;
        int f=0;
        // displaying the occurrence of elements in the arraylist 
         
        
        for (Map.Entry<String, Integer> val : hm.entrySet()) { 
        	
        	if((val.getValue()*100/nbPixles)!=0){
        	recomendations.DN.setText( recomendations.DN.getText() +i+"\" Color " + val.getKey() + " "
                    + "occurs in"
                    + ": " + (val.getValue()*100/nbPixles) + "% of pixels"+"\n");
        		i++;
        		sortedList[f]=((val.getValue()*100/nbPixles));
        		sortedListColor[f]=val.getKey();
        		f++;
        		nbPixles=nbPixles+val.getValue();
        		if ((val.getValue()*100/nbPixles)>=30)
        		{
        			countup++;
        		}
        		if ( ((val.getValue()*100/nbPixles)<30) && ((val.getValue()*100/nbPixles)>=1)  )
        	
        		{
        			countdown++;
        		}
        		
        	}
        } 
        
        
     if (i<=2)
     {
    	 recomendations.DN.setText( recomendations.DN.getText() +" -- "+" You only have "+i+ "colors on you MUI, consider adding"+(3-i)+" colors"+"\n");
          
     }   
     else { 
        ArrayList<String> top3 = new ArrayList<String>(3);
        hm.entrySet().stream()
        .sorted((k1, k2) -> -k1.getValue().compareTo(k2.getValue()))
        .limit(3)
        .forEach(k -> top3.add(k.getKey()));
     

        recomendations.DN.setText( recomendations.DN.getText() +" -- "+countup+" color(s) are/is displayed most frequently across your user interface"+"\n");
        recomendations.DN.setText( recomendations.DN.getText() +" -- "+countdown+" color(s) are/is displayed less frequently across your user interface"+"\n");
        
        if(countup<4)
        { recomendations.DN.setText( recomendations.DN.getText() +"==> No problem with your color numbers"+"\n");
       }
        else
        { recomendations.DN.setText( recomendations.DN.getText() +"==> try to reduce "+(countup-3)+" color(s) from the used intense colors"+"\n");
        }
    	      
    	            	
  /*      recomendations.DN.setText( recomendations.DN.getText() +"Background color= "+top3.get(0)+"\n"+
    	            	"Components first intense color= "+top3.get(1)+"\n"+
    	                "Components second intense color= "+top3.get(2)+"\n");
     
        
        
        */
        
        
        recomendations.DN.setText( recomendations.DN.getText() +"\n"+ "The following conditions must be met: " +"\n");
       	//System.out.println(sortedList[r]);
          	
          	
          	
          	
 
        
      for(int r=0;r<sortedListColor.length;r++)
      { 
        	//System.out.println(sortedListColor[r]);
        		
        	
        }  
      
      
      int max=getMaxValue(sortedList);
      String c1=sortedListColor[max];
      
      if (sortedList[max]<60)
    	{
    		recomendations.DN.setText( recomendations.DN.getText() +
    	sortedListColor[max] +"= +"+ (60-sortedList[max])+"%, ");
    				
    	}
    	else if (sortedList[max]>60)
    	{
    		recomendations.DN.setText( recomendations.DN.getText() +
    	sortedListColor[max] +"= -"+ (sortedList[max]-60)+"%, ");
    				
    	}
      finalColors[0]=c1;
      sortedList[max]=0;
      if(c1.equals("darkGreen"))
      { ColorRecommendations.color1.setBackground(darkGreen);}
      else if (c1.equals("darkBlue"))
      {
    	  ColorRecommendations.color1.setBackground(darkBlue); 
      }
      else if (c1.equals("Beige"))
      {
    	  ColorRecommendations.color1.setBackground(Beige); 
      }
      else if (c1.equals("darkPink"))
      {
    	  ColorRecommendations.color1.setBackground(darkPink); 
      }
      else if (c1.equals("violet"))
      {
    	  ColorRecommendations.color1.setBackground(violet); 
      }
      else
      {Color aColor   = (Color) Color.class.getField(c1).get(null);
  	  ColorRecommendations.color1.setBackground(aColor);
      }
      
      
      
  	 max=getMaxValue(sortedList);
    String c2=sortedListColor[max];
    
    if (sortedList[max]<30)
  	{
  		recomendations.DN.setText( recomendations.DN.getText() +
  	sortedListColor[max] +"= +"+ (30-sortedList[max])+"%, ");
  				
  	}
  	else if (sortedList[max]>30)
  	{
  		recomendations.DN.setText( recomendations.DN.getText() +
  	sortedListColor[max] +"= -"+ (sortedList[max]-30)+"%, ");
  				
  	}
    
    finalColors[1]=c2;
    sortedList[max]=0;
    if(c2.equals("darkGreen"))
    { ColorRecommendations.color2.setBackground(darkGreen);}
    else if (c2.equals("darkBlue"))
    {
  	  ColorRecommendations.color2.setBackground(darkBlue); 
    }
    else if (c2.equals("Beige"))
    {
  	  ColorRecommendations.color2.setBackground(Beige); 
    }
    else if (c2.equals("darkPink"))
    {
  	  ColorRecommendations.color2.setBackground(darkPink); 
    }
    else if (c2.equals("violet"))
    {
  	  ColorRecommendations.color2.setBackground(violet); 
    }
    else
    {Color aColor   = (Color) Color.class.getField(c2).get(null);
	  ColorRecommendations.color2.setBackground(aColor);
    }
    
    
    
	max=getMaxValue(sortedList);
    String c3=sortedListColor[max];
    
    
    if (sortedList[max]<10)
  	{
  		recomendations.DN.setText( recomendations.DN.getText() +
  	sortedListColor[max] +"= +"+ (10-sortedList[max])+"% ");
  				
  	}
  	else if (sortedList[max]>10)
  	{
  		recomendations.DN.setText( recomendations.DN.getText() +
  	sortedListColor[max] +"= -"+ (sortedList[max]-10)+"% ");
  				
  	}
  
    if (i>2)
    {  
    finalColors[2]=c3;
    sortedList[max]=0;
    if(c3.equals("darkGreen"))
    { ColorRecommendations.color3.setBackground(darkGreen);}
    else if (c3.equals("darkBlue"))
    {
  	  ColorRecommendations.color3.setBackground(darkBlue); 
    }
    else if (c3.equals("Beige"))
    {
  	  ColorRecommendations.color3.setBackground(Beige); 
    }
    else if (c3.equals("darkPink"))
    {
  	  ColorRecommendations.color3.setBackground(darkPink); 
    }
    else if (c3.equals("violet"))
    {
  	  ColorRecommendations.color3.setBackground(violet); 
    }
    else
    {Color aColor   = (Color) Color.class.getField(c3).get(null);
	  ColorRecommendations.color3.setBackground(aColor);
    }
    }
    for(int r=0;r<sortedListColor.length;r++)
    { 
      	//System.out.println(finalColors[r]);
      		
      	
      } 
    
        /*String c1= top3.get(0);
        Color aColor   = (Color) Color.class.getField(c1).get(null);
    	ColorRecommendations.color1.setBackground(aColor);
    	String c2= top3.get(1);
        Color aColor1   = (Color) Color.class.getField(c2).get(null);
    	ColorRecommendations.color2.setBackground(aColor1);
    	String c3= top3.get(2);
        Color aColor2   = (Color) Color.class.getField(c3).get(null);
    	ColorRecommendations.color3.setBackground(aColor2);*/
      
    	            	//yellow
    	            	if (finalColors[0].equals("yellow") & finalColors[1].equals("magenta"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice"  
    	            	+"\n"
    	            	+"1- Change the Yellow with White"+"\n"+
    	            			"2- Change the Magenta with Black");}
    	            	else if (finalColors[0].equals("magenta") & finalColors[1].equals("yellow"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Magenta with Black or White"+"\n"+
    	            			"2- Change the Yellow with White or DarkOrange");}
    	            	
    	            	else if (finalColors[0].equals("magenta") & finalColors[1].equals("darkGreen"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Magenta with White"+"\n"+
    	            			"2- Change the darkGreen with White or DarkOrange");}
    	            	
    	            	else if (finalColors[0].equals("darkGreen") & finalColors[1].equals("magenta"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the darkGreen with White"+"\n"+
    	            			"2- Change the magenta with White");}
    	            	
    	            	else if (finalColors[0].equals("magenta") & finalColors[1].equals("darkBlue"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Magenta with White"+"\n"+
    	            			"2- Change the darkBlue with White or DarkOrange");}
    	            	else if (finalColors[0].equals("darkBlue") & finalColors[1].equals("magenta"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the darkBlue with White"+"\n"+
    	            			"2- Change the magenta with White or DarkOrange");}
    	            	
    	            	else if (finalColors[0].equals("magenta") & finalColors[1].equals("red"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Magenta with White"+"\n"+
    	            			"2- Change the red with White or DarkOrange");}
    	            	
    	            	else if (finalColors[0].equals("red") & finalColors[1].equals("magenta"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the red with White"+"\n"+
    	            			"2- Change the magenta with White");}
    	            	
    	            	else if (finalColors[0].equals("magenta") & finalColors[1].equals("green"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Magenta with White"+"\n"+
    	            			"2- Change the green with White or DarkOrange");}
    	            	
    	            	else if (finalColors[0].equals("green") & finalColors[1].equals("magenta"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the green with White"+"\n"+
    	            			"2- Change the magenta with White");}
    	            	
    	            	
    	            	// magenta
    	            	else if (finalColors[0].equals("magenta") & finalColors[1].equals("blue"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Blue with White"+"\n"+
    	            			"2- Change the Magenta with White" );}
    	            	else if (finalColors[0].equals("blue") & finalColors[1].equals("magenta"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Blue with White"+"\n"+
    	            			"2- Change the Magenta with White");}
    	            	else if (finalColors[0].equals("magenta") & finalColors[1].equals("cyan"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Magenta with Red"+"\n"+
    	            			"2- Change the Cyan with White" );}
    	            	else if (finalColors[0].equals("cyan") & finalColors[1].equals("magenta"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Magenta with Red"+"\n"+
    	            			"2- Change the Cyan with White" );}
    	            	
    	            	
    	            	//blue
    	            	else if (finalColors[0].equals("blue") & finalColors[1].equals("cyan"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Blue with DarkOrange"+"\n"+
    	            			"2- Change the Cyan with Orange");}
    	            	else if (finalColors[0].equals("cyan") & finalColors[1].equals("blue"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Blue with DarkOrange"+"\n"+
            			"2- Change the Cyan with Orange");}
    	            	else if (finalColors[0].equals("blue") & finalColors[1].equals("darkBlue"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Blue with white"+"\n"+
    	            			"2- Change the darkBlue with darkOrange");}
    	            	else if (finalColors[0].equals("darkBlue") & finalColors[1].equals("blue"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Blue with DarkOrange or white"+"\n"+
            			"2- Change the darkBlue with white");}
    	            	
    	            	
    	            	else if (finalColors[0].equals("yellow") & finalColors[1].equals("cyan"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Cyan with Black"+"\n"+
    	            			"2- Change the Yellow with DarkOrange" );}
    	            	else if (finalColors[0].equals("cyan") & finalColors[1].equals("yellow"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Cyan with Black"+"\n"+
            			"2- Change the Yellow with DarkOrange"  );}
    	            	else if (finalColors[0].equals("red") & (finalColors[1].equals("green")||finalColors[1].equals("darkGreen")))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Red with White"+"\n"+
    	            			"2- Change the Green with White" );}
    	            	else if (finalColors[0].equals("green") & finalColors[1].equals("red"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Red with White"+"\n"+
            			"2- Change the Green with White"  );}
    	            	else if (finalColors[0].equals("red") & (finalColors[1].equals("blue")||finalColors[1].equals("darkBlue")))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Red with White or Yellow"+"\n"+
    	            			"2- Change the Blue with White" );}
    	            	else if (finalColors[0].equals("blue") & finalColors[1].equals("red"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Red with White or Yellow"+"\n"+
            			"2- Change the Blue with White");}
    	            	else if (finalColors[0].equals("red") & finalColors[1].equals("yellow"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Red with Black or White"+"\n"+
    	            			"2- Change the Yellow with White" );}
    	            	else if (finalColors[0].equals("yellow") &finalColors[1].equals("red"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Red with Black or White"+"\n"+
            			"2- Change the Yellow with White");}
    	            	else if (finalColors[0].equals("red") & finalColors[1].equals("cyan"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0]+" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Red with DarkOrange"+"\n"+
    	            			"2- Change the Cyan with White");}
    	            	else if (finalColors[0].equals("cyan") & finalColors[1].equals("red"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Red with DarkOrange"+"\n"+
            			"2- Change the Cyan with White");}
    	            	else if (finalColors[0].equals("green") & finalColors[1].equals("blue"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Green with White or Yellow"+"\n"+
    	            			"2- Change the Blue with White");}
    	            	else if (finalColors[0].equals("blue") & finalColors[1].equals("green"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice"  
    	            	+"\n"
    	            	+"1- Change the Green with White or Yellow"+"\n"+
            			"2- Change the Blue with White");}
    	            	else if (finalColors[0].equals("green") & finalColors[1].equals("cyan"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Cyan with White"+"\n"+
    	            			"2- Change the Green with DarkOrange" );}
    	            	else if (finalColors[0].equals("cyan") & finalColors[1].equals("green"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Cyan with White"+"\n"+
            			"2- Change the Green with DarkOrange" );}
    	            	else if (finalColors[0].equals("blue") & finalColors[1].equals("black"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Black with White"+"\n"+
    	            			"2- Change the Blue with White");}
    	            	else if (finalColors[0].equals("black") & finalColors[1].equals("blue"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Black with White"+"\n"+
            			"2- Change the Blue with White" );}
    	            	else if (finalColors[0].equals("black") & (finalColors[1].equals("green")||finalColors[1].equals("darkGreen")))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Black with White"+"\n"+
            			"2- Change the green with White" );}
    	            	else if (finalColors[0].equals("red" )& finalColors[1].equals("magenta"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the Red with White"+"\n"+
    	            			"2- Change the Magenta with White" );}
    	            	else if (finalColors[0].equals("magenta") & finalColors[1].equals("red"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0] +" is a bad choice" 
    	            			+"\n"
    	            			+"1- Change the Red with White"+"\n"+
    	            			"2- Change the Magenta with White");}
    	            	else if (finalColors[0].equals("white") & finalColors[1].equals("yellow"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0]+" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the White with Black"+"\n"+
    	            			"2- Change the Yellow with Black" );}
    	            	else if (finalColors[0].equals("yellow") & finalColors[1].equals("white"))
    	            	{ColorRecommendations.result.setText("Using "+finalColors[1]+" on "+ finalColors[0]+" is a bad choice" 
    	            	+"\n"
    	            	+"1- Change the White with Black"+"\n"+
    	            			"2- Change the Yellow with Black");}
    	            	
    	            	
    	            	
    	            	else {ColorRecommendations.result.setText("==> No problem with your colors contrast"); }
    }
    }
	  private static void marchThroughImage(BufferedImage image) throws IllegalArgumentException, IllegalAccessException, NoSuchFieldException, SecurityException {
	
	    for (int r = 0; r < image.getWidth(); r += 1) {
	        for (int c = 0; c < image.getHeight(); c += 1) {
	           
	        	 int rgb = image.getRGB(r,c);
	        	float hsb[] = new float[3];
	        	int r2 = (rgb >> 16) & 0xFF;
	        	int g = (rgb >>  8) & 0xFF;
	        	int b = (rgb      ) & 0xFF;
	        	Color.RGBtoHSB(r2, g, b, hsb);
	        	if      (hsb[1] < 0.1 && hsb[2] > 0.9) nearlyWhite();
	        
	        	else if (hsb[2] < 0.1) nearlyBlack();
	        	else {
	        	    float deg = hsb[0]*360;
	        	    if      (deg >=   0 && deg <  3) red();
	        	    else if (deg >=  4 && deg <  31) orange();
	        	    else if (deg >=  31 && deg <  41) beige();
	        	    else if (deg >=  41 && deg < 55) yellow();
	        	    else if (deg >= 55 && deg < 104) green();
	        	    else if (deg >= 104 && deg < 145) darkgreen();
	        	    else if (deg >= 145 && deg < 189) cyan();
	        	    else if (deg >= 189 && deg < 215) blue();
	        	    else if (deg >= 215 && deg < 260) darkblue();
	        	    else if (deg >= 260 && deg < 280) violet();
	        	   
	        	    else if (deg >= 280 && deg < 290) magenta();
	        	    else if (deg >= 290 && deg < 320) pink();
	        	    else if (deg >= 320 && deg < 345) darkpink();
	        	    else red();
	        }
	    }
	    
	    } 
	 
	    countColor(list); 
	  }

	
	  
	  
		private static void darkpink() {
		// TODO Auto-generated method stub
			String darkpink="darkPink";
			list.add(darkpink);
	}

		private static void magenta() {
		// TODO Auto-generated method stub
			String magenta="magenta";
			list.add(magenta);
			
	}

		private static void darkblue() {
		// TODO Auto-generated method stub
			String darkblue="darkBlue";
			list.add(darkblue);
	}

		private static void darkgreen() {
		// TODO Auto-generated method stub
			String darkgreen="darkGreen";
			list.add(darkgreen);
	}

		

		private static void orange() {
		// TODO Auto-generated method stub
			String orange="orange";
			list.add(orange);
	}

		private static void pink() {
		// TODO Auto-generated method stub
			String pink="pink";
			list.add(pink);
	}

		private static void violet() {
		// TODO Auto-generated method stub
			String violet="violet";
			list.add(violet);
	}

		private static void beige() {
		// TODO Auto-generated method stub
			String beige="Beige";
			list.add(beige);
	}

		

		private static void blue() {
			// TODO Auto-generated method stub
			String blue="blue";
			list.add(blue);
			//countColor(list);
		}

		private static void cyan() {
			// TODO Auto-generated method stub
			String cyan="cyan";
			list.add(cyan);
			//countColor(list);
		}

		private static void green() {
			// TODO Auto-generated method stub
			String green="green";
			list.add(green);
			//countColor(list);
		}

		private static void yellow() {
			// TODO Auto-generated method stub
			String yellow="yellow";
			list.add(yellow);
			//countColor(list);
		}
		
		private static void red() {
			// TODO Auto-generated method stub
			String red="red";
			list.add(red);
			//countColor(list);
			
		}

		private static void nearlyBlack() {
			// TODO Auto-generated method stub
			String nearlyBlack="black";
			list.add(nearlyBlack);
			//countColor(list);
		}

		private static void nearlyWhite() {
			// TODO Auto-generated method stub
			String nearlyWhite="white";
			list.add(nearlyWhite);
			//countColor(list);
		}
		
		
		public static int getMaxValue(int[] rows){ 
			int max = rows[0]; 
		     int maxIdx = 0; 
		     for(int i = 1; i < rows.length; i++) { 
		          if(rows[i] > max) { 
		             max = rows[i]; 
		             maxIdx = i; 
		          } 
		     } 
		     return maxIdx; 
		  }

}
