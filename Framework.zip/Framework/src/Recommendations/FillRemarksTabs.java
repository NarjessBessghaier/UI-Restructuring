package Recommendations;

import aesthetics_evaluation_tool.Sorting;
import aesthetics_evaluation_tool.balance;
import aesthetics_evaluation_tool.main_launcher;
import aesthetics_evaluation_tool.repartition;

/**
 * @author bessghaiernarjess
 */
public class FillRemarksTabs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//economy tab
		
		 recomendations.Economy.setText( recomendations.Economy.getText() +" --you have  "
					+main_launcher.taille1+"  components"+"\n");
		 if(main_launcher.taille1>= 4 & main_launcher.taille1<=17)
		{recomendations.Economy.setText(recomendations.Economy.getText() +main_launcher.taillestatus1);}
		 
		 else if (main_launcher.taille1>= 18 & main_launcher.taille1<=24)
		
		 {
			 recomendations.Economy.setText(recomendations.Economy.getText() +main_launcher.taillestatus2);
		 }
			 if(main_launcher.taille1>= 25 & main_launcher.taille1<=31)
			 {
				 recomendations.Economy.setText(recomendations.Economy.getText() +main_launcher.taillestatus3);
			 }
				 if(main_launcher.taille1>= 32 & main_launcher.taille1<=45)
				 {
					 recomendations.Economy.setText(recomendations.Economy.getText() +main_launcher.taillestatus4);
				 }
					 if(main_launcher.taille1<=4 & main_launcher.taille1 <=17 & main_launcher.density1>=0.6)
					 {
						 recomendations.Economy.setText(recomendations.Economy.getText() +main_launcher.taillestatus5);
					 }
					 
					 
			//regularity tab
		
			recomendations.Regularity.setText("-- Number of columns="+main_launcher.rows1+"\n"+"-- Number of rows="+main_launcher.cols1);	 
			
			//balance weight tab
			
			recomendations.balanceNB.setText("Here is your widgets repartition on the MUI"+"\n"+
					"-- UL has "+(Sorting.ULnew)+" widget(s)" +"\n"+
					"-- UR has "+ (Sorting.URnew)+" widget(s)"+"\n"+
					"-- LL has "+ (Sorting.LLnew)+" widget(s)"+"\n"+
					"-- LR has "+ (Sorting.LRnew)+" widget(s) "+"\n");
			
			//balance nb tab
			int blnc=balance.w_UL+balance.w_UR+balance.w_LL+balance.w_LR;
			recomendations.balanceW.setText("Here is your widgets weight repartition on the MUI"+"\n"+
					"-- UL holds "+(balance.w_UL*100/blnc)+"%  of weight" +"\n"+
					"-- UR holds "+ (balance.w_UR*100/blnc)+"% of weight"+"\n"+
					"-- LL holds "+ (balance.w_LL*100/blnc)+"% of weight"+"\n"+
					"-- LR holds "+ (balance.w_LR*100/blnc)+"% of weight "+"\n");
				if(! main_launcher.balanced1.equals(""))
				
	                {
					if (balance.value<=0.500)
					{
						recomendations.balanceW.setText(recomendations.balanceW.getText()+"The IM defect has been detected due to an unbalanced widgets weights repartition!");
					}
					if (repartition.value<=0.345)
					{ 
						recomendations.balanceNB.setText(recomendations.balanceNB.getText()+"The IM defect has been detected due to an unbalanced widgets number repartition!");
						
						}
					}
			
			//clarity tab
			
			if(main_launcher.button1>0 & main_launcher.btn1>0)
		      {
				recomendations.Clarity.setText(recomendations.Clarity.getText() +"\n"+"-- Clarity of button texts:: you have "+main_launcher.btn1+ " button(s) without text(s) for " + main_launcher.button1 +" button(s)"+"\n");
		      }
		   if(main_launcher.button1>0 & main_launcher.btn1==0) 
				  
				  {recomendations.Clarity.setText(recomendations.Clarity.getText() +"-- No buttons withouts texts found!"+"\n");}
			 
		  /*if(main_launcher.image1>0)
		      {
				  recomendations.Clarity.setText(recomendations.Clarity.getText() +"-- Clarity of the icons (icons-interactive images):: you have "+main_launcher.image1+ " imageView(s). Make sure they/it represent(s) familiar icon(s)"+"\n");
		      }*/
		  if(main_launcher.imagebutton>0)
	      {
			  recomendations.Clarity.setText(recomendations.Clarity.getText() +" --Clarity of the MUI (icons-interactive buttons):: you have "+main_launcher.imagebutton+ " imageButton(s). Make sure they/it represent familiar icons"+"\n");
	      }
		  if(main_launcher.nbedit1>0&main_launcher.edit1>0)
		      {
				  recomendations.Clarity.setText(recomendations.Clarity.getText() +"-- Clarity of the EditText hints:: you have "+main_launcher.edit1+ " EditText(s) without hints for "+ main_launcher.nbedit1+ " EditText(s)"+"\n");
		      }
		 if (main_launcher.button1==0)
			  {
				  recomendations.Clarity.setText(recomendations.Clarity.getText() +"You have no Buttons to check!"+"\n"); 
			  }
		if (main_launcher.nbedit1==0)
			  {
				  recomendations.Clarity.setText(recomendations.Clarity.getText() +"You have no EditTexts to check!"+"\n"); 
			  }
			
			
			
			
			
			
			
			
			
			
			
		
	}

}
