package Recommendations;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.border.TitledBorder;

import Recommendations.recomendations.GenerateRecs;

/**
 * @author bessghaiernarjess
 */
public class ColorRecommendations extends JPanel {
	JPanel color;
	public static final Color Gold = new Color(255,204,51);
    public static JPanel color1,color2,color3;
    public static JTextArea  result;
	public ColorRecommendations() {
		// TODO Auto-generated constructor stub
		color= new JPanel();
		
		 TitledBorder titledBorder = BorderFactory.createTitledBorder("Color Recommendations");
		 color.setBorder(titledBorder);
		
	}

	public void getContent() 
	{
		 Font font11 = new Font("Lora", Font.BOLD, 12);
		 Font font = new Font("Courier", Font.BOLD,12); 
		 color.setLayout(new BoxLayout(color,BoxLayout.Y_AXIS));
		
		 color.setBackground(Gold);
		 
		 
		 JPanel p1= new JPanel();
		 p1.setBackground(Gold);
		 JLabel backgroundColor= new JLabel("Background Color :");
		 backgroundColor.setFont(font);
		 color1= new JPanel();
		 color1.setPreferredSize(new Dimension(40, 20));
		 color1.setBackground(Gold);
		 p1.add(backgroundColor);
		 p1.add(color1);
		 color.add(p1);
		 
		 JPanel p2= new JPanel();
		 p2.setBackground(Gold);
		 JLabel PrimarColor= new JLabel("Primary Color :   ");
		 PrimarColor.setFont(font);
		 color2= new JPanel();
		 color2.setPreferredSize(new Dimension(40, 20));
		 color2.setBackground(Gold);
		 p2.add(PrimarColor);
		 p2.add(color2);
		 color.add(p2);
		 
		 JPanel p3= new JPanel();
		 p3.setBackground(Gold);
		 JLabel SecondColor= new JLabel("Secondary Color : ");
		 SecondColor.setFont(font);
		 color3= new JPanel();
		 color3.setPreferredSize(new Dimension(40, 20));
		 color3.setBackground(Gold);
		 p3.add(SecondColor);
		 p3.add(color3);
		 color.add(p3);
		 
		 result= new JTextArea(3,20);
		 result.setLineWrap(true);
		 color.add(result);
		
		
	}
	
	
	public Component getGUI() {
		// TODO Auto-generated method stub
		return color;
	}
	

}
