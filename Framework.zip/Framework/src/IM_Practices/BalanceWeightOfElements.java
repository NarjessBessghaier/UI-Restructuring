package IM_Practices;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import metaDatagenrationAfterGoldenRatio.ElementsOnEachColumnGolden;
import metaDatagenrationAfterGoldenRatio.GenerateOldGoldenTree;
import metaDatagenrationAfterGoldenRatio.MTDMarginMutliplekeysGolden;

import org.apache.commons.collections4.MultiMap;
import org.apache.commons.collections4.map.MultiValueMap;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import Recommendations.recomendations;
import aesthetics_evaluation_tool.main_launcher;

/**
 * @author bessghaiernarjess
 */
public class BalanceWeightOfElements {
	public static int DiiferentMargins=0;
	public static int rowTotal, maxX;
	public static String result;
	public static  HSSFSheet sheet;
	public static HSSFWorkbook wb;
	static int indice_Row=0;
	public static String file;
	public static HSSFRow row1 ;
	public static String	outputFileNew;
	public static 	boolean MLDStatus;
	public static 	boolean MTDStatus;
	public static 	boolean MRDStatus;
	public static 	boolean MBDStatus;
	public static  int[] R,maxes;
	/*Based on the new generated Golden pro-portions, 
	we will check the consistency of the four different margins to 
	ensure that the group of widgets are in the middle of the MUI.
	
	*
	* In order to do this, we will do a circle of margins application
	*/
	@SuppressWarnings("static-access")
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		file=metaDatagenrationAfterGoldenRatio.MTDMarginMutliplekeysGolden.outputFileNew;

        //String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
    	InputStream input = new FileInputStream(file);
		  wb     = new HSSFWorkbook(input);
		 sheet = wb.getSheetAt(0); //first sheet
		 //row number
		  rowTotal = sheet.getLastRowNum();
	
      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
          rowTotal++;
      }
     /* boolean stop = false;
     while (MLDStatus==false && MRDStatus==false && MTDStatus==false && MBDStatus==false)
     {*/
      ApplyMargins();
      
    /*  stop = true;}
      if (stop) {*/
    	  
      
    // }
     
   
	
		
	}
      @SuppressWarnings("static-access")
	public static void ApplyMargins() throws IOException {
    		ArrayList<Integer> list = new ArrayList<Integer>();
      //##############################
      //##############################
      //#### WORKING ON MLD ##########
      //##############################
      //####First on each row:: minX##
      //##############################
      //##############################
    int[] rows= new int[GenerateOldGoldenTree.nbRows];
   // System.out.println ("rows1"+GenerateOldGoldenTree.nbRows);  
    for ( int l=1;l<=GenerateOldGoldenTree.nbRows; l++){ 
    	
    for ( int r=1;r<rowTotal; r++){     
				 HSSFRow row     = sheet.getRow(r); 
				 
				 //get cell number in each row
				 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
					 HSSFCell cellrow= row.getCell(6);
					 if (sheet.getRow(r) != null && 
				                sheet.getRow(r).getCell(6) != null && 
				               !sheet.getRow(r).getCell(6).toString().equals("")){
					 int rowval= (int) cellrow.getNumericCellValue();
					 if (rowval==l)
					 {
				 HSSFCell cell= row.getCell(1);
				 if (sheet.getRow(r) != null && 
		                    sheet.getRow(r).getCell(1) != null && 
		                   !sheet.getRow(r).getCell(1).toString().equals("")
		                   ){
				 double text= cell.getNumericCellValue();
				// System.out.println (l+"::"+text+"\n");
		    		  list.add((int)text);
		    		  break;
		    		  }
					 }
	 
	}}
	

    //System.out.println ("am hereeeee");	 
int minX=getMinimum(list);   

//je cherche minimal X dans chaque colonne (first cmp). 
//Apres je cherche encore la valeur minimale entre les valeurs minimales (minimal MLD)

rows[l-1]=minX;
list.clear();
    }
	   
		
    for ( int r=0;r<rows.length; r++){  	
	//System.out.println ("MLD"+rows[r]);	
    }
		
 
    //get the lowest MLD
    
    //Arrays.sort(rows);
    
    int minMLD=getMinValue(rows);
    recomendations.IM.setText( recomendations.IM.getText()+"Min MLD::"+minMLD+"\n");
    //loop over rows, get the index (row num) along with the X value and change it to the minMLD value
   
    for (int k=1;k<=GenerateOldGoldenTree.nbRows;k++)
    {
    for ( int r=1;r<rowTotal; r++){     
		 HSSFRow row     = sheet.getRow(r); 
		 
		 //get cell number in each row
		 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
	
		
			 HSSFCell cellrow= row.getCell(6);
			 HSSFCell cellX= row.getCell(1);
			 if (sheet.getRow(r) != null && 
	                    sheet.getRow(r).getCell(6) != null && 
	                   !sheet.getRow(r).getCell(6).toString().equals("")
	                   && 
	                    sheet.getRow(r).getCell(1) != null && 
	                   !sheet.getRow(r).getCell(1).toString().equals("") ){
			 int rowval= (int) cellrow.getNumericCellValue();
			 int Xval= (int) cellX.getNumericCellValue();
			 //System.out.println ("row ="+r+":::"+Xval+"=="+rows[k-1]+"::"+rowval+"=="+k);
			 if (Xval==rows[k-1]& rowval==(k))
			 {
				 //System.out.println ("Am in!");
				 cellX.setCellValue(minMLD);
				 //rows[k-1]=minMLD;
			 }
}
    }
    }  
    
    FileOutputStream fileOut = new FileOutputStream(file);
		
		wb.write(fileOut);
		fileOut.flush();
		fileOut.close();
    
		 
		// re-compute columns and rows
		
		//test if all values in rows are the same --- stopping condition--
		// if rows values are different; call the re-arrangement
		/*MLDStatus=isAllEqual(rows);
		if (MLDStatus==false)
		
		{*/IM_Practices.GenerateOldGoldenTree.nbRows=0;
		IM_Practices.ElementsOnEachColumnGolden.nbColumns=0;
		IM_Practices.GenerateOldGoldenTree gl= new IM_Practices.GenerateOldGoldenTree();
		try {
			gl.main(new String[]{});
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//}
		IM_Practices.MLDMarginMultipleKeysGolden col= new IM_Practices.MLDMarginMultipleKeysGolden();
  		try {
  			col.main(new String[]{});
  		} catch (IOException e1) {
  			// TODO Auto-generated catch block
  			e1.printStackTrace();
  		} 
		file=metaDatagenrationAfterGoldenRatio.MTDMarginMutliplekeysGolden.outputFileNew;

        //String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
    	InputStream input = new FileInputStream(file);
		  wb     = new HSSFWorkbook(input);
		 sheet = wb.getSheetAt(0); //first sheet
		 //row number
		  rowTotal = sheet.getLastRowNum();
	
      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
          rowTotal++;
      }
	
		rows= new int[0];
		
		  //##############################
	      //##############################
	      //#### WORKING ON MTD ##########
	      //##############################
		  //##First on each column:: minY#
	      //##############################
	      //##############################
		
		int OccCol=0;
		 int[] cols= new int[IM_Practices.ElementsOnEachColumnGolden.nbColumns];
		   // System.out.println ("cols1"+IM_Practices.ElementsOnEachColumnGolden.nbColumns);  
		    for ( int l=1;l<=IM_Practices.ElementsOnEachColumnGolden.nbColumns; l++){ 
		    	
		    for ( int r=1;r<rowTotal; r++){     
						 HSSFRow row     = sheet.getRow(r); 
						 
						 //get cell number in each row
						 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
							 HSSFCell cellcol= row.getCell(7);
							 if (sheet.getRow(r) != null && 
					                    sheet.getRow(r).getCell(7) != null && 
					                   !sheet.getRow(r).getCell(7).toString().equals("")){
							 int colval= (int) cellcol.getNumericCellValue();
							 if (colval==l)
							 {OccCol++;
						 HSSFCell cell= row.getCell(2);
						 if (sheet.getRow(r) != null && 
				                    sheet.getRow(r).getCell(2) != null && 
				                   !sheet.getRow(r).getCell(2).toString().equals("")){
						 double text= cell.getNumericCellValue();
						// System.out.println (l+"::"+text+"\n");
				    		  list.add((int)text);
				    		   break;}
			
			 
			}	}
		    }
		    //if (OccCol>1)
		   // {
		    	int minY=getMinimum(list);   
		    
		 
		  cols[l-1]=minY;
		  list.clear();
		    //}
		    }
		    for ( int r=0;r<cols.length; r++){  	
		    	//System.out.println ("MTD"+cols[r]);	
		        }
		    
		
		
		
		    int minMTD=getMinValue(cols);
		    recomendations.IM.setText( recomendations.IM.getText()+"Min MTD::"+minMTD+"\n");
		    for (int k=1;k<=IM_Practices.ElementsOnEachColumnGolden.nbColumns;k++)
		    {
		    for ( int r=1;r<rowTotal; r++){     
				 HSSFRow row     = sheet.getRow(r); 
				 
				 //get cell number in each row
				 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
			
				
					 HSSFCell cellcol= row.getCell(7);
					 HSSFCell cellY= row.getCell(2);
					 if (sheet.getRow(r) != null && 
			                    sheet.getRow(r).getCell(7) != null && 
			                   !sheet.getRow(r).getCell(7).toString().equals("")
			                   && 
			                    sheet.getRow(r).getCell(2) != null && 
			                   !sheet.getRow(r).getCell(2).toString().equals("") ){ 
					 int colval= (int) cellcol.getNumericCellValue();
					 int Yval= (int) cellY.getNumericCellValue();
					 //System.out.println ("row ="+r+":::"+Xval+"=="+rows[k-1]+"::"+rowval+"=="+k);
					 if (Yval==cols[k-1]& colval==(k))
					 {
						 //System.out.println ("Am in!");
						 cellY.setCellValue(minMTD); 
					 }
		}
		    }
		    }  
		    
		    FileOutputStream fileOut1 = new FileOutputStream(file);
				
				wb.write(fileOut1);
				fileOut1.flush();
				fileOut1.close();
		    
				
				// re-compute columns and rows
				/*MTDStatus=isAllEqual(cols);
				if (MTDStatus==false)
				
				{*/	
					IM_Practices.GenerateOldGoldenTree.nbRows=0;
					IM_Practices.ElementsOnEachColumnGolden.nbColumns=0;
				IM_Practices.GenerateOldGoldenTree gl1= new IM_Practices.GenerateOldGoldenTree();
				try {
					gl1.main(new String[]{});
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				//}
				IM_Practices.MTDMarginMutliplekeysGolden col1= new IM_Practices.MTDMarginMutliplekeysGolden();
				try {
					col1.main(new String[]{});
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				file=metaDatagenrationAfterGoldenRatio.MTDMarginMutliplekeysGolden.outputFileNew;

		        //String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
		    	InputStream input1 = new FileInputStream(file);
				  wb     = new HSSFWorkbook(input1);
				 sheet = wb.getSheetAt(0); //first sheet
				 //row number
				  rowTotal = sheet.getLastRowNum();
			
		      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
		          rowTotal++;
		      }
				cols= new int[0];
		
		  //##############################
	      //##############################
	      //#### WORKING ON MRD ##########
	      //##############################
		  //##last on each row:: maxX#####
		  //##############################
		  //##############################
				
				
				//display new values
				
				 for ( int l=1;l<=IM_Practices.GenerateOldGoldenTree.nbRows; l++){ 
				    	
				for ( int r=1;r<rowTotal; r++){     
					 HSSFRow row     = sheet.getRow(r); 
					 
					 //get cell number in each row
					 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
						 HSSFCell cellcol= row.getCell(6);
						 if (sheet.getRow(r) != null && 
				                    sheet.getRow(r).getCell(6) != null && 
				                   !sheet.getRow(r).getCell(6).toString().equals("")
				                   ){
						 int colval= (int) cellcol.getNumericCellValue();
						 if (colval==l)
						 {
					 HSSFCell cell= row.getCell(1);
					 
					 HSSFCell cellR= row.getCell(6);
					 HSSFCell cellC= row.getCell(7);
					 if (sheet.getRow(r) != null && 
			                    sheet.getRow(r).getCell(1) != null && 
			                   !sheet.getRow(r).getCell(1).toString().equals("")
			                   && sheet.getRow(r) != null && 
					                    sheet.getRow(r).getCell(6) != null && 
						                   !sheet.getRow(r).getCell(6).toString().equals("") && sheet.getRow(r) != null && 
								                    sheet.getRow(r).getCell(7) != null && 
									                   !sheet.getRow(r).getCell(7).toString().equals(""))  {
					 double text= (int) cell.getNumericCellValue();
					 double R= (int)cellR.getNumericCellValue();
					 double C= (int)cellC.getNumericCellValue();
					//System.out.println (l+"::"+text+"  "+R+"  "+C+"\n");
			    	}
		
		 
		}	}
	    }
				 }		
				
				
				
				
			
				int WidthValue=0;
				int Occrows=0;
				 int moreThan1=0;
				    //System.out.println ("rows2"+GenerateOldGoldenTree.nbRows);  
				    for ( int l=1;l<=IM_Practices.GenerateOldGoldenTree.nbRows; l++){ 
				    	
				    for ( int r=1;r<rowTotal; r++){     
								 HSSFRow row     = sheet.getRow(r); 
								 
								 //get cell number in each row
								 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
									 HSSFCell cellcol= row.getCell(6);
									 if (sheet.getRow(r) != null && 
							                    sheet.getRow(r).getCell(6) != null && 
							                   !sheet.getRow(r).getCell(6).toString().equals("")
							                   ){
									 int colval= (int) cellcol.getNumericCellValue();
									 if (colval==l)
									 {Occrows++;}}
								 
								}
				    
				    if (Occrows>=2)
				    	
				    {
				    	moreThan1++;
				    	 //System.out.println (l+"moreThan1= "+moreThan1);
				    	 
				    }
				    
				    Occrows=0;
				    }
				    
				     rows= new int[moreThan1];
					maxes= new int[moreThan1];
					  R= new int[moreThan1];
					 int[] widths= new int[moreThan1];
					 
					 
					 //System.out.println ("moreThan1= "+moreThan1); 
					 int found=0;
					 
					 for ( int l=1;l<=IM_Practices.GenerateOldGoldenTree.nbRows; l++){ 
					    	
						    for ( int r=1;r<rowTotal; r++){     
										 HSSFRow row     = sheet.getRow(r); 
										 
										 //get cell number in each row
										 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
											 HSSFCell cellcol= row.getCell(6);
											 if (sheet.getRow(r) != null && 
									                    sheet.getRow(r).getCell(6) != null && 
									                   !sheet.getRow(r).getCell(6).toString().equals("")
									                   ){
											 int colval= (int) cellcol.getNumericCellValue();
											 if (colval==l)
											 {Occrows++;
										 HSSFCell cell= row.getCell(1);
										 if (sheet.getRow(r) != null && 
								                    sheet.getRow(r).getCell(1) != null && 
								                   !sheet.getRow(r).getCell(1).toString().equals("")
								                   ){
										 double text= cell.getNumericCellValue();
										// System.out.println (l+"::"+text+"\n");
								    		  list.add((int)text);}
							
							 
							}	}
						    }
						    if (Occrows>=2)
						    	
						    {
						    
						    maxX=getMaximum(list);
						   // System.out.println (l+"max"+maxX);
						    maxes[found]=maxX;
						    R[found]=l;
						    found++;
						    list.clear();
						    }
						    else  list.clear();
						    
						    Occrows=0;
						    }
						    
					 for ( int r=0;r<R.length; r++){  	
					    	//System.out.println ("R"+R[r]);	
					    	//System.out.println ("maxes"+maxes[r]);
					        } 
					 if(	 isAllEqual(maxes)==false)
						{ 
				    //enter the file and look for the cmp with row=l and x equal to maxX and return the width
				    
				    int found1=0;
				    for ( int l=1;l<=IM_Practices.GenerateOldGoldenTree.nbRows; l++){ 
				    for ( int r1=1;r1<rowTotal; r1++){     
						 HSSFRow row1     = sheet.getRow(r1); 
						 
						 //get cell number in each row
						 int noOfColumns1 = sheet.getRow(r1).getLastCellNum(); 
							 HSSFCell cellcol1= row1.getCell(6);
							 HSSFCell cellX= row1.getCell(1);
							 if (sheet.getRow(r1) != null && 
					                    sheet.getRow(r1).getCell(6) != null && 
					                   !sheet.getRow(r1).getCell(6).toString().equals("")
					                  &&  sheet.getRow(r1).getCell(1) != null && 
							                   !sheet.getRow(r1).getCell(1).toString().equals("") ){
							 int rowval= (int) cellcol1.getNumericCellValue();
							 int Xval= (int) cellX.getNumericCellValue();
							 if(found1==R.length)
							    {
							    break;	
							    }
							 if ( rowval==R[found1]&&Xval==maxes[found1])
							 {//System.out.println (l+"=="+R[found1]+":::"+Xval+"=="+maxes[found1]);	
						 HSSFCell cellW= row1.getCell(3);
						 if (sheet.getRow(r1) != null && 
				                    sheet.getRow(r1).getCell(3) != null && 
				                   !sheet.getRow(r1).getCell(3).toString().equals("")
				                   ){
						  WidthValue= (int) cellW.getNumericCellValue();
						  widths[found1]=WidthValue;
						   
							 int marginX= main_launcher.Framewidth-(maxes[found1]+widths[found1]);
							  rows[found1]=marginX;
							  //list.clear();
						  found1++;
						}
						
			
			 
			}	}  
			   
				
				    }
				    
				    }
				    
				    for ( int r=0;r<rows.length; r++){  	
				    	//System.out.println ("MRD"+rows[r]);	
				        } 
				    	
				
			//get the smallest value from the maximums
				    int minMRD=getMinValue(rows);
				    recomendations.IM.setText( recomendations.IM.getText()+"Min MRD::"+minMRD+"\n");
				    int found11=0;
				    for (int k=1;k<=IM_Practices.GenerateOldGoldenTree.nbRows;k++)
				    {
				    for ( int r=1;r<rowTotal; r++){     
						 HSSFRow row     = sheet.getRow(r); 
						 
						 //get cell number in each row
						 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
					
						
							 HSSFCell cellcol= row.getCell(6);
							 HSSFCell cellY= row.getCell(1);
							 if (sheet.getRow(r) != null && 
					                    sheet.getRow(r).getCell(6) != null && 
					                   !sheet.getRow(r).getCell(6).toString().equals("")
					                   && 
					                    sheet.getRow(r).getCell(1) != null && 
					                   !sheet.getRow(r).getCell(1).toString().equals("") ){
							 int colval= (int) cellcol.getNumericCellValue();
							 int Yval= (int) cellY.getNumericCellValue();
							 //System.out.println ("row ="+r+":::"+Xval+"=="+rows[k-1]+"::"+rowval+"=="+k);
							 if(found11==R.length)
							    {
							    break;	
							    }
							 if (colval==R[found11]&&Yval==maxes[found11])
							 {
								 //System.out.println ("Am in!");
								 cellY.setCellValue(main_launcher.Framewidth-(widths[found11]+minMRD));
								 found11++;
							 }
				}
				    
				    }   }
				    
				    FileOutputStream fileOut2 = new FileOutputStream(file);
						
						wb.write(fileOut2);
						fileOut2.flush();
						fileOut2.close();
				    
							
						// re-compute columns and rows
						
						/*MRDStatus=isAllEqual(rows);
						if (MRDStatus==false)
						
						{*/	IM_Practices.GenerateOldGoldenTree.nbRows=0;
						IM_Practices.ElementsOnEachColumnGolden.nbColumns=0;
						IM_Practices.GenerateOldGoldenTree gl2= new IM_Practices.GenerateOldGoldenTree();
						try {
							gl2.main(new String[]{});
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						
						//}
						}
						MRDMarginMultipleKeysGolden col11= new MRDMarginMultipleKeysGolden();
						try {
							col11.main(new String[]{});
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					
						file=metaDatagenrationAfterGoldenRatio.MTDMarginMutliplekeysGolden.outputFileNew;

				        //String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
				    	InputStream input11 = new FileInputStream(file);
						  wb     = new HSSFWorkbook(input11);
						 sheet = wb.getSheetAt(0); //first sheet
						 //row number
						  rowTotal = sheet.getLastRowNum();
					
				      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
				          rowTotal++;
				      }
						rows= new int[0];
						
							maxes= new int[0];
							  R= new int[0];
							widths= new int[0];
						
		  //##############################
	      //##############################
	      //#### WORKING ON MBD ##########
	      //##############################
		  //##last on each column:: maxY##
		  //##############################
		  //##############################
				
						
						
						//display new values
						
						 for ( int l=1;l<=IM_Practices.ElementsOnEachColumnGolden.nbColumns; l++){ 
						    	
						for ( int r=1;r<rowTotal; r++){     
							 HSSFRow row     = sheet.getRow(r); 
							 
							 //get cell number in each row
							 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
								 HSSFCell cellcol= row.getCell(7);
								 if (sheet.getRow(r) != null && 
						                    sheet.getRow(r).getCell(7) != null && 
						                   !sheet.getRow(r).getCell(7).toString().equals("")
						                   ){
								 int colval= (int) cellcol.getNumericCellValue();
								 if (colval==l)
								 {
							 HSSFCell cell= row.getCell(1);
							 
							 HSSFCell cellR= row.getCell(6);
							 HSSFCell cellC= row.getCell(7);
							 if (sheet.getRow(r) != null && 
					                    sheet.getRow(r).getCell(1) != null && 
					                   !sheet.getRow(r).getCell(1).toString().equals("")
					                   && sheet.getRow(r) != null && 
							                    sheet.getRow(r).getCell(6) != null && 
								                   !sheet.getRow(r).getCell(6).toString().equals("") && sheet.getRow(r) != null && 
										                    sheet.getRow(r).getCell(7) != null && 
											                   !sheet.getRow(r).getCell(7).toString().equals(""))  {
							 double text= (int) cell.getNumericCellValue();
							 double R= (int)cellR.getNumericCellValue();
							 double C= (int)cellC.getNumericCellValue();
							//System.out.println (l+"::"+text+"  "+R+"  "+C+"\n");
					    	}
				
				 
				}	}
			    }
						 }		
						
								
						
						
						
						
						 int WidthValue1=0;
							int Occrows1=0;
							 int moreThan11=0;
							    //System.out.println ("rows2"+GenerateOldGoldenTree.nbRows);  
							    for ( int l=1;l<=IM_Practices.ElementsOnEachColumnGolden.nbColumns; l++){ 
							    	
							    for ( int r=1;r<rowTotal; r++){     
											 HSSFRow row     = sheet.getRow(r); 
											 
											 //get cell number in each row
											 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
												 HSSFCell cellcol= row.getCell(7);
												 if (sheet.getRow(r) != null && 
										                    sheet.getRow(r).getCell(7) != null && 
										                   !sheet.getRow(r).getCell(7).toString().equals("")
										                   ){
												 int colval= (int) cellcol.getNumericCellValue();
												 if (colval==l)
												 {Occrows1++;}}
											 
											}
							    
							    if (Occrows1>=2)
							    	
							    {
							    	moreThan11++;
							    	 //System.out.println (l+"moreThan1= "+moreThan1);
							    	 
							    }
							    
							    Occrows1=0;
							    }
							    
							     rows= new int[moreThan11];
								maxes= new int[moreThan11];
								  R= new int[moreThan11];
								 int[] widths1= new int[moreThan11];
								 
								 
								// System.out.println ("moreThan1= "+moreThan1); 
								 int found111=0;
							 
								 for ( int l=1;l<=IM_Practices.ElementsOnEachColumnGolden.nbColumns; l++){ 
								    	
									    for ( int r=1;r<rowTotal; r++){     
													 HSSFRow row     = sheet.getRow(r); 
													 
													 //get cell number in each row
													 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
														 HSSFCell cellcol= row.getCell(7);
														 if (sheet.getRow(r) != null && 
												                    sheet.getRow(r).getCell(7) != null && 
												                   !sheet.getRow(r).getCell(7).toString().equals("")
												                   ){
														 int colval= (int) cellcol.getNumericCellValue();
														 if (colval==l)
														 {Occrows1++;
													 HSSFCell cell= row.getCell(2);
													 if (sheet.getRow(r) != null && 
											                    sheet.getRow(r).getCell(2) != null && 
											                   !sheet.getRow(r).getCell(2).toString().equals("")
											                   ){
													 double text= cell.getNumericCellValue();
													// System.out.println (l+"::"+text+"\n");
											    		  list.add((int)text);}
										
										 
										}	}
									    }
									    if (Occrows1>=2)
									    	
									    {
									    
									    maxX=getMaximum(list);
									   // System.out.println (l+"max"+maxX);
									    maxes[found111]=maxX;
									    R[found111]=l;
									    found111++;
									    list.clear();
									    }
									    else  list.clear();
									    
									    Occrows1=0;
									    }
									    
								 for ( int r=0;r<R.length; r++){  	
								    	//System.out.println ("C"+R[r]);	
								    	//System.out.println ("maxes"+maxes[r]);
								        } 
								 
							if(	 isAllEqual(maxes)==false)
							{
								 //enter the file and look for the cmp with row=l and x equal to maxX and return the width
								    
								    int found1111=0;
								    for ( int l=1;l<=IM_Practices.ElementsOnEachColumnGolden.nbColumns; l++){ 
								    for ( int r1=1;r1<rowTotal; r1++){     
										 HSSFRow row1     = sheet.getRow(r1); 
										 
										 //get cell number in each row
										 int noOfColumns1 = sheet.getRow(r1).getLastCellNum(); 
											 HSSFCell cellcol1= row1.getCell(7);
											 HSSFCell cellX= row1.getCell(2);
											 if (sheet.getRow(r1) != null && 
									                    sheet.getRow(r1).getCell(7) != null && 
									                   !sheet.getRow(r1).getCell(7).toString().equals("")
									                  &&  sheet.getRow(r1).getCell(2) != null && 
											                   !sheet.getRow(r1).getCell(2).toString().equals("") ){
											 int rowval= (int) cellcol1.getNumericCellValue();
											 int Xval= (int) cellX.getNumericCellValue();
											 if(found1111==R.length)
											    {
											    break;	
											    }
											 if ( rowval==R[found1111]&&Xval==maxes[found1111])
											 {System.out.println (l+"=="+R[found1111]+":::"+Xval+"=="+maxes[found1111]);	
										 HSSFCell cellW= row1.getCell(4);
										 if (sheet.getRow(r1) != null && 
								                    sheet.getRow(r1).getCell(4) != null && 
								                   !sheet.getRow(r1).getCell(4).toString().equals("")
								                   ){
										  WidthValue= (int) cellW.getNumericCellValue();
										  widths[found1111]=WidthValue;
										   
											 int marginX= main_launcher.Frameheight-(maxes[found1111]+widths[found1111]);
											  rows[found1111]=marginX;
											  //list.clear();
										  found1111++;
										}
										
							
							 
							}	}  
							   
								
								    }
								    
								    }
								    
								    for ( int r=0;r<rows.length; r++){  	
								    	System.out.println ("MBD"+rows[r]);	
								        } 
								    	
						
						
						
									//get the smallest value from the maximums
								    int minMBD=getMinValue(rows);
								   
								   // System.out.println ("minMBD "+minMBD);
								    int found11111=0;
								    for (int k=1;k<=IM_Practices.ElementsOnEachColumnGolden.nbColumns;k++)
								    {
								    for ( int r=1;r<rowTotal; r++){     
										 HSSFRow row     = sheet.getRow(r); 
										 
										 //get cell number in each row
										 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
									
										
											 HSSFCell cellcol= row.getCell(7);
											 HSSFCell cellY= row.getCell(2);
											 if (sheet.getRow(r) != null && 
									                    sheet.getRow(r).getCell(7) != null && 
									                   !sheet.getRow(r).getCell(7).toString().equals("")
									                   && 
									                    sheet.getRow(r).getCell(2) != null && 
									                   !sheet.getRow(r).getCell(2).toString().equals("") ){
											 int colval= (int) cellcol.getNumericCellValue();
											 int Yval= (int) cellY.getNumericCellValue();
											 //System.out.println ("row ="+r+":::"+Xval+"=="+rows[k-1]+"::"+rowval+"=="+k);
											 if(found11111==R.length)
											    {
											    break;	
											    }
											 if (colval==R[found11111]&&Yval==maxes[found11111])
											 {
												 //System.out.println ("Am in!");
												 cellY.setCellValue(main_launcher.Frameheight-(widths[found11111]+minMBD));
												 found11111++;
											 }
								}
								    
								    }   }
								    	
						
								    FileOutputStream fileOut11 = new FileOutputStream(file);
									
									wb.write(fileOut11);
									fileOut11.flush();
									fileOut11.close();
									
									// re-compute columns and rows
									/*MBDStatus=isAllEqual(cols);
									if (MBDStatus==false)
									
									{*/	
										IM_Practices.GenerateOldGoldenTree.nbRows=0;
										IM_Practices.ElementsOnEachColumnGolden.nbColumns=0;
									IM_Practices.GenerateOldGoldenTree gl11= new IM_Practices.GenerateOldGoldenTree();
									try {
										gl11.main(new String[]{});
									} catch (IOException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}
									
									//}
									cols= new int[0];  
							}
							 recomendations.IM.setText( recomendations.IM.getText()+"Min MBD::"+maxes[0]+"\n");
									
							IM_Practices.MBDMarginMultipleKeysGolden col2= new IM_Practices.MBDMarginMultipleKeysGolden();
									try {
										col2.main(new String[]{});
									} catch (IOException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}
						
							
						
						
						
									
      }
						
						
						
						
						
						
						
    
	
	private static int getMaximum(ArrayList<Integer> list) {
		// TODO Auto-generated method stub
		int value=0;
		Collections.sort(list);
		Map<Integer, Integer> hm = new HashMap<Integer, Integer>(); 
  	  
        for (Integer i : list) { 
            Integer j = hm.get(i); 
            hm.put(i, (j == null) ? 1 : j + 1); 
        } 
  
        // displaying the occurrence of elements in the arraylist 
        for (Map.Entry<Integer, Integer> val : hm.entrySet()) { 
        	
        	 //System.out.println("Element " + val.getKey() + " "  + "occurs" + ": " + val.getValue() + " times");
        	// value=val.getKey();
        }
      if (list.size()>=1)
        {
    	  value=list.get(list.size() - 1);
        }
       
		return value;
	}
	private static int getMinimum(ArrayList<Integer> list) {
		
		int value=0;
		Collections.sort(list);
		Map<Integer, Integer> hm = new HashMap<Integer, Integer>(); 
  	  
        for (Integer i : list) { 
            Integer j = hm.get(i); 
            hm.put(i, (j == null) ? 1 : j + 1); 
        } 
  
        // displaying the occurrence of elements in the arraylist 
        for (Map.Entry<Integer, Integer> val : hm.entrySet()) { 
        	
        	 //System.out.println("Element " + val.getKey() + " "  + "occurs" + ": " + val.getValue() + " times");
        	// value=val.getKey();
        }
        value=list.get(0);
if (list.size()>=1)
        {
	 // ne rien faire
        }
      
        //System.out.println("value ==" +value);
		//return Collections.min(list);
        return value;
		// TODO Auto-generated method stub
		
	}

	
	public static int getMinValue(int[] rows){
		  int minValue = rows[0];
		  for(int i=1;i<rows.length;i++){
		    if(rows[i] < minValue){
			  minValue = rows[i];
			}
		  }
		  return minValue;
	}
	
	
	 public static int getMaxValue(int[] rows){ 
		    int maxValue = rows[0]; 
		    for(int i=1;i < rows.length;i++){ 
		      if(rows[i] > maxValue){ 
		         maxValue = rows[i]; 
		      } 
		    } 
		    return maxValue; 
		  }
	

		    public static boolean isAllEqual(int[] a){
		        for(int i=1; i<a.length; i++){
		            if(a[0] != a[i]){
		                return false;
		            }
		        }

		        return true;
		    }

	 
}
