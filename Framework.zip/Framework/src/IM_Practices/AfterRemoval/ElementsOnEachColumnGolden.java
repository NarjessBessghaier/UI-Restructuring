package IM_Practices.AfterRemoval;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import restructuring.GenerateOldMUITree;
import aesthetics_evaluation_tool.main_launcher;

/**
 * @author bessghaiernarjess
 */
public class ElementsOnEachColumnGolden {

	public static int rowTotal;
	public static String result;
	public static  HSSFSheet sheet;
	static int indice_X=0;
	public static int nbColumns;
	public static String	outputFileNew;
	
    public static void countFrequencies(ArrayList<Integer> list) 
    { 
  
    	Map<Integer, Integer> hm = new HashMap<Integer, Integer>(); 
    	  
        for (Integer i : list) { 
            Integer j = hm.get(i); 
            hm.put(i, (j == null) ? 1 : j + 1); 
        } 
  
        // displaying the occurrence of elements in the arraylist 
        for (Map.Entry<Integer, Integer> val : hm.entrySet()) { 
        	nbColumns++;
        	// System.out.println("Element " + val.getKey() + " "  + "occurs" + ": " + val.getValue() + " times"); 
        } 
        //nbColumns=hm.size();
       // System.out.println("IMPractices oneachcolumn"+nbColumns);
    } 
  
    @SuppressWarnings("static-access")
	public static void main(String[] args) throws IOException 
    { 
        ArrayList<Integer> list = new ArrayList<Integer>(); 
        
        
       String file=BalanceWeightOfElements.file;
        //String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
    	InputStream input = new FileInputStream(file);
		 HSSFWorkbook wb     = new HSSFWorkbook(input);
		 sheet = wb.getSheetAt(0); //first sheet
		 //row number
		  rowTotal = sheet.getLastRowNum();
	
      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
          rowTotal++;
      }
    	
      for ( int r=1;r<rowTotal; r++){     
			 HSSFRow row     = sheet.getRow(r); 
			 
			 //get cell number in each row
			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
			 
			 // parse cells values of each row
			 for (int c=1;c<2; c++)
	    	        
		        {
				 
			 HSSFCell cell= row.getCell(c);
			// System.out.println("row="+r+"###"+cell.getStringCellValue() );
			 if (sheet.getRow(r) != null && 
	                    sheet.getRow(r).getCell(c) != null && 
	                   !sheet.getRow(r).getCell(c).toString().equals("")){ 
			 double text= cell.getNumericCellValue();
			 //System.out.println("text cols="+text);
			 
			
	    		  list.add((int)text);
	    		
		        }
			 }	}  
        
	    countFrequencies(list); 
	    orderList(list);
        orderComponentsCols(list);
        
      //	outputFileNew=file+"File2.xls";
   		
   	    FileOutputStream fileOut = new FileOutputStream(file);
   		
   		wb.write(fileOut);
   		fileOut.flush();
   		fileOut.close();
   	
   		
    }
    

	public static void orderList(ArrayList<Integer> list) 
    { 
  
    	Collections.sort(list);
    	 
        //System.out.println("After ArrayList sort " +list);
      
    }
    
    @SuppressWarnings("static-access")
	private static void orderComponentsCols(ArrayList<Integer> list) {
		// TODO Auto-generated method stub
 
    	int size = list.size();
  
//get the elements
    	 
    	 result="";
         int s=0;
         int r;
         int k=1;
    	 for (int i=0; i<size;i++){
    		
    		 double val= list.get(i); 
    	 for (r=1;r<rowTotal; r++){ 
    		 
 			 HSSFRow row     = sheet.getRow(r); 
 			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
 			 for (int c=1;c<2; c++) {				 
 			 HSSFCell cell= row.getCell(c);	
 			 if (sheet.getRow(r) != null && 
	                    sheet.getRow(r).getCell(c) != null && 
	                   !sheet.getRow(r).getCell(c).toString().equals("")){
 			 double value= cell.getNumericCellValue();
             //System.out.println(val+"=="+value);
 			 if (val==value)
 			 { s++;
 				 HSSFCell cellText= row.getCell(0);  			 
  			     String text= cellText.getStringCellValue();
  			     
  			     HSSFCell cellX= row.getCell(1);  			 
  			     int X= (int) cellX.getNumericCellValue();
			     
			     HSSFCell cellY= row.getCell(2);  			 
			     int Y= (int) cellY.getNumericCellValue();
			     
			     HSSFCell cellW= row.getCell(3);  			 
			     int W= (int) cellW.getNumericCellValue();
			     
			     HSSFCell cellH= row.getCell(4);  			 
			     int H= (int) cellH.getNumericCellValue();
			   
  			     //System.out.println("(Column"+(k)+")::"+text+"::"+"["+X+","+Y+"]["+W+","+H+"]"+"\n");
			     //result=result+"(Row"+(k)+")"+text+"::"+"["+X+","+Y+"]["+W+","+H+"]"+"\n";
  			   HSSFCell cell1 = row.getCell(7);
  			 //System.out.println(k);
			     cell1.setCellValue(k); 
			    /* row     = sheet.getRow(0); 
			     HSSFCell cell2 = row.createCell(7);
			     cell2.setCellValue("Column"); */
 			 }
 		
 			 
 		        }}
 			 }
    	 k++;
    	if (s>1)i=s-1;
    	 }
	}

    
}