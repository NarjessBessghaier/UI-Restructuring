package IM_Practices.AfterRemoval;

/**
 * @author bessghaiernarjess
 */
public class BalanceNumberOfElements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//Manual removal is done
		//Automatic removal of widgets if possible
	}

}
