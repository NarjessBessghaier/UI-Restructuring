package aesthetics_evaluation_tool;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class integrality {
public static int CAreafinal=0;
public static int UIArea=0;
//public static int  AreaInteractivePlatform=0;
public static int CArea=0;
public static double value=0;
	public double integrality() throws IOException,FileNotFoundException  {
	
	// TODO Auto-generated constructor stub
		
		
		int indice_width=0;
		int indice_height=0;	
String file=main_launcher.data_File;
    	
    	InputStream input = new FileInputStream(file);
		 HSSFWorkbook wb     = new HSSFWorkbook(input);
		 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
		 //row number
		 int rowTotal = sheet.getLastRowNum();
	
      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
          rowTotal++;
      }
    	
      for ( int r=0;r<1; r++){     
			 HSSFRow row     = sheet.getRow(r); 
			 
			 //get cell number in each row
			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
			 
			 // parse cells values of each row
			 for (int c=0;c<noOfColumns; c++)
	    	        
		        {
				 
			 HSSFCell cell= row.getCell(c);
			// System.out.println("row="+r+"###"+cell.getStringCellValue() );
			 
			 String text= cell.getStringCellValue();
			 //System.out.println("text="+text);
			 if (text.equals("width"))
			 {
				indice_width=c; 
				//System.out.println(indice_width);
			 }
			 
			 if (text.equals("height"))
			 {
				indice_height=c; 
				//System.out.println(indice_height);
			 } 
		        }
			 }
		
      int [] width=new int[rowTotal]; 
	  int [] height=new int[rowTotal]; 
		
      for ( int r=1;r<rowTotal; r++)
      
      {   
    	  HSSFRow row     = sheet.getRow(r); 
    	  
    	  //fill the width table
    	  for (int c=indice_width;c<indice_width+1; c++)
  	        
	        {
    		  HSSFCell cell= row.getCell(c);
    		  cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
    		  width[r-1]= (int)(cell.getNumericCellValue());
    		  
	        }
    	  
    	//fill the height table
    	  
    	  for (int c=indice_height;c<indice_height+1; c++)
    	        
	        {
  		  HSSFCell cell= row.getCell(c);
  		  cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
  		  height[r-1]= (int)(cell.getNumericCellValue());
  		  
	        }
      }
      
int[] sizes = new int[rowTotal];

int occ=0;
for (int i = 0; i < rowTotal; ++i) { 
	sizes[i]= width[i]*height[i];
	//System.out.println("sizes=="+sizes[i]);	
}


for (int l = 0; l < sizes.length; ++l) { 
	int val =sizes[l];
	int indice=l;
	//System.out.println("val"+i+"=="+val);	
	
	for (int j = l+1; j < sizes.length-1; ++j) 
	{
		if(val==sizes[j])
		{
			
			sizes[j]=0;
		}
		
		 if(val==0) {
		        l = indice;
		    } 
		
		
	}


	}


for (int l = 0; l < sizes.length; ++l) { 
	
	if(sizes[l]!=0)
	{
		occ++;
	}
	
}


//System.out.println("different sizes=="+occ);
		
for (int i = 0; i < rowTotal; ++i) { 
	
	CArea=CArea+sizes[i];	
}
//System.out.println("CArea=="+CArea);
	int UIwidth=0;
	int UIheight=0;
	
	UIwidth=main_launcher.Framewidth;
	UIheight=main_launcher.Frameheight;
		
	double LH=main_launcher.Layoutheight;
	double LW=main_launcher.layoutwidth;

UIArea=UIwidth*UIheight;
double layoutArea=LH*LW;

//AreaInteractivePlatform= main_launcher.Layoutheight*main_launcher.layoutwidth;
		
double Int= (1-(0.5*((Math.abs((double)(occ-1)/(double)(rowTotal-1)+ (((double)(layoutArea+(double)CArea)/(double) (2*(UIArea)))))))));		
//System.out.println("intgrli"+Int); 
value =Double.parseDouble(new DecimalFormat("##.###").format(Int));

 if (Math.abs(value)>=1)
 {
	 value=1;
 }
return 	Math.abs(value);	
		
		
		
		
		
		
		
		
		
	}

}
