package aesthetics_evaluation_tool;
import Parser.nativeApps;
import aesthetics_evaluation_tool.regularity;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import restructuring.GenerateOldMUITree;
import mainMUI.evaluate;


 /* 
 * ADDET - Aesthetics Defects DEtection Tool
 * author BessghaierNarjess
 */

    public class main_launcher {
    //	public static final String Name_File="AboutGeo.uixfile.xls";
	// specify the path for the generated file from the emulator
	public static  String data_File ;
	public static int Framewidth=0;
	public static int Frameheight=0;
	public static int layoutwidth=0;
	public static int Layoutheight=0;
	public static double nb1=0;
	public static double cohesion1,simplicity1,complexity1,unity1,repartition1,regularity1,clarity1,density1
	,grouping1,balance1,sorting1,integrality1,uniformity1;
	public static double elements1;
	public static float economy1;
	public static int btn1,button1,edit1,nbedit1,image1,imagebutton;
	public static int taille1, rows1,cols1,occ1,nature1;
	
	public static String overloaded1,difficult1,layout1,balanced1,cohesioned1;
	
	
	public static javax.swing.JTable jTableICM;
	public static javax.swing.JTable jTableILW;
	public static javax.swing.JTable jTableIM;
	public static javax.swing.JTable jTableOM;
	public static javax.swing.JTable jTableDN;
	
	 
	//remarks variables
	public static String taillestatus1,taillestatus2,taillestatus3,taillestatus4 ,taillestatus5,regularity;
	
	
	
	private static void addRowToJTable() {
		// TODO Auto-generated method stub
		//############
		//#### ICM table ######
		//#############
		 DefaultTableModel model = (DefaultTableModel) jTableICM.getModel();
	       // ArrayList<data> list = ListData();
	        Object rowData[] = new Object[4];
	        for(int i = 0; i < 1; i++)
	        {
	            rowData[0] = "Cohesion";
	            rowData[1] = "Unity";
	            rowData[2] = "Sorting";
	            rowData[3] = "Grouping";
	            
	           
	            model.addRow(rowData);
	        
	        }
	        Object rowData1[] = new Object[4];
	        for(int i = 0; i < 1; i++)
	        {
	            rowData1[0] = cohesion1;
	            rowData1[1] = unity1;
	            rowData1[2] = sorting1;
	            rowData1[3] = grouping1;
	            
	           
	            model.addRow(rowData1);
	        
	        }
	        
	        
	        
	      //############
			//#### ILW table ######
			//############# 
	        
	        
	        
	        DefaultTableModel modelILW = (DefaultTableModel) jTableILW.getModel();
		       // ArrayList<data> list = ListData();
		        Object rowDataILW[] = new Object[5];
		        for(int i = 0; i < 1; i++)
		        {
		            rowDataILW[0] = "Regularity";
		            rowDataILW[1] = "Uniformity";
		            rowDataILW[2] = "Repartition";
		            rowDataILW[3] = "Simplicity";
		            rowDataILW[4] = "Sorting";
		           
		            modelILW.addRow(rowDataILW);
		        
		        }
		        Object rowDataILW1[] = new Object[5];
		        for(int i = 0; i < 1; i++)
		        {
		            rowDataILW1[0] = regularity1;
		            rowDataILW1[1] = uniformity1;
		            rowDataILW1[2] = repartition1;
		            rowDataILW1[3] = simplicity1;
		            rowDataILW1[4] = sorting1;
		           
		            modelILW.addRow(rowDataILW1);
		        
		        }
		        
	        
	        
	        
	      //############
			//#### IM table ######
			//############# 
	        
		        DefaultTableModel modelIM = (DefaultTableModel) jTableIM.getModel();
			       // ArrayList<data> list = ListData();
			        Object rowDataIM[] = new Object[2];
			        for(int i = 0; i < 1; i++)
			        {
			            rowDataIM[0] = "Balance";
			            rowDataIM[1] = "Repartition";
			            
			           
			            modelIM.addRow(rowDataIM);
			        
			        }
			        Object rowDataIM1[] = new Object[2];
			        for(int i = 0; i < 1; i++)
			        {
			            rowDataIM1[0] = balance1;
			            rowDataIM1[1] = repartition1;
			            
			           
			            modelIM.addRow(rowDataIM1);
			        
			        }
			        
	        
	        
	      //############
			//#### OM table ######
			//############
	        
	        
			        
			        DefaultTableModel modelOM = (DefaultTableModel) jTableOM.getModel();
				       // ArrayList<data> list = ListData();
				        Object rowDataOM[] = new Object[4];
				        for(int i = 0; i < 1; i++)
				        {
				            rowDataOM[0] = "NbElements";
				            rowDataOM[1] = "Density";
				            rowDataOM[2] = "Economy";
				            rowDataOM[3] = "Integrality";
				           
				            modelOM.addRow(rowDataOM);
				        
				        }
				        Object rowDataOM1[] = new Object[4];
				        for(int i = 0; i < 1; i++)
				        {
				            rowDataOM1[0] = elements1;
				            rowDataOM1[1] = density1;
				            rowDataOM1[2] = economy1;
				            rowDataOM1[3] = integrality1;
				           
				            modelOM.addRow(rowDataOM1);
				        
				        }
	        
	        
	        
	      //############
			//#### DN table ######
			//#############
				        DefaultTableModel modelDN = (DefaultTableModel) jTableDN.getModel();
					       // ArrayList<data> list = ListData();
					        Object rowDataDN[] = new Object[1];
					        for(int i = 0; i < 1; i++)
					        {
					            rowDataDN[0] = "Clarity";
					          
					           
					            modelDN.addRow(rowDataDN);
					        
					        }
					        Object rowDataDN1[] = new Object[1];
					        for(int i = 0; i < 1; i++)
					        {
					            rowDataDN1[0] = clarity1;
					           
					            modelDN.addRow(rowDataDN1);
					        
					        }
	        
		
	}
	private static void initComponents() {
		// TODO Auto-generated method stub
		
		//############
				//#### ICM table ######
				//#############
		  jTableICM = new javax.swing.JTable();
		  
		jTableICM.setModel(new javax.swing.table.DefaultTableModel(
	            new Object [][] {

	            },
	            new String [] {
	            		"Cohesion",
	                    "Unity",
	                    "Sorting",
	                    "Grouping"
	            }
	  ));
	        evaluate.metricICM.add(jTableICM);
	        
	     
	        
	      //############
			//#### ILW table ######
			//#############    
	        
	        jTableILW = new javax.swing.JTable();
			  
			jTableILW.setModel(new javax.swing.table.DefaultTableModel(
		            new Object [][] {

		            },
		            new String [] {
		            		"Regularity",
		                    "Uniformity",
		                    "Repartition",
		                    "Simplicity",
		                    "Sorting"
		            }
		  ));
		        evaluate.metricILW.add(jTableILW);
	        
	        
	        
	      //############
			//#### IM table ######
			//#############    
		        jTableIM = new javax.swing.JTable();
				  
				jTableIM.setModel(new javax.swing.table.DefaultTableModel(
			            new Object [][] {

			            },
			            new String [] {
			            		"Balance",
			                    "Repartition",
			                    
			            }
			  ));
			        evaluate.metricIM.add(jTableIM);
		      
	        
	      //############
			//#### OM table ######
			//#############
			        jTableOM = new javax.swing.JTable();
					  
					jTableOM.setModel(new javax.swing.table.DefaultTableModel(
				            new Object [][] {

				            },
				            new String [] {
				            		"Nb-Elements",
				                    "Density",
				                    "Economy",
				                    "Integrality"
				                    
				            }
				  ));
				        evaluate.metricOM.add(jTableOM);
	        
	      //############
			//#### DN table ######
			//#############
	        
				        jTableDN = new javax.swing.JTable();
						  
						jTableDN.setModel(new javax.swing.table.DefaultTableModel(
					            new Object [][] {

					            },
					            new String [] {
					            		"Clarity",
					                   
					                    
					            }
					  ));
					        evaluate.metricDN.add(jTableDN);
	        
	}
	
	
	
	
	@SuppressWarnings("static-access")
	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub

		data_File= evaluate.xlspath.getText();
		//System.out.println(data_File);
		Framewidth= Integer.parseInt(evaluate.fwt.getText());
		Frameheight=Integer.parseInt(evaluate.fht.getText());
		layoutwidth=Integer.parseInt(evaluate.lwt.getText());
		Layoutheight=Integer.parseInt(evaluate.lht.getText());
		
		  GenerateOldMUITree tree= new  GenerateOldMUITree ();
	      try {
				tree.main(new String[]{});
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		//******CLARITY *******
		clarity CL= new clarity();
		double clarity=CL.clarity();
		clarity1=clarity;
		System.out.println("clarity"+clarity1);	
		@SuppressWarnings("static-access")
		int btn= CL.btn; // nb buttons without text
		btn1=btn;
		@SuppressWarnings("static-access")
		int image= CL.ImageView; // nb imageViews
		image1=image;
		@SuppressWarnings("static-access")
		int button= CL.nbbutton;  //nb buttons
		button1=button;
		@SuppressWarnings("static-access")
		int nbedit= CL.nbedit;  //nb edittexts
		nbedit1=nbedit;
		@SuppressWarnings("static-access")
		int edit= CL.edit;  // nb edit without hints
		edit1=edit;
		 imagebutton=CL.ImageButton;
		 
		 
		//******ECONOMY ************ 
		economy Eco= new economy();
		float economy=Eco.economy();
		economy1=economy;
		@SuppressWarnings("static-access")
		int taille=Eco.taille;
		taille1=taille;
		@SuppressWarnings("static-access")
		int occ= Eco.occ;
		occ1=occ;
		 
		
		
		//******DENSITY ************ 
		density DN= new density();
		double  density=DN.density();
		density1=density;
		
		
		//******INTEGRALITY ************ 
		integrality InT= new integrality();
		
		double integrality=InT.integrality();
		integrality1=integrality;
		
		
			
			 
			 
	   //******SORTING************ 
				Sorting SRT= new Sorting();
				double sorting=SRT.Sorting();
				 sorting1=sorting;
		 
		 
		//******SIMPLICITY ************ 
			simplicity Simp= new simplicity();
			double simplicity=Simp.simplicity();
			simplicity1=simplicity;
			 
			/*//******LAYOUT COMPLEXITY ************  
			 
			layout_complexity CMP= new layout_complexity(); 
			double complexity=CMP.layout_complexity();
			*/
			
			//******COMPLEXITY ************  
			 
			complexity CMP= new complexity(); 
			double complexity= CMP.complexity();
			complexity1=complexity;
			
			//******LAYOUT-UNIFORMITY ************ 
				Layout_Uniformity LU= new Layout_Uniformity();	
				double uniformity=LU.Layout_Uniformity();
				uniformity1=uniformity;
				
			//******UNITY ************ 
				unity Un= new unity();	
			double	 unity=Un.unity();
			unity1=unity;
				@SuppressWarnings("static-access")
				int nature=Un.occnature;
				nature1=nature;
				//******COHESION ************ 
				Cohesion CH= new Cohesion();	
				
			double	 cohesion=CH.Cohesion();
				cohesion1=cohesion;
				
		//******BALANCE ************ 
			balance BL= new balance();
			double balance=BL.balance();
			balance1=balance;

		
		//******GROUPING ************ 
			Grouping GRP= new Grouping();
			double grouping=GRP.Grouping();
			grouping1=grouping;
				
			//******REPARTITION ************ 
			repartition REP= new repartition();
		double	 repartition=REP.repartition();
			repartition1=repartition;
		
			//******NB ELEMENTS ************ 
			nb_elements nb= new nb_elements();
			double elements=nb.nb_elements();
			elements1=elements;
			nb1=elements;
			
			
			
			//******REGULARITY ************ 
			regularity RG= new regularity();
		double	regularity=RG.regularity();
		regularity1=regularity;
			int distance=RG.distance;
			int distanceX=RG.distanceX;
			int distanceY=RG.distanceY;
			@SuppressWarnings("static-access")
			int rows=RG.occX;
			rows1=rows;
			@SuppressWarnings("static-access")
			int cols=RG.occY;
			cols1=cols;
			
			//******rules ************ 
			rules r= new rules();
			String[] rule=r.rules();
	

			 initComponents();
		      addRowToJTable();
		
	  // Print the list objects in tabular format.
		 System.out.println("----------------------------------");
		 System.out.printf("%10s", " • METRICS VALUES");
		  System.out.println();
		
		  System.out.println("----------------------------------");
		  System.out.println("-----------------------------------------------------------------------------");
	 System.out.printf("%1s %5s %5s %5s %5s %5s %5s ", "UNIFORMITY", "COMPLEXITY", "SIMPLICITY", "SEQUENCE", "REGULARITY", "INTEGRALITY", "DENSITY");
	 System.out.println();  
	 System.out.println("-----------------------------------------------------------------------------");
	 
	   System.out.format(" %1s %10s %10s %10s %9s %10s %10s ",
               uniformity,  complexity,simplicity, sorting, regularity,integrality,density);
	   System.out.println(); 
	   
	   System.out.println("-----------------------------------------------------------------------------");
	 System.out.printf("%1s %5s %5s %5s %5s %5s %7s%10s" ,"ECONOMY", "CLARITY", "UNITY","COHESION","BALANCE","GROUPING","HOMOGENEITY","#ELEMENTS");
	 System.out.println(); 
	 System.out.println("-----------------------------------------------------------------------------");
	  
	 
	System.out.format(" %1s %7s %7s %7s %7s %7s %9s%10s",economy,clarity, unity,cohesion,balance,grouping,repartition,elements);
	       System.out.println();
	       System.out.println("----------------------------------");
	       System.out.printf("%1s", "• REMARKS");
			  System.out.println();
			  System.out.println("----------------------------------");
			  System.out.println("-----------------------------------------------------------------------------");
	    System.out.println("--Economy of the MUI :: you have  "+taille+"  components, with " + nature + " different types, and  "+occ+"  different sizes");
	    
	    
	    
	    if(taille>= 4 & taille<=17)
	    {   taillestatus1="Your interface is considered minimalist";
	    	System.out.println(   taillestatus1     );}
	    if(taille>= 18 & taille<=24)
	    {taillestatus2="Your interface is considered normal";
	    	System.out.println(taillestatus2);}
	    if(taille>= 25 & taille<=31)
	    {taillestatus3=" Your interface is considered normal but in risk to be overloaded";
	    	System.out.println(taillestatus3);}
	    if(taille>= 32 & taille<=45)
	    {taillestatus4="        Your interface is considered heavy ! ";
	    	System.out.println(taillestatus4);}
	    
	    if(taille<=4 & taille <=17 & density>=0.6)
	    {  taillestatus5=" Your interface is charged with different components sizes ! ";
	    	System.out.println(taillestatus5);   }
	    
	   
	  System.out.println("--Regularity of the MUI :: number of rows= "+rows+" and number of columns= " +cols);
	  //System.out.println("      - There is "+distance+" different spaces between your widgets.");
	  //System.out.println("      - "+ distanceX+" differences in rows, and "+distanceY+" different distances in columns");
	  System.out.println("--Uniformity of the MUI :: Here is your widgets repartition on the MUI");
	  System.out.println("      - UL has "+(Sorting.ULnew)+" widget(s) / "+ "UR has "+ (Sorting.URnew)+" widget(s) /"+ "LL has "+ (Sorting.LLnew)+" widget(s) /"+ "LR has "+ (Sorting.LRnew)+" widget(s) ");
	  
	  if(button>0 & btn>0)
      {
      	System.out.println("--Clarity of the MUI (button texts):: you have "+btn+ " button(s) without text(s) for " + button +" buttons");
      }
	  else  if(button>0 & btn==0) System.out.println(" --No buttons withouts texts found!");
	 
      if(image>0)
      {
      	System.out.println(" --Clarity of the MUI (icons-interactive images):: you have "+image+ " imageViews. Make sure they represent familiar icons");
      }
      
      if(imagebutton>0)
      {
      	System.out.println(" --Clarity of the MUI (icons-interactive buttons):: you have "+imagebutton+ " imageButtons. Make sure they represent familiar icons");
      }
      if(nbedit>0&edit>0)
      {
      	System.out.println(" --Clarity of the MUI (EditText hints):: you have "+edit+ " EditText(s) without hints for "+ nbedit+ " Edittexts");
      }
      else if(nbedit>0 & edit==0) System.out.println(" --No Edittexts withouts hints found!");
      if(CL.value==0)
      {
      	System.out.println("You have no buttons, items nor EditText on your MUI !");
      }
       
      
      System.out.println("-----------------------------------------------------------------------------");
      System.out.printf("%10s", "• POSSIBLE DEFECTS");
	  System.out.println();

	  String overloaded="";
	   String difficult="";
	   String layout="";
	   String balanced="";
	   String cohesioned="";
	if(!rules.OM.equals("")){  overloaded="Detected";}
	if(!rules.DN.equals("")){  difficult="Detected";}
	if(!rules.ILW.equals("")){  layout="Detected";}
	if(!rules.IM.equals("")){  balanced="Detected";}
	if(!rules.ICM.equals("")){  cohesioned="Detected";}
	overloaded1=overloaded;
	difficult1=difficult;
	layout1=layout;
	balanced1=balanced;
	cohesioned1=cohesioned;
	
	  System.out.println("-----------------------------------------------------------------------------");
	  System.out.println("----------------------------------------------");
	  System.out.printf("%1s %30s ", "Defect", "Status");
	  System.out.println();
	  System.out.println("----------------------------------------------");
	 System.out.printf("%1s %24s", "Overloaded MUI",overloaded);
	   
	   System.out.println(); 
	   
	   System.out.println("----------------------------------------------");
	   System.out.printf("%1s %24s", "Imbalanced MUI",balanced);
	   System.out.println(); 
	   System.out.println("----------------------------------------------");
	   System.out.printf("%1s%22s", "InCohesion of MUI",cohesioned);
	   System.out.println(); 
	   System.out.println("----------------------------------------------");
	   
	   System.out.printf("%1s %15s", "Incorrect layout of MUI",layout);
	   System.out.println(); 
	   System.out.println("----------------------------------------------");
	   System.out.printf("%1s%19s", "Difficult navigation",difficult);
	   System.out.println(); 
	   System.out.println("----------------------------------------------");
	  
	   
	   System.out.println(); 
	
	 
	 
	
	}
}
