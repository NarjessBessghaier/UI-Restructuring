package aesthetics_evaluation_tool;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
public class economy {

	public static float value=0;
	public static  int taille=0;
	public static int occ=0;
	public static int occf=0;
	public static int SumSize=0;
	public float economy() throws IOException, FileNotFoundException {
		// TODO Auto-generated method stub
		

int indice_width=0;
int indice_height=0;

		//main_launcher ML= new main_launcher();
    	String file=main_launcher.data_File;
    	
    	InputStream input = new FileInputStream(file);
		 HSSFWorkbook wb     = new HSSFWorkbook(input);
		 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
		 //row number
		 int rowTotal = sheet.getLastRowNum();
	
      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
          rowTotal++;
      }
    	
      for ( int r=0;r<1; r++){     
			 HSSFRow row     = sheet.getRow(r); 
			 
			 //get cell number in each row
			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
			 
			 // parse cells values of each row
			 for (int c=0;c<noOfColumns; c++)
	    	        
		        {
				 
			 HSSFCell cell= row.getCell(c);
			// System.out.println("row="+r+"###"+cell.getStringCellValue() );
			 
			 String text= cell.getStringCellValue();
			 //System.out.println("text="+text);
			 if (text.equals("width"))
			 {
				indice_width=c; 
				//System.out.println(indice_width);
			 }
			 
			 if (text.equals("height"))
			 {
				indice_height=c; 
				//System.out.println(indice_height);
			 } 
		        }
			 }
      
      int [] width=new int[rowTotal]; 
	  int [] height=new int[rowTotal]; 
		
      for ( int r=1;r<rowTotal; r++)
      
      {   
    	  HSSFRow row     = sheet.getRow(r); 
    	  
    	  //fill the width table
    	  for (int c=indice_width;c<indice_width+1; c++)
  	        
	        {
    		  HSSFCell cell= row.getCell(c);
    		  cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
    		  width[r-1]= (int)(cell.getNumericCellValue());
    		  
	        }
    	  
    	//fill the height table
    	  
    	  for (int c=indice_height;c<indice_height+1; c++)
    	        
	        {
  		  HSSFCell cell= row.getCell(c);
  		  cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
  		  height[r-1]= (int)(cell.getNumericCellValue());
  		  
	        }
      }
      
int[] sizes = new int[rowTotal];

//String[] newwidth = new String[width.length];


for (int i = 0; i < rowTotal; ++i) { 
	sizes[i]= width[i]*height[i];
	//System.out.println("sizes=="+sizes[i]);	
}

for (int i = 0; i < sizes.length; ++i) { 
	SumSize=SumSize+sizes[i];
	//System.out.println("sizes=="+sizes[i]);	
}

for (int i = 0; i < sizes.length-1; ++i) { 
	int val =sizes[i];
	int indice=i;
	//System.out.println("val"+i+"=="+val);	
	
	for (int j = i+1; j < sizes.length; ++j) 
	{
		if(val==sizes[j])
		{
			
			sizes[j]=0;
		}
		
		 if(val==0) {
		        i = indice;
		    } 
		
		
	}


	}
for (int k = 0; k < sizes.length; ++k) { 
	//System.out.println("outputsizes=="+sizes[k]);	
}

for (int l = 0; l < sizes.length; ++l) { 
	
	if(sizes[l]!=0)
	{
		occ++;
	}
	
}
taille=sizes.length-1;
occf=occ-1;

//System.out.println("you have  "+(sizes.length-1)+"  componenents, with  "+occ+"  different types");

float result = (float) 1 / (float)(occ);
//System.out.println("economy=="+result);
 value =(float) Double.parseDouble(new DecimalFormat("##.###").format(result));
      
      //String result= ""+indice_width+""+indice_height;
 if (Math.abs(value)>=1)
 {
	 value=1;
 }
return Math.abs(value);


	}
}
	


