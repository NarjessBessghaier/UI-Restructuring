package aesthetics_evaluation_tool;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class unity {
	public static double value=0;
	public static int occnature=0;
	public double unity() throws IOException, FileNotFoundException {
		// TODO Auto-generated constructor stub
		
		
		int sizes=economy.occf;
		
		
		int indice_nature=0;
		

				//main_launcher ML= new main_launcher();
		    	String file=main_launcher.data_File;
		    	
		    	InputStream input = new FileInputStream(file);
				 HSSFWorkbook wb     = new HSSFWorkbook(input);
				 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
				 //row number
				 int rowTotal = sheet.getLastRowNum();
			
		      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
		          rowTotal++;
		      }
		    	
		      for ( int r=0;r<1; r++){     
					 HSSFRow row     = sheet.getRow(r); 
					 
					 //get cell number in each row
					 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
					 
					 // parse cells values of each row
					 for (int c=0;c<noOfColumns; c++)
			    	        
				        {
						 
					 HSSFCell cell= row.getCell(c);
					// System.out.println("row="+r+"###"+cell.getStringCellValue() );
					 
					 String text= cell.getStringCellValue();
					 //System.out.println("text="+text);
					 if (text.equals("nature"))
					 {
						indice_nature=c; 
						//System.out.println(indice_width);
					 }
					 
				
				        }
					 }
		      
		      String[] nature=new String[rowTotal]; 
		      String[] nature_original=new String[rowTotal]; 
				
		      for ( int r=1;r<rowTotal; r++)
		      
		      {   
		    	  HSSFRow row     = sheet.getRow(r); 
		    	  
		    	  //fill the width table
		    	  for (int c=indice_nature;c<indice_nature+1; c++)
		  	        
			        {
		    		  HSSFCell cell= row.getCell(c);
		    		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		    		  nature[r-1]= (cell.getStringCellValue());
		    		  nature_original[r-1]= (cell.getStringCellValue());
			        }
		      }
		
	// look for different widgets types
		    	  
		    	  // look for occurrences of width
		         

		          		for (int i = 0; i < nature.length-1; ++i) { 
		          			String val =nature[i];
		          			int indice=i;
		          			//System.out.println("val"+i+"=="+val);	
		          			
		          			for (int j = i+1; j < nature.length-1; ++j) 
		          			{
		          				if(val.equals(nature[j]))
		          				{
		          					
		          					nature[j]="0";
		          				}
		          				
		          				 if(val.equals("0")) {
		          				        i = indice;
		          				    } 
		          				
		          				
		          			}


		          		}
		          		
		          		
	    					
		          		for (int k = 0; k < nature.length-1; ++k) { 
		          			//System.out.println("outputsizes in width=="+nature[k]);
		          			
		          		}
		          		
		          	
		          		for (int l = 0; l < nature.length-1; ++l) { 
		          			
		          			if(!nature[l].equals("0"))
		          			{
		          				occnature++;
		          			}
		          			
		          		}
		          		
		          		//System.out.println(occnature);
//search for the number of each object type
		          		
		          		//String occ="";
    					int somme=1;
    					int[] types=new int[occnature]; 
		          		
		          			for (int j = 0; j < occnature; ++j) 
		          			{
		          				String val=nature_original[j];
		          				
		          				for (int i =j+1; i < nature_original.length-1; ++i) 
			          			{
		          				if(val.equals(nature_original[i+1]))
		          				{
		          					somme++;
		          					//occ=occ+somme;
		          					nature_original[i+1]="0";
		          					types[j]=somme;
		          				}
		          				else if (!val.equals(nature_original[i+1]))
		          				{
		          					somme=1;
		          				
		          				}
		          				if(val.equals("0"))
		          				{
		          					
		          				}
		          				
			          			}
		          				//occ=occ+",";
		          				
		          			}
	    					//System.out.println(occ);
	    					for (int k = 0; k < occnature; ++k) { 
			          			//System.out.println("outputsizes in width=="+types[k]);
			          			
			          		}
		
		
		
		double UntForm= 1-( (double)(sizes+occnature-2)/(2*(rowTotal-1)) );
		double UntSpace= 1- ((double)(main_launcher.Layoutheight*main_launcher.layoutwidth)/(double)(main_launcher.Frameheight*main_launcher.Framewidth));
		
		//System.out.println(UntForm);
		//System.out.println(UntSpace);
		
		double value1= ((UntForm+UntSpace)/2);
	 	// System.out.println("unity"+value1); 

	value =Double.parseDouble(new DecimalFormat("##.###").format(value1));
		//System.out.println(value);
	 if (Math.abs(value)>=1)
	 {
		 value=1;
	 }
		return Math.abs(value);	
		
		
	//return value;	
		
		
		
	

}}
