package aesthetics_evaluation_tool;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class Layout_Uniformity {
	public static double value=0;
	public double Layout_Uniformity() throws IOException {
		// TODO Auto-generated constructor stub
		
		
		
		int indice_width=0;
		int indice_height=0;
		int indice_X=0;
String file=main_launcher.data_File;
    	
    	InputStream input = new FileInputStream(file);
		 HSSFWorkbook wb     = new HSSFWorkbook(input);
		 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
		 //row number
		 int rowTotal = sheet.getLastRowNum();
	
      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
          rowTotal++;
      }
    	
      for ( int r=0;r<1; r++){     
			 HSSFRow row     = sheet.getRow(r); 
			 
			 //get cell number in each row
			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
			 
			 // parse cells values of each row
			 for (int c=0;c<noOfColumns; c++)
	    	        
		        {
				 
			 HSSFCell cell= row.getCell(c);
			// System.out.println("row="+r+"###"+cell.getStringCellValue() );
			 
			 String text= cell.getStringCellValue();
			 //System.out.println("text="+text);
			 if (text.equals("width"))
			 {
				indice_width=c; 
				//System.out.println(indice_width);
			 }
			 
			 if (text.equals("height"))
			 {
				indice_height=c; 
				//System.out.println(indice_height);
			 } 
			 
			 if (text.equals("x"))
			 {
				indice_X=c; 
				//System.out.println(indice_width);
			 }
		        }
			 }
		
      int [] width=new int[rowTotal]; 
	  int [] height=new int[rowTotal]; 
		
      for ( int r=1;r<rowTotal; r++)
      
      {   
    	  HSSFRow row     = sheet.getRow(r); 
    	  
    	  //fill the width table
    	  for (int c=indice_width;c<indice_width+1; c++)
  	        
	        {
    		  HSSFCell cell= row.getCell(c);
    		  cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
    		  width[r-1]= (int)(cell.getNumericCellValue());
    		  
	        }
    	  
    	//fill the height table
    	  
    	  for (int c=indice_height;c<indice_height+1; c++)
    	        
	        {
  		  HSSFCell cell= row.getCell(c);
  		  cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
  		  height[r-1]= (int)(cell.getNumericCellValue());
  		  
	        }
      }
		
		
   // look for occurrences of width
      int occwidth=0;

      		for (int i = 0; i < width.length-1; ++i) { 
      			int val =width[i];
      			int indice=i;
      			//System.out.println("val"+i+"=="+val);	
      			
      			for (int j = i+1; j < width.length-1; ++j) 
      			{
      				if(val==width[j])
      				{
      					
      					width[j]=0;
      				}
      				
      				 if(val==0) {
      				        i = indice;
      				    } 
      				
      				
      			}


      			}
      		
      		
      		
      		
      		
      		for (int k = 0; k < width.length-1; ++k) { 
      			//System.out.println("outputsizes in width=="+width[k]);
      			
      		}
      		
      	
      		for (int l = 0; l < width.length-1; ++l) { 
      			
      			if(width[l]!=0)
      			{
      				occwidth++;
      			}
      			
      		}
      		
      		//System.out.println(occwidth);
		
		
      	// look for occurrences of height
    		int occheight=0;

    				for (int i = 0; i < height.length-1; ++i) { 
    					int val =height[i];
    					int indice=i;
    					//System.out.println("val"+i+"=="+val);	
    					
    					for (int j = i+1; j < height.length-1; ++j) 
    					{
    						if(val==height[j])
    						{
    							
    							height[j]=0;
    						}
    						
    						 if(val==0) {
    						        i = indice;
    						    } 
    						
    						
    					}


    					}
    				
    				
    				
    				
    				
    				for (int k = 0; k < height.length-1; ++k) { 
    					////System.out.println("outputsizes in Y=="+Ytab[k]);
    					
    				}
    				
    				for (int l = 0; l < height.length-1; ++l) { 
    					
    					if(height[l]!=0)
    					{
    						occheight++;
    					}
    					
    				}
    				//System.out.println(occheight);
    				////System.out.println("***********************");

		
		
		
		
		
		double M=(double)(2+2*(2*Math.sqrt(rowTotal-1)));
		//System.out.println(M);
		
		//double LU=( (((double)(occwidth+occheight+(double)((Sorting.LLnew)/2)+(double)((Sorting.LRnew)/2)+(double)(Sorting.ULnew/2)+(double)(Sorting.URnew/2)))/(double)((4*(rowTotal-1)))));
	//	double LU1 = LU - Math.floor(LU);

		double LU= 100* (  ((   occheight+occwidth+ Sorting.LLnew+Sorting.LRnew+Sorting.ULnew+Sorting.URnew  ) -M)   /(double)((6*(rowTotal-1))*M));
		//System.out.println("LU"+LU);
		value =Double.parseDouble(new DecimalFormat("##.###").format(LU));
		 if (Math.abs(value)>=1)
		 {
			 value=1;
		 }
		return Math.abs(value);
		
		
	}

}
