package DN_Practices;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import restructuring.GenerateSimilarUI;
import Recommendations.recomendations;
import aesthetics_evaluation_tool.main_launcher;

/**
 * @author bessghaiernarjess
 */
public class ImageButtonwithText {
	 public static int DiiferentMargins=0;
		public static int rowTotal;
		public static String result;
		public static  HSSFSheet sheet;
		static int indice_Row=0;
		public static HSSFRow row1 ;
		public static String	outputFileNew;
	public static int TableLength=0;
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		
		 String file=main_launcher.data_File;
	    // String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
	 	InputStream input = new FileInputStream(file);
			 HSSFWorkbook wb     = new HSSFWorkbook(input);
			 sheet = wb.getSheetAt(0); //first sheet
			 //row number
			  rowTotal = sheet.getLastRowNum();
		
	   if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
	       rowTotal++;
	   }
	 	
	   for ( int r=1;r<rowTotal; r++){     
			 HSSFRow row     = sheet.getRow(r); 
			 
			 //get cell number in each row
			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
			 
			 // parse cells values of each row
			 for (int c=0;c<1; c++)
	  	        
		        {
				 
			 HSSFCell cell= row.getCell(c);
			// System.out.println("row="+r+"###"+cell.getStringCellValue() );
			 
			String text= cell.getStringCellValue();
			
			if (text.equals("ImageButton"))
			{
				TableLength++;
				
			}
		
				 }

		        }	   
	   //System.out.println("tablelength"+TableLength );
	   String[] text=new String[TableLength]; 
	   int[] width=new int[TableLength]; 
	int k=0;
	String val="";
	Boolean test=false;
	   for ( int r=1;r<rowTotal; r++){     
			 HSSFRow row     = sheet.getRow(r); 
			 
			 //get cell number in each row
			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
			 
			 // parse cells values of each row
			 for (int c=0;c<1; c++)
		        
		        {
				 
			 HSSFCell cell= row.getCell(c);
			// System.out.println("row="+r+"###"+cell.getStringCellValue() );
			 
			String text1= cell.getStringCellValue();
			
			if (text1.equals("ImageButton"))
			{
				
				 HSSFCell celltext= row.getCell(5);  			 
		         val= celltext.getStringCellValue();
		         if (val.equals("text=\"none\"")){
		        	 k++;
						recomendations.DN.setText( recomendations.DN.getText() +"\n"+"-- ImageButton n°"+ k +" has no label!"+"\n");
						   
					test=true;	
						
					} 
		         else if (!val.equals("text=\"none\"")) {test=false;k++;}
			 }
			}
		
			 //System.out.println("k" +k);
			
		        }
	   
	   if (test)
	   {
		   GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+"Guideline#4::It’s best to pair icons with text labels, especially if the icon does not have obvious meaning :: Violated"+"\n");
		   
	   }
	   else if (test==false)
	   {
		   GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+"Guideline#4::It’s best to pair icons with text labels, especially if the icon does not have obvious meaning :: √"+"\n");
		     
	   }
	}

}
