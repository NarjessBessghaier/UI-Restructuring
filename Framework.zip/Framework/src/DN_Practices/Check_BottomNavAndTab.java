package DN_Practices;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import restructuring.GenerateSimilarUI;
import Recommendations.recomendations;
import aesthetics_evaluation_tool.main_launcher;

/**
 * @author bessghaiernarjess
 */
public class Check_BottomNavAndTab {
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
	
	int indice_nature=0;
	

	//main_launcher ML= new main_launcher();
	String file=main_launcher.data_File;
	
	InputStream input = new FileInputStream(file);
	 HSSFWorkbook wb     = new HSSFWorkbook(input);
	 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
	 //row number
	 int rowTotal = sheet.getLastRowNum();

  if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
      rowTotal++;
  }
	
  for ( int r=0;r<1; r++){     
		 HSSFRow row     = sheet.getRow(r); 
		 
		 //get cell number in each row
		 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
		 
		 // parse cells values of each row
		 for (int c=0;c<noOfColumns; c++)
    	        
	        {
			 
		 HSSFCell cell= row.getCell(c);
		// System.out.println("row="+r+"###"+cell.getStringCellValue() );
		 
		 String text= cell.getStringCellValue();
		 //System.out.println("text="+text);
		 if (text.equals("nature"))
		 {
			indice_nature=c; 
			//System.out.println(indice_width);
		 }
		 
	
	        }
		 }
  

  String[] nature=new String[rowTotal]; 
  String[] nature_original=new String[rowTotal]; 
	
  for ( int r=1;r<rowTotal; r++)
  
  {   
	  HSSFRow row     = sheet.getRow(r); 
	  
	  //fill the width table
	  for (int c=indice_nature;c<indice_nature+1; c++)
	        
        {
		  HSSFCell cell= row.getCell(c);
		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		  nature[r-1]= (cell.getStringCellValue());
		  nature_original[r-1]= (cell.getStringCellValue());
        }
  }

// look for different widgets types
	  
	  // look for occurrences of nav
      int nav=0;

      		for (int i = 0; i < nature.length-1; ++i) { 
      		
      		if (nature[i].equals("BottomNavigationView"))	
      				
      		{
      			nav++;
      		}
      			}

      		 int tab=0;

      		for (int i = 0; i < nature.length-1; ++i) { 
      		
      		if (nature[i].equals("TabLayout"))	
      				
      		{
      			tab++;
      		}
      			}
	
	
	
	if ((nav+tab)==2)
	{
		recomendations.DN.setText( recomendations.DN.getText() +"\n"+"Your MUI has a bottom navigation bar and a tab"+"\n"+
	"==> Consider removing one of them");
		
		GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+"Guideline#1::Combining bottom navigation and tabs maycause confusion :: Violated"+"\n");
	}
	
	else {
		GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+"Guideline#1::Combining bottom navigation and tabs maycause confusion :: √"+"\n");
	}
	
	
	
	}
	
	
	
	
}
