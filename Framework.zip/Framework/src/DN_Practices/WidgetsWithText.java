package DN_Practices;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import restructuring.GenerateSimilarUI;
import Recommendations.recomendations;
import aesthetics_evaluation_tool.main_launcher;

/**
 * @author bessghaiernarjess
 */
public class WidgetsWithText {
	 public static int DiiferentMargins=0;
		public static int rowTotal;
		public static String result;
		public static  HSSFSheet sheet;
		static int indice_Row=0;
		public static HSSFRow row1 ;
		public static String	outputFileNew;
	public static int TableLength=0,TableLengthB=0,TableLengthF=0;
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		 String file=main_launcher.data_File;
		    // String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
		 	InputStream input = new FileInputStream(file);
				 HSSFWorkbook wb     = new HSSFWorkbook(input);
				 sheet = wb.getSheetAt(0); //first sheet
				 //row number
				  rowTotal = sheet.getLastRowNum();
			
		   if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
		       rowTotal++;
		   }
		 	
		   for ( int r=1;r<rowTotal; r++){     
				 HSSFRow row     = sheet.getRow(r); 
				 
				 //get cell number in each row
				 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
				 
				 // parse cells values of each row
				 for (int c=0;c<1; c++)
		  	        
			        {
					 
				 HSSFCell cell= row.getCell(c);
				// System.out.println("row="+r+"###"+cell.getStringCellValue() );
				 
				String text= cell.getStringCellValue();
				
				if (text.equals("TextView"))
				{
					TableLength++;
					
				}
				if (text.equals("Button"))
				{
					TableLengthB++;
					
				}
				if (text.equals("TextField"))
				{
					TableLengthF++;
					
				}
			
					 }

			        }	   
		   //System.out.println("tablelength"+TableLength );
		   
		int k=0;
		int kB=0;
		int kF=0;
		int k1=0;
		int kB1=0;
		int kF1=0;
		int c1 = 0;
		String val="";
		Boolean testText=false;
		Boolean testButton=false;
		Boolean testFields=false;
		String [] text= new String[TableLength];
		String [] btn= new String[TableLengthB];
		String [] field= new String[TableLengthF];
		   for ( int r=1;r<rowTotal; r++){     
				 HSSFRow row     = sheet.getRow(r); 
				 
				 //get cell number in each row
				 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
				 
				 // parse cells values of each row
				 for (int c=0;c<1; c++)
			        
			        {
					 
				 HSSFCell cell= row.getCell(c);
				// System.out.println("row="+r+"###"+cell.getStringCellValue() );
				 
				String text1= cell.getStringCellValue();
				
				if (text1.equals("TextView"))
				{
					
					 HSSFCell celltext= row.getCell(5);  			 
			         val= celltext.getStringCellValue();
			         if (val.equals("text=\"none\"")){
			        	 k++;
							recomendations.DN.setText( recomendations.DN.getText() +"\n"+"-- TextView n°"+ k +" has no label!"+"\n");
							   
						testText=true;	
						text[k1]="true";
						k1++;	
						} 
			         else if (!val.equals("text=\"none\"")) 
			         {testText=false;
			         k++;
			         text[k1]="false";k1++;
			         }
			         
				 }
				
			
				 
				else if (text1.equals("Button"))
					{
						
						 HSSFCell celltext= row.getCell(5);  			 
				         val= celltext.getStringCellValue();
				         if (val.equals("text=\"none\"")){
				        	 kB++;
								recomendations.DN.setText( recomendations.DN.getText() +"\n"+"-- Button n°"+ kB +" has no label!"+"\n");
								   
							testButton=true;	
							btn[kB1]="true";kB1++;
							} 
				         else if (!val.equals("text=\"none\"")) 
				         {testButton=false;kB++;btn[kB1]="false";kB1++;}
				         
					 }
				 
				else if (text1.equals("TextField"))
					{
						kF++;
						
						 HSSFCell celltext= row.getCell(14);  			 
				         val= celltext.getStringCellValue();
				         if (val.equals("content-desc=\"none\"")){
				        	 
								recomendations.DN.setText( recomendations.DN.getText() +"\n"+"-- TextField n°"+ kF +" has no hint!"+"\n");
								   
							testFields=true;	
							field[kF1]="true";	
							 kF1++;
							} 
				         else if (!val.equals("content-desc=\"none\"")) 
				         {testFields=false;kF++;field[kF1]="false";	 kF1++;}
				        
					 }
				
					}
				 
				  
				  
				 //c1++;
				 
				//
				 
				
				
			        }
		  
		   
		// Convert String Array to List
	        List<String> list = Arrays.asList(text);
	        List<String> listB = Arrays.asList(btn);
	        List<String> listF = Arrays.asList(field);
	        
	        if(list.contains("true") || listB.contains("true")||listF.contains("true")){
	        	GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+"Guideline#5::It’s best to pair interactive widgets with text labels :: Violated"+"\n");
				   
	        }
	        
	        if(!list.contains("true") && !listB.contains("true")&& !listF.contains("true")){
	        	GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+"Guideline#5::It’s best to pair interactive widgets with text labels :: √"+"\n");
				   
	        }
		   
		   
		   
		   
		   
		   
		   
		   
		}

	

}
