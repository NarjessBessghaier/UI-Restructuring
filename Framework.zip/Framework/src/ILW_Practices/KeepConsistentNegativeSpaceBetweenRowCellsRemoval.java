package ILW_Practices;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import metaDatagenrationAfterGoldenRatio.GenerateOldGoldenTree;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import Recommendations.recomendations;
import aesthetics_evaluation_tool.main_launcher;

/**
 * @author bessghaiernarjess
 */
public class KeepConsistentNegativeSpaceBetweenRowCellsRemoval {
	public static int DiiferentMargins=0;
	public static int rowTotal;
	public static String result;
	public static  HSSFSheet sheet;
	public static HSSFWorkbook wb;
	static int indice_Row=0;
	public static String file;
	public static HSSFRow row ;
	public static String	outputFileNew;
	@SuppressWarnings("static-access")
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		
		//Consistent negative space between widgets on rows
		
int Counter=0;
int Count=1;
		file=GoldenRatioAfterRemovingElements.MTDMarginMutliplekeysGolden.outputFileNew;
		//file=MetaDataGeneration.MDMarginMutliplekeys.outputFileNew;

        //String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
    	InputStream input = new FileInputStream(file);
		  wb     = new HSSFWorkbook(input);
		 sheet = wb.getSheetAt(0); //first sheet
		 //row number
		  rowTotal = sheet.getLastRowNum();
	
      if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
          rowTotal++;
      }
		
		//add each rows widgets in a list
		
  	//add each rows widgets in a list
		
      ArrayList<Integer> list = new ArrayList<Integer>();
      Map<Integer,Integer> map = new LinkedHashMap<>();
      Map<Integer, Integer> tree = new TreeMap<Integer,Integer>();
      int counter=0;
      int c=0;
      int sum=0;
      int[] rows= new int[IM_Practices.AfterRemoval.GenerateOldGoldenTree.nbRows];
      // System.out.println ("rows"+GenerateOldGoldenTree.nbRows);  
       for ( int l=1;l<=IM_Practices.AfterRemoval.GenerateOldGoldenTree.nbRows; l++){ 
       	
       for ( int r=1;r<rowTotal; r++){     
   				  row     = sheet.getRow(r); 
   				 
   				 //get cell number in each row
   				 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
   					 HSSFCell cellrow= row.getCell(6);
   					 if (sheet.getRow(r) != null && 
   		                    sheet.getRow(r).getCell(6) != null && 
   		                   !sheet.getRow(r).getCell(6).toString().equals("")){
   					 int rowval= (int) cellrow.getNumericCellValue();
   					
   					 if (rowval==l)
   					 {
   					counter++;	 
   				//System.out.println(l + " === " + rowval);
   				 HSSFCell x= row.getCell(1);
   				HSSFCell w= row.getCell(3);
   			 if (sheet.getRow(r) != null && 
	                    sheet.getRow(r).getCell(1) != null && 
	                   !sheet.getRow(r).getCell(1).toString().equals("") && (sheet.getRow(r) != null && 
	                    sheet.getRow(r).getCell(3) != null && 
	                   !sheet.getRow(r).getCell(3).toString().equals(""))){
   				 int X= (int) x.getNumericCellValue();
   				 int W=(int) w.getNumericCellValue();
   				//System.out.println ("x "+ X);
   				//System.out.println ("w "+W);
   		    		  //list.add(X,W);
   		    		  map.put(X,W);
   		    		  tree.put(X, W);
   		    		  }
   					 
       }
       }	
       }
      int[] widths= new int[counter];
      int[] Xces= new int[counter];
      int[] XcesNew= new int[counter];
      int negativeSpace=0;
      //read(list);
      read1(map);
      
     int nbCmp= map.size();
     Counter++;
    
	if (nbCmp>=3)
	{//System.out.println("row more than 3"+l);
		// 1) V= FrameWidth-((Xcmp_1+Widthcmp_1)+Xcmp_n)
		int FrameWidth= main_launcher.Framewidth;
		//System.out.println("FrameWidth"+FrameWidth);
		 //loop and retrieve each value
		  for (Entry<Integer, Integer> entrySet : map.entrySet()) {
			  c++;
			  widths[c-1]=entrySet.getValue();
			  Xces[c-1]=entrySet.getKey();
			  XcesNew[c-1]=entrySet.getKey();
			    //System.out.println(c+"=="+entrySet.getKey() + "/" + entrySet.getValue());
			}
		  
		  
		  for(int i=0; i <widths.length;i++)
		  {
			 // System.out.println("widths" + widths[i]);
			  //System.out.println("Xces"+ Xces[i]);
			  sum=sum+widths[i];
		  }
		  
		  negativeSpace=FrameWidth-sum;
		  //System.out.println( "1 negativeSpace= "+negativeSpace);
		  //negativeSpace=negativeSpace-Xces[0];
		  //System.out.println( "2 negativeSpace= "+negativeSpace);
		  //negativeSpace=negativeSpace-(FrameWidth-(Xces[counter-1]+widths[counter-1]));
		  //System.out.println( "3 negativeSpace= "+negativeSpace);
		  negativeSpace=negativeSpace/(counter-1);
		  //System.out.println("negativeSpace"+ negativeSpace);
	//4) change the X 	  
		  //Xces[0]=key+value+negativeSpace;
		  
		  for(int r=1; r<Xces.length;r++)
		  {
			  XcesNew[r]=XcesNew[r-1]+widths[r-1]+ negativeSpace;
		  }
		  
		  for(int r=0; r<XcesNew.length;r++)
		  {
			 //System.out.println("Xces"+ XcesNew[r]);
		  }
		  int newCounter=0;
		  
		  //write new X in file
		 
		  for ( int r=1;r<rowTotal; r++){     
				  row     = sheet.getRow(r);  
					 //System.out.println("hereeee");
					          HSSFCell cell= row.getCell(1);
						     // System.out.println("row="+r+"###"+cell.getStringCellValue() );
						 
						     HSSFCell cellcol= row.getCell(6);  
						     if (sheet.getRow(r) != null && 
					                    sheet.getRow(r).getCell(1) != null && 
					                   !sheet.getRow(r).getCell(1).toString().equals("") && (sheet.getRow(r) != null && 
					                    sheet.getRow(r).getCell(6) != null && 
					                   !sheet.getRow(r).getCell(6).toString().equals(""))){
					         int R= (int) cellcol.getNumericCellValue();
					         int X= (int) cell.getNumericCellValue();
					          if (R==Counter && X==Xces[newCounter])
							 {  
                             int value=XcesNew[newCounter];
                            // System.out.println("hereeee"+value);
							 cell.setCellValue(value);
							 newCounter++;
							 
					         }
		  } 			     
		  
		  }
		  
	}
	recomendations.IM.setText( recomendations.IM.getText()+"NegativeSpace (Row"+l+")::"+Math.abs(negativeSpace)+"\n");
	
	 map.clear();	
	 widths = null;
	 Xces = null;
	 XcesNew = null;
	 negativeSpace=0;
	 c=0;
	 sum=0;
	 counter=0;
	 Count++;
	 	
	}			     
		  FileOutputStream fileOut = new FileOutputStream(file);
			
			wb.write(fileOut);
			fileOut.flush();
			fileOut.close();
			ILW_Practices.fKeepConsistentNegativeSpaceBetweenColumnsCellsRemoval col= new ILW_Practices.fKeepConsistentNegativeSpaceBetweenColumnsCellsRemoval();
			try {
				col.main(new String[]{});
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		  
	}
	 
	


private static Integer getLastId(Map<Integer, Integer> tree) {
		// TODO Auto-generated method stub
	 return ((TreeMap<Integer, Integer>) tree).lastEntry().getKey();
	}



private static void read1(Map<Integer, Integer> map) {
		// TODO Auto-generated method stub
	if(map != null && map.size() > 0){
	
	
	for (Entry<Integer, Integer> entry : map.entrySet())  
     System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue()); 
}
}




private static void read(ArrayList<Integer> list) {
	// TODO Auto-generated method stub

		
		int value=0;
		Collections.sort(list);
		Map<Integer, Integer> hm = new HashMap<Integer, Integer>(); 
  	  
        for (Integer i : list) { 
            Integer j = hm.get(i); 
            hm.put(i, (j == null) ? 1 : j + 1); 
        } 
  
        // displaying the occurrence of elements in the arraylist 
        for (Map.Entry<Integer, Integer> val : hm.entrySet()) { 
        	
        	 //System.out.println("Element " + val.getKey() + " "  + "occurs" + ": " + val.getValue() + " times");
        	// value=val.getKey();
        }
	
}
}
