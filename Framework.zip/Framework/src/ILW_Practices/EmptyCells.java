package ILW_Practices;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import Recommendations.recomendations;

/**
 * @author bessghaiernarjess
 */
public class EmptyCells {
	 public static int DiiferentMargins=0;
		public static int rowTotal;
		public static String result;
		public static  HSSFSheet sheet;
		static int indice_Row=0;
		public static HSSFRow row1 ;
		public static String	outputFileNew;
	public static int TableLength=0;
	public static int Y;
	public static int rows= IM_Practices.GenerateOldGoldenTree.nbRows;
	public static int cols= IM_Practices.ElementsOnEachColumnGolden.nbColumns;
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		recomendations.ILW.setText(recomendations.ILW.getText()+"\n"+"-- After Golden Ratio: you have "+rows+" rows and "+cols+" columns");
		
		 String file=metaDatagenrationAfterGoldenRatio.MTDMarginMutliplekeysGolden.outputFileNew;
		    // String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
		 	InputStream input = new FileInputStream(file);
				 HSSFWorkbook wb     = new HSSFWorkbook(input);
				 sheet = wb.getSheetAt(0); //first sheet
				 //row number
				  rowTotal = sheet.getLastRowNum();
			
		   if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
		       rowTotal++;
		   }
		 	
		
		   ArrayList<Integer> list = new ArrayList<Integer>(); 
		      for ( int r=1;r<rowTotal; r++){     
					 HSSFRow row     = sheet.getRow(r); 
					 
					 //get cell number in each row
					 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
			
						 HSSFCell cell= row.getCell(1);
							//System.out.println("row="+r+"###"+cell.getStringCellValue() );
						
							 int R= (int) cell.getNumericCellValue();	
							 //System.out.println(R );
					
			    		list.add(R);
				        
					 }
		   
		      Map<Integer, Integer> hm = new HashMap<Integer, Integer>(); 
		 	  int count=0;
			     for (Integer i : list) { 
			         Integer j = hm.get(i); 
			         hm.put(i, (j == null) ? 1 : j + 1); 
			     } 

			     // displaying the occurrence of elements in the arraylist 
			     for (Map.Entry<Integer, Integer> val : hm.entrySet()) { 
			     
			     	//System.out.println("Element " + val.getKey() + " "  + "occurs" + ": " + val.getValue() + " times"); 
			     	count++;
			    	 }
		        
				
			    // System.out.println(count );
		
		
			    int[]X= new int[count];
		        int c=0;
			    for (Integer i : list) { 
			         Integer j = hm.get(i); 
			         hm.put(i, (j == null) ? 1 : j + 1); 
			     } 

			     // displaying the occurrence of elements in the arraylist 
			     for (Map.Entry<Integer, Integer> val : hm.entrySet()) { 
			     
			     	//System.out.println("Element " + val.getKey() + " "  + "occurs" + ": " + val.getValue() + " times"); 
			     	X[c]=val.getKey();
			     	c++;
			    	 }
		
			     for (int i=0;i<X.length;i++)
					{
				
			    	  //System.out.println("res"+X[i] );
					}
		
			     recomendations.ILW.setText(recomendations.ILW.getText()+"\n"+"-- EMPTY CELLS");
		// loop over each row, check for inexistent X
			     String[] FinalX=null;
			     int[] RemovedX;
			     String index="";
			      for (int i=1;i<=rows;i++)
					{
					
			      for ( int r=1;r<rowTotal; r++){     
						 HSSFRow row     = sheet.getRow(r); 
						 
						 //get cell number in each row
						 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
				
							 HSSFCell cell= row.getCell(6);
								//System.out.println("row="+r+"###"+cell.getStringCellValue() );
							
								 int R= (int) cell.getNumericCellValue();
								
								 //System.out.println(R );
							if (R==i)
							{
								
								 HSSFCell cellX= row.getCell(1);
									//System.out.println("row="+r+"###"+cell.getStringCellValue() );
								
									 int xval= (int) cellX.getNumericCellValue();	
								index=index+contains(X, xval )+";";
								 HSSFCell cellY= row.getCell(2);
									//System.out.println("row="+r+"###"+cell.getStringCellValue() );
								
									 Y= (int) cellY.getNumericCellValue();
								
							}
				    		
					        
						 }
			     
			      //System.out.println("index="+i+"::"+index);
			      
			      FinalX=index.split(";"); 
			    	 
			     
		    		 recomendations.ILW.setText(recomendations.ILW.getText()+"\n"+"-- (row"+i+", Y = "+Y+")" );
		    			 for(int k1=0;k1<X.length;k1++){
					    		
					    	if (containsBoolean(FinalX,k1))	
		    				 
		    				
					    		{
					    		continue;	
					    		}
					    		else  recomendations.ILW.setText(recomendations.ILW.getText()+"\n"+" X= " + X[k1]  );
					    	 }	
			    		
			    	 
			      
		    		
		    		
			    			
			      
			      index="";
			      }  
			            
			     
			     
			//remove index from X array     
			     
			     
			     
			     
			     
			     
			     
			     
			     
			     
			     
		
	}

	private static int contains(int[] x, int targetValue) {
		// TODO Auto-generated method stub
		int index=0;
		for(int s=0; s<x.length;s++){
			if(x[s]==targetValue)
				index= s;
		}
		return index;
	
	}

	private static boolean containsBoolean(String[] finalX, int targetValue) {
		// TODO Auto-generated method stub
		
		for(int s=0; s<finalX.length;s++){
			if(Integer.parseInt(finalX[s])==targetValue)
				return true;;
		}
		return false;
	
	}

}
