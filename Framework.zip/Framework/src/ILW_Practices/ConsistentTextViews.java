package ILW_Practices;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import restructuring.GenerateSimilarUI;
import Recommendations.recomendations;
import aesthetics_evaluation_tool.main_launcher;

/**
 * @author bessghaiernarjess
 */
public class ConsistentTextViews {

	//loop through the buttonimages 
		//retrieve their text attribute
		//compute the text length along with the buttonimage width
		//compare
		
		
		 public static int DiiferentMargins=0;
			public static int rowTotal;
			public static String result;
			public static  HSSFSheet sheet;
			static int indice_Row=0;
			public static HSSFRow row1 ;
			public static String	outputFileNew;
		public static int TableLength=0;
		public static void main(String[] args) throws IOException {
			// TODO Auto-generated method stub
		
		
		 String file=main_launcher.data_File;
	    // String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
	 	InputStream input = new FileInputStream(file);
			 HSSFWorkbook wb     = new HSSFWorkbook(input);
			 sheet = wb.getSheetAt(0); //first sheet
			 //row number
			  rowTotal = sheet.getLastRowNum();
		
	   if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
	       rowTotal++;
	   }
	 	
	   for ( int r=1;r<rowTotal; r++){     
			 HSSFRow row     = sheet.getRow(r); 
			 
			 //get cell number in each row
			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
			 
			 // parse cells values of each row
			 for (int c=0;c<1; c++)
	  	        
		        {
				 
			 HSSFCell cell= row.getCell(c);
			// System.out.println("row="+r+"###"+cell.getStringCellValue() );
			 
			String text= cell.getStringCellValue();
			
			if (text.equals("TextView"))
			{
				TableLength++;
				
			}
		
				 }

		        }	   
	   //System.out.println(TableLength );
	   String[] text=new String[TableLength]; 
	   int[] width=new int[TableLength]; 
	int k=0;
	   for ( int r=1;r<rowTotal; r++){     
			 HSSFRow row     = sheet.getRow(r); 
			 
			 //get cell number in each row
			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
			 
			 // parse cells values of each row
			 for (int c=0;c<1; c++)
		        
		        {
				 
			 HSSFCell cell= row.getCell(c);
			// System.out.println("row="+r+"###"+cell.getStringCellValue() );
			 
			String text1= cell.getStringCellValue();
			
			if (text1.equals("TextView"))
			{
				
				 
		         HSSFCell cellw= row.getCell(3);  			 
		         int width1= (int) cellw.getNumericCellValue();
		         width[k]=width1;
		         k++;
			}
		
				 }
			
		        }	   
	   int[] length=new int[TableLength];	
	   int w1; 
	   
	   
	   // compute number of different text widths
	   
	   int numOfDifferentVals = 0;

	    ArrayList<Integer> diffNum = new ArrayList<>();

	    for(int i=0; i<TableLength; i++){
	        if(!diffNum.contains(width[i])){
	            diffNum.add(width[i]);
	        }
	    }

	    if(diffNum.size()==1){
	            numOfDifferentVals = 0;
	    }
	    else{
	          numOfDifferentVals = diffNum.size();
	        } 

	    if (numOfDifferentVals>5 )	
		{
			recomendations.ILW.setText(recomendations.ILW.getText()+"\n"+"-- You have " +numOfDifferentVals+" different TextViews widths"+"\n"
		+"==> TextViews elements seem not to be consistent in width"+"\n");
			GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+ "Guideline#7::Don’t shrink text size in order to fit a text label on a single line :: Violated"+"\n");
		}
		else 
		{
			recomendations.ILW.setText(recomendations.ILW.getText()+"\n"+"-- You have " +numOfDifferentVals+"  different TextViews width"+"\n"
		+"==> your textViews are consistent in width"+"\n");
			GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+ "Guideline#7::Don’t shrink text size in order to fit a text label on a single line :: √"+"\n");
		}
		
	   
	   
	}

}
