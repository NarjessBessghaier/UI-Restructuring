package ILW_Practices;

import restructuring.GenerateSimilarUI;
import Recommendations.recomendations;

/**
 * @author bessghaiernarjess
 */
public class TryTabsOrNavigationDrawer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	int length=	DN_Practices.Check_ButtonImageWidthAndText.TableLength;
		
	if (length<3 )	
	{
		recomendations.ILW.setText(recomendations.ILW.getText()+"\n"+"-- You have only " +length+" destination(s) in your navigation bar"+"\n"
	+"==> Consider adding " +(3-length) +" destinations"+"\n");
		GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+ "Guideline#6::Don’t use more than 5 destinations and fewer than 3 destinations :: Violated"+"\n");
	}
	else if (length>3 )	
	{
		recomendations.ILW.setText(recomendations.ILW.getText()+"\n"+"-- You have " +length+"destinations in your navigation bar"+"\n"
	+"==> Consider removing " +(length-5) +" destinations"+"\n");
		GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+ "Guideline#6::Don’t use more than 5 destinations and fewer than 3 destinations :: Violated"+"\n");
	}
	
	else 
		{GenerateSimilarUI.text1.setText(GenerateSimilarUI.text1.getText()+"\n"+ "Guideline#6::Don’t use more than 5 destinations and fewer than 3 destinations :: √"+"\n");
		}
	}

}
