package Assist;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import aesthetics_evaluation_tool.main_launcher;

/**
 * @author bessghaiernarjess
 */
public class CountDifferences {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		
		
String file="/Users/bessghaiernarjess/Documents/Ph.D_Thesis/main/step3-RESTRUCTURING/DumpFiles/Pinterest/"
		+ "dump_8844269163014256240.uixOriginalFile.xls12345678RestructuredFile.xls";
      	
      	InputStream input = new FileInputStream(file);
  		 HSSFWorkbook wb     = new HSSFWorkbook(input);
  		 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
  		 //row number
  		 int rowTotal = sheet.getLastRowNum();
  	
        if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
            rowTotal++;
        }
        ArrayList<Integer> listX = new ArrayList<Integer>();
        ArrayList<Integer> listY = new ArrayList<Integer>();
        ArrayList<Integer> listR = new ArrayList<Integer>();
        ArrayList<Integer> listC = new ArrayList<Integer>();
        ArrayList<Integer> listMLD = new ArrayList<Integer>();
        ArrayList<Integer> listMBD = new ArrayList<Integer>();
        ArrayList<Integer> listMTD = new ArrayList<Integer>();
        ArrayList<Integer> listMRD = new ArrayList<Integer>();
        for ( int r=1;r<rowTotal; r++){     
  			
        	     HSSFRow row     = sheet.getRow(r);  
				 HSSFCell cellrow= row.getCell(6);
				 if (sheet.getRow(r) != null && 
		                    sheet.getRow(r).getCell(6) != null && 
		                   !sheet.getRow(r).getCell(6).toString().equals("")
		                   ){
				 double Row= cellrow.getNumericCellValue();
				 listR.add((int)Row);
				 }
				 
				 HSSFRow col     = sheet.getRow(r);  
				 HSSFCell cellcol= col.getCell(7);
				 if (sheet.getRow(r) != null && 
		                    sheet.getRow(r).getCell(7) != null && 
		                   !sheet.getRow(r).getCell(7).toString().equals("")
		                   ){
				 double Col= cellcol.getNumericCellValue();
				 listC.add((int)Col);
				 }
				 
				 HSSFRow X     = sheet.getRow(r); 
				
				 HSSFCell cellX= X.getCell(8);
				 if (sheet.getRow(r) != null && 
		                    sheet.getRow(r).getCell(8) != null && 
		                   !sheet.getRow(r).getCell(8).toString().equals("")
		                   ){
				 double x= cellX.getNumericCellValue();
				 listX.add((int)x);
				 }
				 
				 HSSFRow Y     = sheet.getRow(r);
				
				 HSSFCell cellY= Y.getCell(9);
				 if (sheet.getRow(r) != null && 
		                    sheet.getRow(r).getCell(9) != null && 
		                   !sheet.getRow(r).getCell(9).toString().equals("")
		                   ){
				 double y= cellY.getNumericCellValue();
				 listY.add((int)y);
				 }
				 
				 HSSFRow mld     = sheet.getRow(r);  
				 HSSFCell cellmld= mld.getCell(10);
				 if (sheet.getRow(r) != null && 
		                    sheet.getRow(r).getCell(10) != null && 
		                   !sheet.getRow(r).getCell(10).toString().equals("")
		                   ){
				 double MLD= cellmld.getNumericCellValue();
				 listMLD.add((int)MLD);
				 }
				 HSSFRow mrd     = sheet.getRow(r);  
				 HSSFCell cellmrd= mrd.getCell(11);
				 if (sheet.getRow(r) != null && 
		                    sheet.getRow(r).getCell(11) != null && 
		                   !sheet.getRow(r).getCell(11).toString().equals("")
		                   ){
				 double MRD= cellmrd.getNumericCellValue();
				 listMRD.add((int)MRD);
				 }
				
				 HSSFRow mbd     = sheet.getRow(r); 
				
				 HSSFCell cellmbd= mbd.getCell(12);
				 if (sheet.getRow(r) != null && 
		                    sheet.getRow(r).getCell(12) != null && 
		                   !sheet.getRow(r).getCell(12).toString().equals("")
		                   ){
				 double MBD= cellmbd.getNumericCellValue();
				 listMBD.add((int)MBD);
				 }
				 
				 HSSFRow mtd     = sheet.getRow(r);  
				 HSSFCell cellmtd= mtd.getCell(13);
				 if (sheet.getRow(r) != null && 
		                    sheet.getRow(r).getCell(13) != null && 
		                   !sheet.getRow(r).getCell(13).toString().equals("")
		                   ){
				 double MTD= cellmtd.getNumericCellValue();
				 listMTD.add((int)MTD);
				 }
  			 }
        
        //System.out.println("Rows"+"\n");
		getValues(listR);
	//	System.out.println("Cols"+"\n");
		getValues(listC);
		//System.out.println("X"+"\n");
		getValues(listX);
		//System.out.println("Y"+"\n");
		getValues(listY);
		//System.out.println("MLD"+"\n");
		getValues(listMLD);
		//System.out.println("MRD"+"\n");
		getValues(listMRD);
		//System.out.println("MBD"+"\n");
		getValues(listMBD);
		//System.out.println("MTD"+"\n");
		getValues(listMTD);
	}
	
private static void getValues(ArrayList<Integer> listR) {
		
		Map<Integer, Integer> hm = new HashMap<Integer, Integer>(); 
  	  
        for (Integer i : listR) { 
            Integer j = hm.get(i); 
            hm.put(i, (j == null) ? 1 : j + 1); 
        }  
        for (Map.Entry<Integer, Integer> val : hm.entrySet()) { 
        	
        	//System.out.println("Element " + val.getKey() + " "  + "occurs" + ": " + val.getValue() + " times");
        	
        	
        }
        Set<Integer> set = new HashSet<Integer>(listR);
        System.out.println("size == "+set.size());
	}

}
