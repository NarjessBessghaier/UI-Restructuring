package OM_Practices;

import java.awt.Color;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JCheckBox;

import org.apache.commons.lang3.math.NumberUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;

import com.google.common.base.Strings;
import com.microsoft.schemas.office.visio.x2012.main.CellType;

import Parser.DeleteEmptyRows;
import Parser.DeleteEmptyRowsFile;
import aesthetics_evaluation_tool.main_launcher;
import restructuring.ElementsOnEachQuadrant;

/**
 * @author bessghaiernarjess
 */
public class ManualRemovalElements {
	public static int emptinessLR=0;
	static HSSFRow row;
	public static int rowTotal,size;
	
	public static String result;
	public static  HSSFSheet sheet;
	static int indice_Y=0;
	public static final Color Gold = new Color(255,204,51);
	public static String	outputFileNew;
	public static FileOutputStream fileOut;
	public static int nbRows,i1,i11,i12,i13;;
    public static 	String[] Componentname,textAttribute,Finalvals,Finalvals1,Finalvals2,Finalvals3;
    public static 	int[] yAttribute,heightAttribute;
	@SuppressWarnings("static-access")
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		//this class aims to remove elements manually depending on user choice
		// loop through the map of each quadrant
		// Retrieve the value of each selected key represented by i (checkbox)
	
		
	//============================
    //================LR (map4)========
	//============================
		i1=0;
		for (Entry<JCheckBox, ArrayList<String>> entry : ElementsOnEachQuadrant.map4.entrySet()) {
		    //System.out.println(entry.getKey() + " = " + entry.getValue());
		    
		    if (entry.getKey().isSelected())
		    {
		    	i1++;
		    }
		}
	
		//============================
	    //================LL (map4)========
		//============================
		
		 i11=0;
		for (Entry<JCheckBox, ArrayList<String>> entry : ElementsOnEachQuadrant.map3.entrySet()) {
		    //System.out.println(entry.getKey() + " = " + entry.getValue());
		    
		    if (entry.getKey().isSelected())
		    {
		    	i11++;
		    }
		}
	
		//============================
	    //================UR (map4)========
		//============================
		 i12=0;
		for (Entry<JCheckBox, ArrayList<String>> entry : ElementsOnEachQuadrant.map2.entrySet()) {
		    //System.out.println(entry.getKey() + " = " + entry.getValue());
		    
		    if (entry.getKey().isSelected())
		    {
		    	i12++;
		    }
		}
		
		//============================
	    //================UL (map4)========
		//============================
		 i13=0;
		for (Entry<JCheckBox, ArrayList<String>> entry : ElementsOnEachQuadrant.map.entrySet()) {
		    //System.out.println(entry.getKey() + " = " + entry.getValue());
		    
		    if (entry.getKey().isSelected())
		    {
		    	i13++;
		    }
		}
		
		
		size=i1+i11+i12+i13;
		
		if (size==0)
		{
			IM_Practices.BalanceWeightOfElements bl = new IM_Practices.BalanceWeightOfElements();
			bl.main(args);
		}
		else {
		
		//System.out.println("size agale =" +size);
		Componentname= new String[size];
		textAttribute=new String[size];
		heightAttribute= new int[size];
		yAttribute= new int[size];
		//System.out.println(i1);	
	
		String text ="";
		for (Entry<JCheckBox, ArrayList<String>> entry : ElementsOnEachQuadrant.map4.entrySet()) {
		    //System.out.println(entry.getKey() + " = " + entry.getValue());
		    
		    if (entry.getKey().isSelected())
		    {
		    	text=text+entry.getKey().getText()+";";
		    
		    }
		}
		
		//System.out.println("LR text map4 "+text);	
		
		if (text.length()!=0){
		String value;
		 Finalvals=null;
		
		Finalvals=text.split(";");
		
		for(int k=0;k<Finalvals.length;k++){
			
			//System.out.println(Finalvals[k]); 
			value=Finalvals[k];
			//get the component name
			Pattern p = Pattern.compile("([a-zA-Z]+)\\:");
		    Matcher m = p.matcher(value);
		    while(m.find())
		    {
		    	Componentname[k]=m.group(1);
		    }
		
		    // get the text attribute
		    
		   // Pattern p1 = Pattern.compile("\"(.*?)\""); // a pattern to remove the text""
		    Pattern p1 = Pattern.compile("\\:(text=\"(.*?)+\")");
		    Matcher m1 = p1.matcher(value);
		    while(m1.find())
		    {
		    	textAttribute[k]=m1.group(1);
		    }
		
		    Pattern p11 = Pattern.compile("\\:y=([0-9]+)\\:");
		    Matcher m11 = p11.matcher(value);
		    while(m11.find())
		    {
		    	yAttribute[k]=Integer.parseInt(m11.group(1));
		    }
		    Pattern p111 = Pattern.compile("\\:height=([0-9]+)");
		    Matcher m111 = p111.matcher(value);
		    while(m111.find())
		    {
		    	heightAttribute[k]=Integer.parseInt(m111.group(1));
		    }
		    //y pattern= \\:(y=[0-9]+)
		    //height pattern = \\:(height=[0-9]+)
		    
				 }	  
		
         /*   for(int k=0;k<i1;k++){
			
			//System.out.println("name LR "+Componentname[k]); 
			}
		
            for(int k=0;k<i1;k++){
    			
    		//System.out.println("text LR "+textAttribute[k]); 
    			}
            for(int k=0;k<i1;k++){
    			
    		//	System.out.println("y LR "+yAttribute[k]); 
    			}
    		
                for(int k=0;k<i1;k++){
        			
        		System.out.println("height LR "+heightAttribute[k]); 
        			}*/
		}
            

          //============================
            //================LL (map3)========
        	//============================
        	
        		//System.out.println(i1);	
        	
        		String text1 ="";
        		for (Entry<JCheckBox, ArrayList<String>> entry : ElementsOnEachQuadrant.map3.entrySet()) {
        		    //System.out.println(entry.getKey() + " = " + entry.getValue());
        		    
        		    if (entry.getKey().isSelected())
        		    {
        		    	text1=text1+entry.getKey().getText()+";";
        		    
        		    }
        		}
        		
        		
        		if (text1.length()!=0){
        		String value;
        		Finalvals1=null;
        		
        		Finalvals1=text1.split(";");
        		
               
        		
        		//test if LR is empty
        		if (i1==0){
        		
        		for(int k=0;k<Finalvals1.length;k++){
        			
        			//System.out.println(Finalvals[k]); 
        			value=Finalvals1[k];
        			//get the component name
        			Pattern p = Pattern.compile("([a-zA-Z]+)\\:");
        		    Matcher m = p.matcher(value);
        		    while(m.find())
        		    {
        		    	Componentname[k]=m.group(1);
        		    }
        		
        		    // get the text attribute
        		    
        		    Pattern p1 = Pattern.compile("\\:(text=\"(.*?)+\")");
        		    Matcher m1 = p1.matcher(value);
        		    while(m1.find())
        		    {
        		    	textAttribute[k]=m1.group(1);
        		    }
        		
        		    Pattern p11 = Pattern.compile("\\:y=([0-9]+)\\:");
        		    Matcher m11 = p11.matcher(value);
        		    while(m11.find())
        		    {
        		    	yAttribute[k]=Integer.parseInt(m11.group(1));
        		    }
        		    Pattern p111 = Pattern.compile("\\:height=([0-9]+)");
        		    Matcher m111 = p111.matcher(value);
        		    while(m111.find())
        		    {
        		    	heightAttribute[k]=Integer.parseInt(m111.group(1));
        		    }
        		    
        				 }	  
        		}
        		
        		//if LR is not empty
        		else if (i1!=0){
            		int s=i1;
            		for(int k=0;k<Finalvals1.length;k++){
            			
            			//System.out.println(Finalvals[k]); 
            			value=Finalvals1[k];
            			//get the component name
            			Pattern p = Pattern.compile("([a-zA-Z]+)\\:");
            		    Matcher m = p.matcher(value);
            		    while(m.find())
            		    {
            		    	Componentname[s]=m.group(1);
            		    	
            		    }
            		
            		    // get the text attribute
            		    
            		    Pattern p1 = Pattern.compile("\\:(text=\"(.*?)+\")");
            		    Matcher m1 = p1.matcher(value);
            		    while(m1.find())
            		    {
            		    	textAttribute[s]=m1.group(1);
            		    }
            		    Pattern p11 = Pattern.compile("\\:y=([0-9]+)\\:");
            		    Matcher m11 = p11.matcher(value);
            		    while(m11.find())
            		    {
            		    	yAttribute[s]=Integer.parseInt(m11.group(1));
            		    }
            		    Pattern p111 = Pattern.compile("\\:height=([0-9]+)");
            		    Matcher m111 = p111.matcher(value);
            		    while(m111.find())
            		    {
            		    	heightAttribute[s]=Integer.parseInt(m111.group(1));
            		    }
            		    s++;
            		    
            		    
            				 }	  
            		}
  
        		
                    /*for(int k=0;k<i1+i11;k++){
        			
        			System.out.println("name LL  "+Componentname[k]); 
        			}
        		
                    for(int k=0;k<i1+i11;k++){
            			
            		System.out.println("text LL "+textAttribute[k]); 
            			}
            */
            
        		}
            
            
        		//============================
        	    //================UR (map2)========
        		//============================   
            
            
            

        		String text11 ="";
        		for (Entry<JCheckBox, ArrayList<String>> entry : ElementsOnEachQuadrant.map2.entrySet()) {
        		    //System.out.println(entry.getKey() + " = " + entry.getValue());
        		    
        		    if (entry.getKey().isSelected())
        		    {
        		    	text11=text11+entry.getKey().getText()+";";
        		    
        		    }
        		}
            
            
            
		//System.out.println(text11);	
        		
        		
        		if (text11.length()!=0){
        	
        		String value;
        		Finalvals2=null;
        		
        		Finalvals2=text11.split(";");
        		
        		//======= CASE1: 00======
    			
        		
        		if (i1==0 &i11==0){
        			//System.out.println("======= CASE1: 00======");
        		for(int k=0;k<Finalvals2.length;k++){
        			
        			//System.out.println(Finalvals[k]); 
        			value=Finalvals2[k];
        			//get the component name
        			Pattern p = Pattern.compile("([a-zA-Z]+)\\:");
        		    Matcher m = p.matcher(value);
        		    while(m.find())
        		    {
        		    	Componentname[k]=m.group(1);
        		    }
        		
        		    // get the text attribute
        		    
        		    Pattern p1 = Pattern.compile("\\:(text=\"(.*?)+\")");
        		    Matcher m1 = p1.matcher(value);
        		    while(m1.find())
        		    {
        		    	textAttribute[k]=m1.group(1);
        		    }
        		
        		    Pattern p11 = Pattern.compile("\\:y=([0-9]+)\\:");
        		    Matcher m11 = p11.matcher(value);
        		    while(m11.find())
        		    {
        		    	yAttribute[k]=Integer.parseInt(m11.group(1));
        		    }
        		    Pattern p111 = Pattern.compile("\\:height=([0-9]+)");
        		    Matcher m111 = p111.matcher(value);
        		    while(m111.find())
        		    {
        		    	heightAttribute[k]=Integer.parseInt(m111.group(1));
        		    }
        		    
        				 }	  
        		}
        		
        		//======= CASE1: 10======
    			
        		
        		else if (i1!=0 &i11==0){
        			int s=i1;
        			//System.out.println("======= CASE1: 10======");
            		for(int k=0;k<Finalvals2.length;k++){
            			
            			//System.out.println(Finalvals[k]); 
            			value=Finalvals2[k];
            			//get the component name
            			Pattern p = Pattern.compile("([a-zA-Z]+)\\:");
            		    Matcher m = p.matcher(value);
            		    while(m.find())
            		    {
            		    	Componentname[s]=m.group(1);
            		    }
            		
            		    // get the text attribute
            		    
            		    Pattern p1 = Pattern.compile("\\:(text=\"(.*?)+\")");
            		    Matcher m1 = p1.matcher(value);
            		    while(m1.find())
            		    {
            		    	textAttribute[s]=m1.group(1);
            		    }
            		
            		    Pattern p11 = Pattern.compile("\\:y=([0-9]+)\\:");
            		    Matcher m11 = p11.matcher(value);
            		    while(m11.find())
            		    {
            		    	yAttribute[s]=Integer.parseInt(m11.group(1));
            		    }
            		    Pattern p111 = Pattern.compile("\\:height=([0-9]+)");
            		    Matcher m111 = p111.matcher(value);
            		    while(m111.find())
            		    {
            		    	heightAttribute[s]=Integer.parseInt(m111.group(1));
            		    }
            		    s++;
            				 }	  
            		}
  
        		
                  //======= CASE1: 01======
    			
        		
        		else	 if (i1==0 &i11!=0){
        			int s=i11;
        			//System.out.println("======= CASE1: 01======");
            		for(int k=0;k<Finalvals2.length;k++){
            			
            			//System.out.println(Finalvals[k]); 
            			value=Finalvals2[k];
            			//get the component name
            			Pattern p = Pattern.compile("([a-zA-Z]+)\\:");
            		    Matcher m = p.matcher(value);
            		    while(m.find())
            		    {
            		    	Componentname[s]=m.group(1);
            		    }
            		
            		    // get the text attribute
            		    
            		    Pattern p1 = Pattern.compile("\\:(text=\"(.*?)+\")");
            		    Matcher m1 = p1.matcher(value);
            		    while(m1.find())
            		    {
            		    	textAttribute[s]=m1.group(1);
            		    }
            		
            		    Pattern p11 = Pattern.compile("\\:y=([0-9]+)\\:");
            		    Matcher m11 = p11.matcher(value);
            		    while(m11.find())
            		    {
            		    	yAttribute[s]=Integer.parseInt(m11.group(1));
            		    }
            		    Pattern p111 = Pattern.compile("\\:height=([0-9]+)");
            		    Matcher m111 = p111.matcher(value);
            		    while(m111.find())
            		    {
            		    	heightAttribute[s]=Integer.parseInt(m111.group(1));
            		    }
            		    s++;
            		    
            				 }	  
            		}
  
        		
                    //======= CASE1: 11======
    			
        		
        		else if (i1!=0 &i11!=0){
        			int s=i1+i11;
        			//System.out.println("======= CASE1: 11======");
            		for(int k=0;k<Finalvals2.length;k++){
            			
            			//System.out.println(Finalvals[k]); 
            			value=Finalvals2[k];
            			//get the component name
            			Pattern p = Pattern.compile("([a-zA-Z]+)\\:");
            		    Matcher m = p.matcher(value);
            		    while(m.find())
            		    {
            		    	Componentname[s]=m.group(1);
            		    }
            		
            		    // get the text attribute
            		    
            		    Pattern p1 = Pattern.compile("\\:(text=\"(.*?)+\")");
            		    Matcher m1 = p1.matcher(value);
            		    while(m1.find())
            		    {
            		    	textAttribute[s]=m1.group(1);
            		    }
            		
            		    Pattern p11 = Pattern.compile("\\:y=([0-9]+)\\:");
            		    Matcher m11 = p11.matcher(value);
            		    while(m11.find())
            		    {
            		    	yAttribute[s]=Integer.parseInt(m11.group(1));
            		    }
            		    Pattern p111 = Pattern.compile("\\:height=([0-9]+)");
            		    Matcher m111 = p111.matcher(value);
            		    while(m111.find())
            		    {
            		    	heightAttribute[s]=Integer.parseInt(m111.group(1));
            		    }
            		    s++;
            				 }	  
            		}
  

                    /*for(int k=0;k<i1+i11+i12;k++){
        			
        			System.out.println("name UR  "+Componentname[k]); 
        			}
        		
                    
                    for(int k=0;k<i1+i11+i12;k++){
            			
            		System.out.println("text UR "+textAttribute[k]); 
            			}*/
            
            
        		}
            
            
            
        		//============================
        	    //================UL (map1)========
        		//============================
            
            
        		String text111 ="";
        		for (Entry<JCheckBox, ArrayList<String>> entry : ElementsOnEachQuadrant.map.entrySet()) {
        		   // System.out.println(entry.getKey() + " = " + entry.getValue());
        		    
        		    if (entry.getKey().isSelected())
        		    {
        		    	text111=text111+entry.getKey().getText()+";";
        		    
        		    }
        		}
        		
        	//	System.out.println("Final vals UL= "+text111);
            
        		if (text111.length()!=0){
            		String value;
            		Finalvals3=null;
            		
            		Finalvals3=text111.split(";");
            		
            		//=======CASE1=============
            		if (i1==0 & i11!=0 & i12!=0)
            		
            	{
            			int s=i11+i12; 
            		for(int k=0;k<Finalvals3.length;k++){
            			
            			
            			value=Finalvals3[k];
            			//get the component name
            			Pattern p = Pattern.compile("([a-zA-Z]+)\\:");
            		    Matcher m = p.matcher(value);
            		    while(m.find())
            		    {
            		    	Componentname[s]=m.group(1);
            		    }
            		
            		    // get the text attribute
            		    
            		    Pattern p1 = Pattern.compile("\\:(text=\"(.*?)+\")");
            		    Matcher m1 = p1.matcher(value);
            		    while(m1.find())
            		    {
            		    	textAttribute[s]=m1.group(1);
            		    }
            		
            		    Pattern p11 = Pattern.compile("\\:y=([0-9]+)\\:");
            		    Matcher m11 = p11.matcher(value);
            		    while(m11.find())
            		    {
            		    	yAttribute[s]=Integer.parseInt(m11.group(1));
            		    }
            		    Pattern p111 = Pattern.compile("\\:height=([0-9]+)");
            		    Matcher m111 = p111.matcher(value);
            		    while(m111.find())
            		    {
            		    	heightAttribute[s]=Integer.parseInt(m111.group(1));
            		    }
            		    s++;
            		    
            				 }	  
             
                
            		}
            		
            		
            		//=======CASE2=============
            		if (i1!=0 & i11==0 & i12!=0)
            		
            	{int s=i1+i12;
            		
            		for(int k=0;k<Finalvals3.length;k++){
            			
            			 
            			value=Finalvals3[k];
            			//get the component name
            			Pattern p = Pattern.compile("([a-zA-Z]+)\\:");
            		    Matcher m = p.matcher(value);
            		    while(m.find())
            		    {
            		    	Componentname[s]=m.group(1);
            		    }
            		
            		    // get the text attribute
            		    
            		    Pattern p1 = Pattern.compile("\\:(text=\"(.*?)+\")");
            		    Matcher m1 = p1.matcher(value);
            		    while(m1.find())
            		    {
            		    	textAttribute[s]=m1.group(1);
            		    }
            		
            		    Pattern p11 = Pattern.compile("\\:y=([0-9]+)\\:");
            		    Matcher m11 = p11.matcher(value);
            		    while(m11.find())
            		    {
            		    	yAttribute[s]=Integer.parseInt(m11.group(1));
            		    }
            		    Pattern p111 = Pattern.compile("\\:height=([0-9]+)");
            		    Matcher m111 = p111.matcher(value);
            		    while(m111.find())
            		    {
            		    	heightAttribute[s]=Integer.parseInt(m111.group(1));
            		    }
            		    s++;
            		    
            				 }	  
             
                
            		}
            		
            		//=======CASE3=============
            		if (i1!=0 & i11!=0 & i12==0)
            		
            	{int s=i1+i11;
            		
            		for(int k=0;k<Finalvals3.length;k++){
            			
            			 
            			value=Finalvals3[k];
            			//get the component name
            			Pattern p = Pattern.compile("([a-zA-Z]+)\\:");
            		    Matcher m = p.matcher(value);
            		    while(m.find())
            		    {
            		    	Componentname[s]=m.group(1);
            		    }
            		
            		    // get the text attribute
            		    
            		    Pattern p1 = Pattern.compile("\\:(text=\"(.*?)+\")");
            		    Matcher m1 = p1.matcher(value);
            		    while(m1.find())
            		    {
            		    	textAttribute[s]=m1.group(1);
            		    }
            		
            		    Pattern p11 = Pattern.compile("\\:y=([0-9]+)\\:");
            		    Matcher m11 = p11.matcher(value);
            		    while(m11.find())
            		    {
            		    	yAttribute[s]=Integer.parseInt(m11.group(1));
            		    }
            		    Pattern p111 = Pattern.compile("\\:height=([0-9]+)");
            		    Matcher m111 = p111.matcher(value);
            		    while(m111.find())
            		    {
            		    	heightAttribute[s]=Integer.parseInt(m111.group(1));
            		    }
            		    s++;
            		    
            				 }	  
             
                
            		}
            		
            		
            		//=======CASE4=============
            		if (i1!=0 & i11!=0 & i12!=0)
            		
            	{
            			int s=i1+i11+i12;
            		for(int k=0;k<Finalvals3.length;k++){
            			
            			 
            			value=Finalvals3[k];
            			//get the component name
            			Pattern p = Pattern.compile("([a-zA-Z]+)\\:");
            		    Matcher m = p.matcher(value);
            		    while(m.find())
            		    {
            		    	Componentname[s]=m.group(1);
            		    }
            		
            		    // get the text attribute
            		    
            		    Pattern p1 = Pattern.compile("\\:(text=\"(.*?)+\")");
            		    Matcher m1 = p1.matcher(value);
            		    while(m1.find())
            		    {
            		    	textAttribute[s]=m1.group(1);
            		    }
            		
            		    Pattern p11 = Pattern.compile("\\:y=([0-9]+)\\:");
            		    Matcher m11 = p11.matcher(value);
            		    while(m11.find())
            		    {
            		    	yAttribute[s]=Integer.parseInt(m11.group(1));
            		    }
            		    Pattern p111 = Pattern.compile("\\:height=([0-9]+)");
            		    Matcher m111 = p111.matcher(value);
            		    while(m111.find())
            		    {
            		    	heightAttribute[s]=Integer.parseInt(m111.group(1));
            		    }
            		    s++;
            		    
            				 }	  
             
                
            		}
            		
            		
            		//=======CASE5=============
            		if (i1==0 & i11==0 & i12==0)
            		
            	{
            		
            		for(int k=0;k<Finalvals3.length;k++){
            			
            			
            			value=Finalvals3[k];
            			//get the component name
            			Pattern p = Pattern.compile("([a-zA-Z]+)\\:");
            		    Matcher m = p.matcher(value);
            		    while(m.find())
            		    {
            		    	Componentname[k]=m.group(1);
            		    }
            		
            		    // get the text attribute
            		    
            		    Pattern p1 = Pattern.compile("\\:(text=\"(.*?)+\")");
            		    Matcher m1 = p1.matcher(value);
            		    while(m1.find())
            		    {
            		    	textAttribute[k]=m1.group(1);
            		    }
            		
            		    Pattern p11 = Pattern.compile("\\:y=([0-9]+)\\:");
            		    Matcher m11 = p11.matcher(value);
            		    while(m11.find())
            		    {
            		    	yAttribute[k]=Integer.parseInt(m11.group(1));
            		    }
            		    Pattern p111 = Pattern.compile("\\:height=([0-9]+)");
            		    Matcher m111 = p111.matcher(value);
            		    while(m111.find())
            		    {
            		    	heightAttribute[k]=Integer.parseInt(m111.group(1));
            		    }
            		    
            				 }	  
             
                
            		}
            		
            		
            		
            		//=======CASE6=============
            		if (i1==0 & i11==0 & i12!=0)
            		
            	{
            			int s=i12; 
            		for(int k=0;k<Finalvals3.length;k++){
            			
            			
            			value=Finalvals3[k];
            			//get the component name
            			Pattern p = Pattern.compile("([a-zA-Z]+)\\:");
            		    Matcher m = p.matcher(value);
            		    while(m.find())
            		    {
            		    	Componentname[s]=m.group(1);
            		    }
            		
            		    // get the text attribute
            		    
            		    Pattern p1 = Pattern.compile("\\:(text=\"(.*?)+\")");
            		    Matcher m1 = p1.matcher(value);
            		    while(m1.find())
            		    {
            		    	textAttribute[s]=m1.group(1);
            		    }
            		
            		    Pattern p11 = Pattern.compile("\\:y=([0-9]+)\\:");
            		    Matcher m11 = p11.matcher(value);
            		    while(m11.find())
            		    {
            		    	yAttribute[s]=Integer.parseInt(m11.group(1));
            		    }
            		    Pattern p111 = Pattern.compile("\\:height=([0-9]+)");
            		    Matcher m111 = p111.matcher(value);
            		    while(m111.find())
            		    {
            		    	heightAttribute[s]=Integer.parseInt(m111.group(1));
            		    }
            		   s++;
            		    
            				 }	  
             
                
            		}
            		
            		
            		//=======CASE7=============
            		if (i1!=0 & i11==0 & i12==0)
            		
            	{
            			int s=i1; 
            		for(int k=0;k<Finalvals3.length;k++){
            			
            			
            			value=Finalvals3[k];
            			//get the component name
            			Pattern p = Pattern.compile("([a-zA-Z]+)\\:");
            		    Matcher m = p.matcher(value);
            		    while(m.find())
            		    {
            		    	Componentname[s]=m.group(1);
            		    }
            		
            		    // get the text attribute
            		    
            		    Pattern p1 = Pattern.compile("\\:(text=\"(.*?)+\")");
            		    Matcher m1 = p1.matcher(value);
            		    while(m1.find())
            		    {
            		    	textAttribute[s]=m1.group(1);
            		    }
            		
            		    Pattern p11 = Pattern.compile("\\:y=([0-9]+)\\:");
            		    Matcher m11 = p11.matcher(value);
            		    while(m11.find())
            		    {
            		    	yAttribute[s]= Integer.parseInt(m11.group(1));
            		    }
            		    Pattern p111 = Pattern.compile("\\:height=([0-9]+)");
            		    Matcher m111 = p111.matcher(value);
            		    while(m111.find())
            		    {
            		    	heightAttribute[s]=Integer.parseInt(m111.group(1));
            		    }
            		   s++;
            		    
            				 }	  
             
                
            		}
            		
            		
            		//=======CASE8=============
            		if (i1==0 & i11!=0 & i12==0)
            		
            	{
            			int s=i11; 
            		for(int k=0;k<Finalvals3.length;k++){
            			
            			
            			value=Finalvals3[k];
            			//get the component name
            			Pattern p = Pattern.compile("([a-zA-Z]+)\\:");
            		    Matcher m = p.matcher(value);
            		    while(m.find())
            		    {
            		    	Componentname[s]=m.group(1);
            		    }
            		
            		    // get the text attribute
            		    
            		    Pattern p1 = Pattern.compile("\\:(text=\"(.*?)+\")");
            		    Matcher m1 = p1.matcher(value);
            		    while(m1.find())
            		    {
            		    	textAttribute[s]=m1.group(1);
            		    }
            		
            		    Pattern p11 = Pattern.compile("\\:y=([0-9]+)\\:");
            		    Matcher m11 = p11.matcher(value);
            		    while(m11.find())
            		    {
            		    	yAttribute[s]=Integer.parseInt(m11.group(1));
            		    }
            		    Pattern p111 = Pattern.compile("\\:height=([0-9]+)");
            		    Matcher m111 = p111.matcher(value);
            		    while(m111.find())
            		    {
            		    	heightAttribute[s]=Integer.parseInt(m111.group(1));
            		    }
            		   s++;
            		    
            				 }	  
             
                
            		}
            		
            		
            		
            		
            		
            		
            		
        		}
            		
            		
            		
            		
            		
            		
            		
        		/*for(int k=0;k<size;k++){
        			
        			System.out.println("name ::"+Componentname[k]); 
        			}*/
        		
                    for(int k=0;k<textAttribute.length;k++){
            			
                		 if(textAttribute[k]==null)
                		 {textAttribute[k]="";
                			}
                		
                    }
                  /*  for(int k=0;k<size;k++){
            			
            		System.out.println("text :: "+textAttribute[k]); 
            			}
            
                    for(int k=0;k<size;k++){
            			
                		System.out.println("y :: "+yAttribute[k]); 
                			}
                    for(int k=0;k<size;k++){
            			
                		System.out.println("height :: "+heightAttribute[k]); 
                			}*/
            
            //###################
		//########REMOVAL######
		//####################
		
		
            String file=main_launcher.data_File;
             //String file="/Users/bessghaiernarjess/Desktop/about.uixFinalOutputFile.xls";
         	InputStream input = new FileInputStream(file);
     		 HSSFWorkbook wb     = new HSSFWorkbook(input);
     		 sheet = wb.getSheetAt(0); //first sheet
     		 //row number
     		  rowTotal = sheet.getLastRowNum();
     	
           if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
               rowTotal++;
           }
         	
           for ( int r=1;r<rowTotal; r++){     
     			 HSSFRow row     = sheet.getRow(r); 
     			 
     			 HSSFCell cell= row.getCell(0);

     			 String textname= cell.getStringCellValue();
     			
     			HSSFCell cell1= row.getCell(5);

    			 String textatt= cell1.getStringCellValue();
    			 
    			 
    			 HSSFCell cell2= row.getCell(1);

     			 double x= cell2.getNumericCellValue();
     			 
     			HSSFCell cell3= row.getCell(2);

    			 int y=(int) cell3.getNumericCellValue();
    			 String newy=Integer.toString(y);
    			 HSSFCell cell4= row.getCell(3);

     			 double w= cell4.getNumericCellValue();
     			 
     			HSSFCell cell5= row.getCell(4);

    			 int h= (int) cell5.getNumericCellValue();
    			 String newh=Integer.toString(h);
     			 //System.out.println("text="+text);
     			 
    			 for (int g=0;g<size;g++)
    			 {  //System.out.println("am in!!");
    				 /*if(textAttribute[g]==null)
    				 {*/
    				/* int valy = NumberUtils.toInt(yAttribute[g]);
    				 int valh=  NumberUtils.toInt(heightAttribute[g]);*/
    				 //System.out.println("somme "+valy+"et"+valh+"est" +valy+valh);
    				if (textname.equals(Componentname[g]) & textatt.equals(textAttribute[g]) &
    					y==(yAttribute[g]) & h==(heightAttribute[g]) ) 
    				{   //System.out.println("am here!!");
    					cell.setCellType(Cell.CELL_TYPE_BLANK);
    					cell1.setCellType(Cell.CELL_TYPE_BLANK);
    					cell2.setCellType(Cell.CELL_TYPE_BLANK);
    					cell3.setCellType(Cell.CELL_TYPE_BLANK);
    					cell4.setCellType(Cell.CELL_TYPE_BLANK);
    					cell5.setCellType(Cell.CELL_TYPE_BLANK);
    					

    				//}
    				 }
    	
    			 }
     	    		
    				//System.out.println("am outside!!");
     		        }
     			   
             
           outputFileNew =file+"LRremoved1.xls";
   		
   	    fileOut = new FileOutputStream(outputFileNew);
   		
   		wb.write(fileOut);
   		fileOut.flush();
   		fileOut.close();
		
   		
   		
   		DeleteEmptyElementsRows deleteFile= new DeleteEmptyElementsRows();
		deleteFile.main(args);
   		
   		DeleteFiles files= new DeleteFiles();
   		files.main(args);
   		

		emptinessLR=1;
		}
	}
}
