package OM_Practices;

import java.io.File;



/**
 * @author bessghaiernarjess
 */
public class DeleteFiles {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File LR = new File(ManualRemovalElements.outputFileNew);
		LR.delete();
		
		File LRd = new File(DeleteEmptyElementsRows.outputFileNew1);
		LRd.delete();
		
		/*File LRd1 = new File(GenerateNewMUITree.outputFileNew);
		LRd1.delete();*/
		
	}

}
