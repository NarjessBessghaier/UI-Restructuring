package restructuring;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*; 
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.border.TitledBorder;

import mainMUI.ViewUIComponent;

/**
 * @author bessghaiernarjess
 */
public class restructuringMain extends JPanel implements ItemListener, ActionListener{
	JPanel restructure;
	public static final Color Gold = new Color(255,204,51);
	public static JButton generateDesign; 
	public static JPanel holderTree,p11,p21,p31,p41;
	Font font11;
	public static JPanel UpperLeft,UpperRight,LowerLeft,LowerRight;
	 
	static JPanel design;
	
	public restructuringMain() {
		// TODO Auto-generated constructor stub
		restructure= new JPanel();
		
		 TitledBorder titledBorder = BorderFactory.createTitledBorder("Generate New Design");
		 restructure.setBorder(titledBorder);
		 
	}

	@SuppressWarnings("static-access")
	public void getContent() throws IOException 
	{
		
		 font11 = new Font("Lora", Font.BOLD, 12);
		 Font font = new Font("Courier", Font.BOLD,12); 
		 restructure.setLayout(new BoxLayout(restructure,BoxLayout.Y_AXIS));
		
		 restructure.setBackground(Gold);
		
		  generateDesign= new JButton("Remove unecessary elements");
		 generateDesign.setBackground(Color.black);
		 generateDesign.setForeground(Color.white);
		 generateDesign.setContentAreaFilled(true);
		 generateDesign.setOpaque(true);
		 generateDesign.setFont(font11); 
		 generateDesign.setEnabled(false);
		 generateDesign.setForeground(Color.black);
		 generateDesign.addActionListener(this);
		 restructure.add(generateDesign, BorderLayout.CENTER);
		  
	       
	   	    design= new JPanel();
			design.setLayout(new BoxLayout(design, BoxLayout.Y_AXIS));
			design.setPreferredSize(new Dimension(200, 350));
			design.setBackground(Gold);
			
			JTabbedPane tp1=new JTabbedPane(); 
			UIManager.put("TabbedPane.unselectedForeground", Color.blue);
			UIManager.put("TabbedPane.selectedBackground", Color.red);
			 UpperLeft=new JPanel(); 
			 UpperLeft .setBackground(Gold);
			 UpperRight=new JPanel();
			 UpperRight.setBackground(Gold);
			 LowerLeft=new JPanel();
			 LowerLeft .setBackground(Gold);
			 LowerRight=new JPanel();
			 LowerRight.setBackground(Gold);
			  /*   p11=new JPanel();  
			    p11.add(UpperLeft);  
			     p21=new JPanel(); 
			    p21.add(UpperRight);
			     p31=new JPanel();  
			    p31.add(LowerLeft);
			     p41=new JPanel(); 
			    p41.add(LowerRight);*/
			    
			 tp1.setBounds(50,50,10,10);  
		
			    JScrollPane scroll1 = new JScrollPane();
			    scroll1.setViewportView(UpperLeft);
			    JScrollPane scroll2 = new JScrollPane();
			    scroll2.setViewportView(UpperRight);
			    JScrollPane scroll3 = new JScrollPane();
			    scroll3.setViewportView(LowerLeft);
			    JScrollPane scroll4 = new JScrollPane();
			    scroll4.setViewportView(LowerRight);
			   
			    tp1.add("UpperLeft",UpperLeft);
			    tp1.add("UpperRight",UpperRight);
			    tp1.add("LowerLeft",LowerLeft);
			    tp1.add("LowerRight",LowerRight);
			    
			    for (int i = 0; i < tp1.getTabCount(); i++) {
			        tp1.getComponentAt(i).setBackground(Gold);
			       
			    }
			    
		design.add(tp1);
		
 
	     	 restructure.add(design);
			 JPanel p7= new JPanel();
			 Font f= new Font("Lora",Font.LAYOUT_LEFT_TO_RIGHT, 8);
			 String t="<html><body>You can keep all elements unchecked!</body></html>";		
	         JLabel text= new JLabel(t);
	         text.setFont(f);
			 p7.setBackground(Gold);
	         p7.add(text);
			 restructure.add(p7);
	}
	
	
	public Component getGUI() {
		// TODO Auto-generated method stub
		return restructure;
	}



	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
		
	}

	@SuppressWarnings("static-access")
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

		ElementsOnEachQuadrant tree1= new ElementsOnEachQuadrant();
		try {
			tree1.getContent();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		tree1.add(tree1.getGUI());
		tree1.setBackground(Color.white);
		tree1.setPreferredSize(new Dimension(300, 270));
		UpperLeft.add(tree1);
		
		ElementsOnEachQuadrant tree2= new ElementsOnEachQuadrant();
		try {
			tree2.getContent1();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		tree2.add(tree2.getGUI1());
		tree2.setBackground(Color.white);
		tree2.setPreferredSize(new Dimension(300, 270));
		UpperRight.add(tree2);
		
		ElementsOnEachQuadrant tree3= new ElementsOnEachQuadrant();
		try {
			tree3.getContent2();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		tree3.add(tree3.getGUI2());
		tree3.setBackground(Color.white);
		tree3.setPreferredSize(new Dimension(300, 270));
		LowerLeft.add(tree3);
		
		ElementsOnEachQuadrant tree4= new ElementsOnEachQuadrant();
		try {
			tree4.getContent3();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		tree4.add(tree4.getGUI3());
		tree4.setBackground(Color.white);
		tree4.setPreferredSize(new Dimension(300, 270));
		LowerRight.add(tree4);
		
		UpperLeft.revalidate();
		UpperRight.revalidate();
		LowerLeft.revalidate();
		LowerRight.revalidate();
		design.revalidate();
		
	}
	
	
}
