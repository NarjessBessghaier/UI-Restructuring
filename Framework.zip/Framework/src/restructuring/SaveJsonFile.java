package restructuring;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

/**
 * @author bessghaiernarjess
 */
public class SaveJsonFile implements ActionListener{
	private JButton SimilarUI;
	
	 public SaveJsonFile(JButton SimilarUI){
          this.SimilarUI=SimilarUI;

                   }
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
