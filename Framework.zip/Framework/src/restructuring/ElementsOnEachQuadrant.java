package restructuring;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import restructuring.MUIElementsTree.checkedElements;
import aesthetics_evaluation_tool.main_launcher;

/**
 * @author bessghaiernarjess
 */
public class ElementsOnEachQuadrant extends JPanel{
	 public static final Color Gold = new Color(255,204,51);
	 static JScrollPane scrollPane,scrollPane1,scrollPane2,scrollPane3;
	  int indice_nature=0;
		int indice_text=0;
		int indice_height=0;
		int indice_y=0;
		public static HSSFRow row;
		public static double value=0;
		public static String [] nature, text, heighttab;
		public static int []	YTab;
		
		int sizemap1,sizemap2,sizemap3,sizemap4;
		public static JCheckBox checkBox,checkBox4;
		public static String[] map4text; 
		public static int k4=0;
		 public static HashMap<JCheckBox, ArrayList<String>> map = new HashMap<>();
		 public static HashMap<JCheckBox, ArrayList<String>> map4 = new HashMap<>();
		 public static HashMap<JCheckBox, ArrayList<String>> map2 = new HashMap<>();
		 public static HashMap<JCheckBox, ArrayList<String>> map3 = new HashMap<>();
		 
		 public static ArrayList<String> listLR = new ArrayList<>();
		public void getContent() throws IOException 
		{
			
				
				String file=main_launcher.data_File;
		      	
		      	InputStream input = new FileInputStream(file);
		  		 HSSFWorkbook wb     = new HSSFWorkbook(input);
		  		 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
		  		 //row number
		  		 int rowTotal = sheet.getLastRowNum();
		  	
		        if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
		            rowTotal++;
		        }
		      	
		        for ( int r=0;r<1; r++){     
		  			 HSSFRow row     = sheet.getRow(r); 
		  			 
		  			 //get cell number in each row
		  			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
		  			 
		  			 // parse cells values of each row
		  			 for (int c=0;c<noOfColumns; c++)
		  	    	        
		  		        {
		  				 
		  			 HSSFCell cell= row.getCell(c);
		  			// System.out.println("row="+r+"###"+cell.getStringCellValue() );
		  			 
		  			 String text= cell.getStringCellValue();
		  			 //System.out.println("text="+text);
		  			 if (text.equals("nature"))
		  			 {
		  				 indice_nature=c; 
		  				//System.out.println(indice_width);
		  			 }
		  			 
		  			 if (text.equals("text"))
		  			 {
		  				indice_text=c; 
		  				//System.out.println(indice_height);
		  			 } 
		  			 
		  			 if (text.equals("height"))
		  			 {
		  				indice_height=c; 
		  				//System.out.println(indice_height);
		  			 }
		  			if (text.equals("y"))
		  			 {
		  				indice_y=c; 
		  				//System.out.println(indice_height);
		  			 }
		  		        }
		  			 }
		        
		         nature=new String[rowTotal]; 
		  	   text=new String[rowTotal]; 
		  	 heighttab=new String[rowTotal];
		  	YTab=new int[rowTotal];
		  	  //fill nature table
		        for ( int r=1;r<rowTotal; r++)
		        
		        {   
		      	   row     = sheet.getRow(r); 
		      	  
		      	  //fill the nature table
		      	  for (int c=indice_nature;c<indice_nature+1; c++)
		    	        
		  	        {
		      		  HSSFCell cell= row.getCell(c);
		      		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		      		  nature[r-1]= (cell.getStringCellValue());
		      		  
		  	        }
		      	  
		      	//fill the text table
		      	  
		      	  for (int c=indice_text;c<indice_text+1; c++)
		      	        
		  	        {
		    		  HSSFCell cell= row.getCell(c);
		    		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		    		  text[r-1]= (cell.getStringCellValue());
		    		  
		  	        }
	            //fill the height table
		      	  
		      	  for (int c=indice_height;c<indice_height+1; c++)
		      	        
		  	        {
		    		  HSSFCell cell= row.getCell(c);
		    		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		    		  heighttab[r-1]= (cell.getStringCellValue());
		    		  
		  	        }
		      	  
//fill the y table
		      	  
		      	  for (int c=indice_y;c<indice_y+1; c++)
		      	        
		  	        {
		    		  HSSFCell cell= row.getCell(c);
		    		  //cell.setCellType(HSSFCell.CELL_TYPE_STRING);
		    		  YTab[r-1]= (int) (cell.getNumericCellValue());
		    		  
		  	        }
		      	  
		        }
		       
		        
		        for (int i = 0; i < nature.length-1; ++i) { 
		        	
		        //	System.out.println("nature::"+nature[i]);	
		        }
		        
		        for (int i = 0; i < text.length-1; ++i) { 
		        	
		        	//System.out.println("text::"+text[i]);	
		        }
                for (int i = 0; i < heighttab.length-1; ++i) { 
		        	
		        	//System.out.println("height::"+heighttab[i]);	
		        }
		        int newheight=main_launcher.Frameheight/2;
			      int newwidth=main_launcher.Framewidth/2;    
			
		        //=============UL===========
	        	 //==========================
			     JPanel inner= new JPanel(new GridLayout(0, 1));
					 inner.setPreferredSize(new Dimension(100, 270));
					 inner.setBackground(Color.white);
					
				
				String cmp;
				String height;
				int YValue;
				String t;
				String blank="::";
				String h="height=";
				String y1="y=";
				
		        for (int i = 1; i < rowTotal; i++) {
		        	HSSFRow row1    = sheet.getRow(i); 
		        	
		            StringBuilder sb = new StringBuilder();
		            ArrayList<String> listUL = new ArrayList<>();
		            //test
		            HSSFCell X1=row1.getCell(1);
		        	int  x= (int) X1.getNumericCellValue();
		            
		        	HSSFCell Y1=row1.getCell(2);
		        	int  y= (int) Y1.getNumericCellValue();
		        	 
		        	
		            if (y<newheight & x<newwidth)
		            { cmp=nature[i];
		            height=heighttab[i];
		            
		            listUL.add(cmp);
		            t=text[i];
		            YValue=YTab[i];
		            sb.append(cmp).append(blank).append(t).append(blank).append(y1).append(YValue).append(blank).append(h).append(height);
		            
		            checkBox = new JCheckBox(sb.toString().trim());
		            checkBox.setName("CheckBox" + t);
		            //System.out.println(checkBox);
		            checkBox.addActionListener(new checkedElementsUL());
		            map.put(checkBox, listUL);
		            inner.add(checkBox);}}
		        
		        if(map.size()>=1 & map.size()<2)
		        {
		        	 inner.setPreferredSize(new Dimension(300, 50));
		        }
		        else
		       
		        if(map.size()>=3 & map.size()<8)
		        {
		        	inner.setPreferredSize(new Dimension(300, 150));
		        }
		        
		        else  if(map.size()>=9 & map.size()<14)
		        {
		        	inner.setPreferredSize(new Dimension(300, 270));
		        }
		        
		        else  if(map.size()>=15 & map.size()<20)
		        {
		        	inner.setPreferredSize(new Dimension(300, 350));
		        }
		        
		        else  if(map.size()>=21 & map.size()<26)
		        {
		        	inner.setPreferredSize(new Dimension(300, 400));
		        }
		        else  if(map.size()>=27 & map.size()<31)
		        {
		        	inner.setPreferredSize(new Dimension(300, 450));
		        }
		        else  if(map.size()>=32 & map.size()<37)
		        {
		        	inner.setPreferredSize(new Dimension(300, 500));
		        }
		        else  if(map.size()>=38 & map.size()<43)
		        {
		        	inner.setPreferredSize(new Dimension(300, 550));
		        }
		        else  if(map.size()>=44 & map.size()<50)
		        {
		        	inner.setPreferredSize(new Dimension(300, 600));
		        }
		        else  inner.setPreferredSize(new Dimension(300, 1000));
		        scrollPane = new JScrollPane(inner);
		        scrollPane.setPreferredSize(new Dimension(300,270));
		        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED); 	 
		        	 
		}      	 
		    
		public void getContent1() throws IOException 
		{
			          //=============UR===========
			        	 //========================== 
		        	 
			
			String file=main_launcher.data_File;
	      	
	      	InputStream input = new FileInputStream(file);
	  		 HSSFWorkbook wb     = new HSSFWorkbook(input);
	  		 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
	  		 //row number
	  		 int rowTotal = sheet.getLastRowNum();
	  	
	        if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
	            rowTotal++;
	        }
	      	
	        for ( int r=0;r<1; r++){     
	  			 HSSFRow row     = sheet.getRow(r); 
	  			 
	  			 //get cell number in each row
	  			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
	  			 
	  			 // parse cells values of each row
	  			 for (int c=0;c<noOfColumns; c++)
	  	    	        
	  		        {
	  				 
	  			 HSSFCell cell= row.getCell(c);
	  			// System.out.println("row="+r+"###"+cell.getStringCellValue() );
	  			 
	  			 String text= cell.getStringCellValue();
	  			 //System.out.println("text="+text);
	  			 if (text.equals("nature"))
	  			 {
	  				 indice_nature=c; 
	  				//System.out.println(indice_width);
	  			 }
	  			 
	  			 if (text.equals("text"))
	  			 {
	  				indice_text=c; 
	  				//System.out.println(indice_height);
	  			 }
	  			 if (text.equals("height"))
	  			 {
	  				indice_height=c; 
	  				//System.out.println(indice_height);
	  			 }
	  			if (text.equals("y"))
	  			 {
	  				indice_y=c; 
	  				//System.out.println(indice_height);
	  			 }
	  		        }
	  			 }
	        
	         nature=new String[rowTotal]; 
	  	   text=new String[rowTotal]; 
	  	 heighttab=new String[rowTotal];
	  	 YTab= new int[rowTotal];
	  	  //fill nature table
	        for ( int r=1;r<rowTotal; r++)
	        
	        {   
	      	   row     = sheet.getRow(r); 
	      	  
	      	  //fill the nature table
	      	  for (int c=indice_nature;c<indice_nature+1; c++)
	    	        
	  	        {
	      		  HSSFCell cell= row.getCell(c);
	      		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
	      		  nature[r-1]= (cell.getStringCellValue());
	      		  
	  	        }
	      	  
	      	//fill the text table
	      	  
	      	  for (int c=indice_text;c<indice_text+1; c++)
	      	        
	  	        {
	    		  HSSFCell cell= row.getCell(c);
	    		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
	    		  text[r-1]= (cell.getStringCellValue());
	    		  
	  	        }
	      	//fill the height table
	      	  
	      	  for (int c=indice_height;c<indice_height+1; c++)
	      	        
	  	        {
	    		  HSSFCell cell= row.getCell(c);
	    		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
	    		  heighttab[r-1]= (cell.getStringCellValue());
	    		  
	  	        }
	      	//fill the y table
	      	  
	      	  for (int c=indice_y;c<indice_y+1; c++)
	      	        
	  	        {
	    		  HSSFCell cell= row.getCell(c);
	    		 // cell.setCellType(HSSFCell.CELL_TYPE_STRING);
	    		  YTab[r-1]=(int) (cell.getNumericCellValue());
	    		  
	  	        }
	      	  
	        }
	       
	        
	        for (int i = 0; i < nature.length-1; ++i) { 
	        	
	        //	System.out.println("nature::"+nature[i]);	
	        }
	        
	        for (int i = 0; i < text.length-1; ++i) { 
	        	
	        	//System.out.println("text::"+text[i]);	
	        }
			
	        int newheight=main_launcher.Frameheight/2;
		      int newwidth=main_launcher.Framewidth/2; 
		        	 
		      JPanel inner1= new JPanel(new GridLayout(0, 1));
				 inner1.setPreferredSize(new Dimension(100, 270));
				 inner1.setBackground(Color.white);
		        	// HashMap<JCheckBox, ArrayList<String>> map2 = new HashMap<>();
						JCheckBox checkBox2;
						String height;
						int YValue;
					String cmp2;
					String t2;
					String blank2="::";
					String h="height=";
					String y1="y=";
					
			        for (int i2 = 1; i2 < rowTotal; i2++) {
			        	HSSFRow row2   = sheet.getRow(i2); 
			        	
						
			            StringBuilder sb = new StringBuilder();
			            ArrayList<String> listUR = new ArrayList<>();
			            //test
			            HSSFCell X1=row2.getCell(1);
			           
			        	 int  x= (int) X1.getNumericCellValue();
			            
			        	 HSSFCell Y1=row2.getCell(2);
			        	
			        	 int  y= (int) Y1.getNumericCellValue();
			        	  
		          
		          if (y<newheight & x>=newwidth)
		  			{
		            	cmp2=nature[i2];
		            	listUR.add(cmp2);
		                t2=text[i2];
		                height=heighttab[i2];
		                YValue=YTab[i2];
		                sb.append(cmp2).append(blank2).append(t2).append(blank2).append(y1).append(YValue).append(blank2).append(h).append(height);
			            
		              
			            
		            checkBox2 = new JCheckBox(sb.toString().trim());
		            checkBox2.setName("CheckBox" + t2);
		            checkBox2.addActionListener(new checkedElementsUR());
		            map2.put(checkBox2, listUR);
		           inner1.add(checkBox2);
		  			}}
			        if(map2.size()>=1 & map2.size()<4)
			        {
			        	 inner1.setPreferredSize(new Dimension(300, 10));
			        }
			        else
			        if(map2.size()>=5 & map2.size()<8)
			        {
			        	inner1.setPreferredSize(new Dimension(300, 150));
			        }
			        
			        else  if(map2.size()>=9 & map2.size()<14)
			        {
			        	inner1.setPreferredSize(new Dimension(300, 270));
			        }
			        
			        else  if(map2.size()>=15 & map2.size()<20)
			        {
			        	inner1.setPreferredSize(new Dimension(300, 350));
			        }
			        
			        else  if(map2.size()>=21 & map2.size()<26)
			        {
			        	inner1.setPreferredSize(new Dimension(300, 400));
			        }
			        else  if(map2.size()>=27 & map2.size()<31)
			        {
			        	inner1.setPreferredSize(new Dimension(300, 450));
			        }
			        else  if(map2.size()>=32 & map2.size()<37)
			        {
			        	inner1.setPreferredSize(new Dimension(300, 500));
			        }
			        else  if(map2.size()>=38 & map2.size()<43)
			        {
			        	inner1.setPreferredSize(new Dimension(300, 550));
			        }
			        else  if(map2.size()>=44 & map2.size()<50)
			        {
			        	inner1.setPreferredSize(new Dimension(300, 600));
			        }
			        else  inner1.setPreferredSize(new Dimension(300, 1000));
			        scrollPane1 = new JScrollPane(inner1);
			        scrollPane1.setPreferredSize(new Dimension(300,270));
			        scrollPane1.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
			        scrollPane1.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		}
		
		
		public void getContent2() throws IOException 
		{
		          //=============LL===========
		        	 //==========================
			
			String file=main_launcher.data_File;
	      	
	      	InputStream input = new FileInputStream(file);
	  		 HSSFWorkbook wb     = new HSSFWorkbook(input);
	  		 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
	  		 //row number
	  		 int rowTotal = sheet.getLastRowNum();
	  	
	        if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
	            rowTotal++;
	        }
	      	
	        for ( int r=0;r<1; r++){     
	  			 HSSFRow row     = sheet.getRow(r); 
	  			 
	  			 //get cell number in each row
	  			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
	  			 
	  			 // parse cells values of each row
	  			 for (int c=0;c<noOfColumns; c++)
	  	    	        
	  		        {
	  				 
	  			 HSSFCell cell= row.getCell(c);
	  			// System.out.println("row="+r+"###"+cell.getStringCellValue() );
	  			 
	  			 String text= cell.getStringCellValue();
	  			 //System.out.println("text="+text);
	  			 if (text.equals("nature"))
	  			 {
	  				 indice_nature=c; 
	  				//System.out.println(indice_width);
	  			 }
	  			 
	  			 if (text.equals("text"))
	  			 {
	  				indice_text=c; 
	  				//System.out.println(indice_height);
	  			 } 
	  			 if (text.equals("height"))
	  			 {
	  				indice_height=c; 
	  				//System.out.println(indice_height);
	  			 }
	  			if (text.equals("y"))
	  			 {
	  				indice_y=c; 
	  				//System.out.println(indice_height);
	  			 }
	  			
	  		        }
	  			 }
	        
	         nature=new String[rowTotal]; 
	  	   text=new String[rowTotal]; 
	  	 heighttab=new String[rowTotal];
	  	 YTab= new int[rowTotal];
	  	  //fill nature table
	        for ( int r=1;r<rowTotal; r++)
	        
	        {   
	      	   row     = sheet.getRow(r); 
	      	  
	      	  //fill the nature table
	      	  for (int c=indice_nature;c<indice_nature+1; c++)
	    	        
	  	        {
	      		  HSSFCell cell= row.getCell(c);
	      		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
	      		  nature[r-1]= (cell.getStringCellValue());
	      		  
	  	        }
	      	  
	      	//fill the text table
	      	  
	      	  for (int c=indice_text;c<indice_text+1; c++)
	      	        
	  	        {
	    		  HSSFCell cell= row.getCell(c);
	    		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
	    		  text[r-1]= (cell.getStringCellValue());
	    		  
	  	        }
	      	//fill the height table
	      	  
	      	  for (int c=indice_height;c<indice_height+1; c++)
	      	        
	  	        {
	    		  HSSFCell cell= row.getCell(c);
	    		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
	    		  heighttab[r-1]= (cell.getStringCellValue());
	    		  
	  	        }
	      	//fill the y table
	      	  
	      	  for (int c=indice_y;c<indice_y+1; c++)
	      	        
	  	        {
	    		  HSSFCell cell= row.getCell(c);
	    		 // cell.setCellType(HSSFCell.CELL_TYPE_STRING);
	    		  YTab[r-1]= (int) (cell.getNumericCellValue());
	    		  
	  	        }
	      	  
	        }
	       
	        
	        for (int i = 0; i < nature.length-1; ++i) { 
	        	
	        //	System.out.println("nature::"+nature[i]);	
	        }
	        
	        for (int i = 0; i < text.length-1; ++i) { 
	        	
	        	//System.out.println("text::"+text[i]);	
	        }
			
	        int newheight=main_launcher.Frameheight/2;
		      int newwidth=main_launcher.Framewidth/2; 
		      JPanel inner2= new JPanel(new GridLayout(0, 1));
				 inner2.setPreferredSize(new Dimension(100, 270));
				 inner2.setBackground(Color.white);
			          	 //HashMap<JCheckBox, ArrayList<String>> map3 = new HashMap<>();
							JCheckBox checkBox3;
							String height;	
							int YValue;
						String cmp3;
						String t3;
						String blank3="::";
						String h="height=";
						String y1="y=";
						
				        for (int i3 = 1; i3 < rowTotal; i3++) {
				        	HSSFRow row3    = sheet.getRow(i3); 
				        	
				            StringBuilder sb = new StringBuilder();
				            ArrayList<String> listLL = new ArrayList<>();
				            //test
				            HSSFCell X1=row3.getCell(1);
				           
				        	 int  x= (int) X1.getNumericCellValue();
				            
				        	 HSSFCell Y1=row3.getCell(2);
				        	
				        	 int  y= (int) Y1.getNumericCellValue(); 
			        	 
			        	 if (y>=newheight  & x<newwidth)
		  			{
		  				cmp3=nature[i3];
		  				listLL.add(cmp3);
		                t3=text[i3];
		                YValue=YTab[i3];

		                height=heighttab[i3];
		                sb.append(cmp3).append(blank3).append(t3).append(blank3).append(y1).append(YValue).append(blank3).append(h).append(height);
			            

		            checkBox3 = new JCheckBox(sb.toString().trim());
		            checkBox3.setName("CheckBox" + t3);
		            checkBox3.addActionListener(new checkedElementsLL());
		            map3.put(checkBox3, listLL);
		            inner2.add(checkBox3);
		  			}}
				        if(map3.size()>=1 & map3.size()<4)
				        {
				        	 inner2.setPreferredSize(new Dimension(300, 10));
				        }
				        else if(map3.size()>=5 & map3.size()<8)
				        {
				        	 inner2.setPreferredSize(new Dimension(300, 150));
				        }
				        
				        else  if(map3.size()>=9 & map3.size()<14)
				        {
				        	inner2.setPreferredSize(new Dimension(300, 270));
				        }
				        
				        else  if(map3.size()>=15 & map3.size()<20)
				        {
				        	inner2.setPreferredSize(new Dimension(300, 350));
				        }
				        
				        else  if(map3.size()>=21 & map3.size()<26)
				        {
				        	inner2.setPreferredSize(new Dimension(300, 400));
				        }
				        else  if(map3.size()>=27 & map3.size()<31)
				        {
				        	inner2.setPreferredSize(new Dimension(300, 450));
				        }
				        else  if(map3.size()>=32 & map3.size()<37)
				        {
				        	inner2.setPreferredSize(new Dimension(300, 500));
				        }
				        else  if(map3.size()>=38 & map3.size()<43)
				        {
				        	inner2.setPreferredSize(new Dimension(300, 550));
				        }
				        else  if(map3.size()>=44 & map3.size()<50)
				        {
				        	inner2.setPreferredSize(new Dimension(300, 600));
				        }
				        else  inner2.setPreferredSize(new Dimension(300, 1000));
				        scrollPane2 = new JScrollPane(inner2);
				        scrollPane2.setPreferredSize(new Dimension(300,270));
				        scrollPane2.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
				        scrollPane2.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		}
		
		public void getContent3() throws IOException 
		{
		          //=============LR===========
		        	 //==========================
			
			String file=main_launcher.data_File;
	      	
	      	InputStream input = new FileInputStream(file);
	  		 HSSFWorkbook wb     = new HSSFWorkbook(input);
	  		 HSSFSheet sheet = wb.getSheetAt(0); //first sheet
	  		 //row number
	  		 int rowTotal = sheet.getLastRowNum();
	  	
	        if ((rowTotal > 0) || (sheet.getPhysicalNumberOfRows() > 0)) {
	            rowTotal++;
	        }
	      	
	        for ( int r=0;r<1; r++){     
	  			 HSSFRow row     = sheet.getRow(r); 
	  			 
	  			 //get cell number in each row
	  			 int noOfColumns = sheet.getRow(r).getLastCellNum(); 
	  			 
	  			 // parse cells values of each row
	  			 for (int c=0;c<noOfColumns; c++)
	  	    	        
	  		        {
	  				 
	  			 HSSFCell cell= row.getCell(c);
	  			// System.out.println("row="+r+"###"+cell.getStringCellValue() );
	  			 
	  			 String text= cell.getStringCellValue();
	  			 //System.out.println("text="+text);
	  			 if (text.equals("nature"))
	  			 {
	  				 indice_nature=c; 
	  				//System.out.println(indice_width);
	  			 }
	  			 
	  			 if (text.equals("text"))
	  			 {
	  				indice_text=c; 
	  				//System.out.println(indice_height);
	  			 }
	  			 if (text.equals("height"))
	  			 {
	  				indice_height=c; 
	  				//System.out.println(indice_height);
	  			 }
	  			if (text.equals("y"))
	  			 {
	  				indice_y=c; 
	  				//System.out.println(indice_height);
	  			 }
	  		        }
	  			 }
	        
	         nature=new String[rowTotal]; 
	  	   text=new String[rowTotal]; 
	  	 heighttab=new String[rowTotal];
	  	 YTab= new int[rowTotal];
	  	  //fill nature table
	        for ( int r=1;r<rowTotal; r++)
	        
	        {   
	      	   row     = sheet.getRow(r); 
	      	  
	      	  //fill the nature table
	      	  for (int c=indice_nature;c<indice_nature+1; c++)
	    	        
	  	        {
	      		  HSSFCell cell= row.getCell(c);
	      		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
	      		  nature[r-1]= (cell.getStringCellValue());
	      		  
	  	        }
	      	  
	      	//fill the text table
	      	  
	      	  for (int c=indice_text;c<indice_text+1; c++)
	      	        
	  	        {
	    		  HSSFCell cell= row.getCell(c);
	    		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
	    		  text[r-1]= (cell.getStringCellValue());
	    		  
	  	        }
	      	//fill the height table
	      	  
	      	  for (int c=indice_height;c<indice_height+1; c++)
	      	        
	  	        {
	    		  HSSFCell cell= row.getCell(c);
	    		  cell.setCellType(HSSFCell.CELL_TYPE_STRING);
	    		  heighttab[r-1]= (cell.getStringCellValue());
	    		  
	  	        }
	      	//fill the y table
	      	  
	      	  for (int c=indice_y;c<indice_y+1; c++)
	      	        
	  	        {
	    		  HSSFCell cell= row.getCell(c);
	    		 // cell.setCellType(HSSFCell.CELL_TYPE_STRING);
	    		  YTab[r-1]= (int) (cell.getNumericCellValue());
	    		  
	  	        }
	      	  
	        }
	       
	        
	        for (int i = 0; i < nature.length-1; ++i) { 
	        	
	        //	System.out.println("nature::"+nature[i]);	
	        }
	        
	        for (int i = 0; i < text.length-1; ++i) { 
	        	
	        	//System.out.println("text::"+text[i]);	
	        }
			
	        int newheight=main_launcher.Frameheight/2;
		      int newwidth=main_launcher.Framewidth/2;  
		      JPanel inner3= new JPanel(new GridLayout(0, 1));
				
				 inner3.setBackground(Color.white);
			          	 //HashMap<JCheckBox, ArrayList<String>> map4 = new HashMap<>();
							JCheckBox checkBox4;
							String height;	
							int YValue;
						String cmp4 ;
						String t4;
						String blank4="::";
						String h="height=";
						String y1="y=";
						
				        for (int i4 = 1; i4 < rowTotal; i4++) {
				        	HSSFRow row4   = sheet.getRow(i4); 
				        	
				            StringBuilder sb = new StringBuilder();
				           
				            //test
				            HSSFCell X1=row4.getCell(1);
				           
				        	 int  x= (int) X1.getNumericCellValue();
				            
				        	 HSSFCell Y1=row4.getCell(2);
				        	
				        	 int  y= (int) Y1.getNumericCellValue(); 	 
			        	 
		  			 if (y>=newheight & x>=newwidth){
		  				
		  				cmp4=nature[i4];
		  				listLR.add(cmp4);
		                t4=text[i4];
		                YValue=YTab[i4];

		                height=heighttab[i4];
		                sb.append(cmp4).append(blank4).append(t4).append(blank4).append(y1).append(YValue).append(blank4).append(h).append(height);
			            

		            checkBox4 = new JCheckBox(sb.toString().trim());
		            checkBox4.setName(t4);
		            map4text= new String[map4.size()];
		            //System.out.println(checkBox4.getName());
		          
		            checkBox4.addActionListener(new checkedElementsLR());
		            map4.put(checkBox4, listLR);
		            inner3.add(checkBox4);
		  			}}
				        
				        if(map4.size()>=1 & map4.size()<4)
				        {
				        	 inner3.setPreferredSize(new Dimension(300, 10));
				        }
				        
				        else  if(map4.size()>=5 & map4.size()<8)
				        {
				        	 inner3.setPreferredSize(new Dimension(300, 100));
				        }
				        else  if(map4.size()>=9 & map4.size()<14)
				        {
				        	 inner3.setPreferredSize(new Dimension(300, 200));
				        }
				        
				        else  if(map4.size()>=15 & map4.size()<20)
				        {
				        	 inner3.setPreferredSize(new Dimension(300, 350));
				        }
				        
				        else  if(map4.size()>=21 & map4.size()<26)
				        {
				        	 inner3.setPreferredSize(new Dimension(300, 400));
				        }
				        else  if(map4.size()>=27 & map4.size()<31)
				        {
				        	 inner3.setPreferredSize(new Dimension(300, 450));
				        }
				        else  if(map4.size()>=32 & map4.size()<37)
				        {
				        	 inner3.setPreferredSize(new Dimension(300, 500));
				        }
				        else  if(map4.size()>=38 & map4.size()<43)
				        {
				        	 inner3.setPreferredSize(new Dimension(300, 550));
				        }
				        else  if(map4.size()>=44 & map4.size()<50)
				        {
				        	 inner3.setPreferredSize(new Dimension(300, 600));
				        }
				        else  inner3.setPreferredSize(new Dimension(300, 1000));
				        scrollPane3 = new JScrollPane(inner3);
				        scrollPane3.setPreferredSize(new Dimension(300,270));
				        scrollPane3.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
				        scrollPane3.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
				    			
				    			
				    			
		coutSize();		    			
			    			
				    			
		}
		  			 
						 
		private void checkedElementsLR() {
			// TODO Auto-generated method stub
			
			
			
		}

		private void coutSize() {
			// TODO Auto-generated method stub
			sizemap1=map.size();
			sizemap2=map2.size();
			sizemap3=map3.size();
			sizemap4=map4.size();

		}

		public static Component getGUI() {
			// TODO Auto-generated method stub
			return scrollPane;
		}

		public static Component getGUI1() {
			// TODO Auto-generated method stub
			return scrollPane1;
		}
		public static Component getGUI2() {
			// TODO Auto-generated method stub
			return scrollPane2;
		}
		public static Component getGUI3() {
			// TODO Auto-generated method stub
			return scrollPane3;
		}
		class checkedElementsUL implements ActionListener{
			public void actionPerformed (ActionEvent ev) 
			{ 
			// TODO Auto-generated method stub
			
			//map	
			
				
		}
		}
		
		
		class checkedElementsUR implements ActionListener{
			public void actionPerformed (ActionEvent ev) 
			{	// TODO Auto-generated method stub
				//map2
			}
			}
		
		class checkedElementsLL implements ActionListener{
			public void actionPerformed (ActionEvent ev) 
			{	// TODO Auto-generated method stub
			//map3	
			}
			}
		
		
		class checkedElementsLR implements ActionListener{
			public void actionPerformed (ActionEvent ev) 
			{	// TODO Auto-generated method stub
			//map4	
		
				
			}
			}
		
}
