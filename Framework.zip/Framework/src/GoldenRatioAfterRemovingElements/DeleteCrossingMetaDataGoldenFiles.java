package GoldenRatioAfterRemovingElements;

import java.io.File;

/**
 * @author bessghaiernarjess
 */
public class DeleteCrossingMetaDataGoldenFiles {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		if (!(MTDMarginMutliplekeysGolden.outputFileNew.equals(null)))
		{
			File rows = new File(GenerateOldGoldenTree.outputFileNew);
			rows.delete();
			
			File Golden= new File(GoldenRatio.outputFileGoldenRatio);
			Golden.delete();
			File cols = new File(ElementsOnEachColumnGolden.outputFileNew);
			cols.delete();
			
			File X = new File(X_GoldenDistance.outputFileNew);
			X.delete();
			
			File Y = new File(Y_GoldenDistance.outputFileNew);
			Y.delete();
			
			File ML = new File(MLDMarginMultipleKeysGolden.outputFileNew);
			ML.delete();
			
			File MR = new File(MRDMarginMultipleKeysGolden.outputFileNew);
			MR.delete();
			
			File MB = new File(MBDMarginMultipleKeysGolden.outputFileNew);
			MB.delete();
		
			
		}
		
		
		
		
	}

}
